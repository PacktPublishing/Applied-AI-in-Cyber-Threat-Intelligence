# Flashpoint API Endpoints

**Auto-generated from API enumeration**

**Base URL**: https://fp.tools/api/v4

---

## Known Endpoints

### Indicators_Simple

**Path**: `/indicators/simple`

**Method**: GET

**Description**: Search for compromised credentials and technical indicators

**Status**: ✓ (200)

**Parameters**:
- `query`: Search query (e.g., +domain:"example.com")
- `limit`: Max results (default: 100)
- `types`: Comma-separated indicator types (e.g., email,credential-pair,domain,ip-dst)
- `since`: ISO timestamp for time filtering
- `until`: ISO timestamp for time filtering

**Response Schema**:
- Type: list

---

### Indicators_Attribute

**Path**: `/indicators/attribute`

**Method**: GET

**Description**: Search indicators by attribute (alternate endpoint)

**Status**: ✓ (200)

**Parameters**:
- `query`: Search query
- `limit`: Max results

**Response Schema**:
- Type: list

---

### Communities_Search

**Path**: `/communities/search`

**Method**: GET

**Description**: Search underground forums, marketplaces, and communities

**Status**: ✗ (404)

**Parameters**:
- `query`: Search query (organization, brand, domain)
- `limit`: Max results
- `since`: ISO timestamp
- `until`: ISO timestamp

---

### Communities_Post

**Path**: `/communities/posts`

**Method**: GET

**Description**: Get specific forum posts

**Status**: ✗ (404)

**Parameters**:
- `query`: Search query
- `limit`: Max results

---

### Finished_Intelligence

**Path**: `/finished-intelligence`

**Method**: GET

**Description**: Search analyst-generated finished intelligence reports

**Status**: ✗ (404)

**Parameters**:
- `query`: Search query (threat actor, campaign, industry)
- `limit`: Max results
- `since`: ISO timestamp
- `until`: ISO timestamp

---

### Reports_Search

**Path**: `/reports/search`

**Method**: GET

**Description**: Search intelligence reports (alternate endpoint)

**Status**: ✗ (404)

**Parameters**:
- `query`: Search query
- `limit`: Max results

---

### Vulnerabilities

**Path**: `/vulnerabilities/search`

**Method**: GET

**Description**: Search vulnerability intelligence and CVE data

**Status**: ✗ (503)

**Parameters**:
- `query`: Search query (CVE ID, product name, vendor)
- `limit`: Max results

---

### Paste_Sites

**Path**: `/paste-sites/search`

**Method**: GET

**Description**: Search paste sites for exposed data

**Status**: ✗ (404)

**Parameters**:
- `query`: Search query (domain, organization)
- `limit`: Max results

---

### Malware

**Path**: `/malware/search`

**Method**: GET

**Description**: Search malware intelligence

**Status**: ✗ (404)

**Parameters**:
- `query`: Search query
- `limit`: Max results

---

### Cards

**Path**: `/cards/search`

**Method**: GET

**Description**: Search for compromised payment card data

**Status**: ✗ (404)

**Parameters**:
- `query`: Search query (BIN, issuer)
- `limit`: Max results

---

### Chat_Services

**Path**: `/chat-services/search`

**Method**: GET

**Description**: Search chat services (Telegram, Discord, etc.)

**Status**: ✗ (404)

**Parameters**:
- `query`: Search query
- `limit`: Max results

---

### Compromised_Credentials

**Path**: `/compromised-credentials/search`

**Method**: GET

**Description**: Dedicated credential compromise search

**Status**: ✗ (404)

**Parameters**:
- `query`: Search query (domain, email)
- `limit`: Max results

---

### Threat_Actors

**Path**: `/threat-actors/search`

**Method**: GET

**Description**: Search threat actor profiles

**Status**: ✗ (404)

**Parameters**:
- `query`: Search query (actor name, group)
- `limit`: Max results

---

### Leaked_Credentials

**Path**: `/leaked-credentials`

**Method**: GET

**Description**: Search leaked credential databases

**Status**: ✗ (404)

**Parameters**:
- `query`: Domain or email
- `limit`: Max results

---

