#!/bin/bash
# CTI Priority Intelligence - Automated Run from config.yaml
# Robust execution with retry logic and graceful error handling

set -e

# Configuration
MAX_RETRIES=2
RETRY_DELAY=3

cd "$(dirname "$0")"

LOG_DIR="logs"
LOG_FILE="$LOG_DIR/run.log"

# Create log directory
mkdir -p "$LOG_DIR"

# Logging function
log() {
    local level=$1
    shift
    local message="$@"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message" >> "$LOG_FILE"
}

# Retry wrapper for commands
retry_command() {
    local description=$1
    shift
    local cmd="$@"
    local attempt=1

    while [ $attempt -le $MAX_RETRIES ]; do
        if [ $attempt -gt 1 ]; then
            echo "⚠️  Retry attempt $attempt/$MAX_RETRIES: $description"
            log "RETRY" "$description (attempt $attempt)"
            sleep $RETRY_DELAY
        fi

        if eval "$cmd" >> "$LOG_FILE" 2>&1; then
            log "SUCCESS" "$description"
            return 0
        else
            local exit_code=$?
            log "ERROR" "$description failed (attempt $attempt, exit code: $exit_code)"

            if [ $attempt -ge $MAX_RETRIES ]; then
                echo "✗ Failed after $MAX_RETRIES attempts: $description"
                return $exit_code
            fi
        fi

        attempt=$((attempt + 1))
    done

    return 1
}

echo "================================================================================"
echo "CTI PRIORITY INTELLIGENCE - CONFIG FILE MODE"
echo "================================================================================"
echo ""
log "INFO" "Starting CTI Priority Intelligence run (loading from config.yaml)"

# Check if venv exists
if [ ! -d "venv" ]; then
    echo "✗ Virtual environment not found!"
    echo "  Run setup first: ./setup.sh"
    log "ERROR" "Virtual environment not found"
    exit 1
else
    echo "✓ Virtual environment found"
    log "INFO" "Virtual environment found"
fi

# Activate venv
echo "[1/4] Activating virtual environment..."
source venv/bin/activate
echo "✓ venv activated"
log "SUCCESS" "Virtual environment activated"
echo ""

# Check dependencies
echo "[2/4] Checking dependencies..."
if ! python -c "import google.adk" &>/dev/null; then
    echo "⚠️  Dependencies not found or incomplete"
    echo "  Installing requirements.txt..."
    log "WARN" "Dependencies missing, reinstalling"

    if retry_command "Installing dependencies" "pip install -q -r requirements.txt"; then
        echo "✓ Dependencies installed"
    else
        echo "✗ Failed to install dependencies"
        echo "  Try manually: source venv/bin/activate && pip install -r requirements.txt"
        log "ERROR" "Failed to install dependencies"
        exit 1
    fi
else
    echo "✓ Dependencies already installed"
    log "INFO" "Dependencies verified"
fi
echo ""

# Check GCP auth
echo "[3/4] Checking authentication..."
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | grep -q "@"; then
    echo "⚠️  Not authenticated with gcloud"
    echo "  Running: gcloud auth login"
    log "WARN" "Not authenticated, running gcloud auth login"

    if retry_command "GCP authentication" "gcloud auth login"; then
        echo "✓ Authentication complete"
        log "SUCCESS" "Authentication complete"
    else
        echo "✗ Authentication failed"
        echo "  Try manually: gcloud auth login"
        log "ERROR" "Authentication failed"
        exit 1
    fi
fi

ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | head -1)
echo "✓ Authenticated as: $ACCOUNT"
log "INFO" "Authenticated as: $ACCOUNT"

# Get GCP project (from env var or gcloud config)
if [ -z "$GOOGLE_CLOUD_PROJECT" ]; then
    PROJECT_ID=$(gcloud config get-value project 2>/dev/null)
    if [ -z "$PROJECT_ID" ] || [ "$PROJECT_ID" = "(unset)" ]; then
        echo ""
        echo "✗ No GCP project configured"
        echo ""
        echo "Please set your project ID:"
        echo "  gcloud config set project YOUR_PROJECT_ID"
        echo ""
        echo "Or set the environment variable:"
        echo "  export GOOGLE_CLOUD_PROJECT=YOUR_PROJECT_ID"
        echo ""
        log "ERROR" "No GCP project configured"
        exit 1
    fi
    export GOOGLE_CLOUD_PROJECT="$PROJECT_ID"
fi
echo "✓ GCP Project: $GOOGLE_CLOUD_PROJECT"
log "INFO" "Using GCP project: $GOOGLE_CLOUD_PROJECT"
echo ""

# Run from config file
echo "[4/4] Starting intelligence gathering (loading from config.yaml)..."
log "INFO" "Starting intelligence gathering (config file mode)"
echo ""
echo "================================================================================"
echo ""

# Run with retry logic - using --from-config to load from config.yaml
if retry_command "Intelligence gathering" "python run_agent.py --from-config"; then
    EXIT_CODE=0
else
    EXIT_CODE=$?
fi

echo ""
echo "================================================================================"

if [ $EXIT_CODE -eq 0 ]; then
    echo "✓ INTELLIGENCE GATHERING COMPLETE"
    echo "================================================================================"
    echo ""
    echo "Report generated: output/latest_report.html"
    log "SUCCESS" "Intelligence gathering complete"
    echo ""

    # Auto-open report in browser
    if [ -f "output/latest_report.html" ]; then
        echo "Opening report in browser..."

        if [[ "$OSTYPE" == "darwin"* ]]; then
            # macOS
            open output/latest_report.html
        elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
            # Linux
            xdg-open output/latest_report.html 2>/dev/null || echo "⚠️  Could not auto-open. Manually open: output/latest_report.html"
        elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
            # Windows
            start output/latest_report.html
        else
            echo "⚠️  Platform not recognized. Manually open: output/latest_report.html"
        fi

        echo "✓ Report opened in browser"
        log "SUCCESS" "Report opened in browser"
    else
        echo "⚠️  Report file not found"
        log "WARN" "Report file not found"
    fi
else
    echo "✗ INTELLIGENCE GATHERING FAILED (exit code: $EXIT_CODE)"
    echo "================================================================================"
    echo ""
    echo "Check the logs for details:"
    echo "  System log: $LOG_FILE"
    echo "  Query log: logs/query_log_*.jsonl"
    echo ""
    log "ERROR" "Intelligence gathering failed (exit code: $EXIT_CODE)"
fi

echo ""
echo "================================================================================"
log "INFO" "Run complete (exit code: $EXIT_CODE)"

exit $EXIT_CODE
