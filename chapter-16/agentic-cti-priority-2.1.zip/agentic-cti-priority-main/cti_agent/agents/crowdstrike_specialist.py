"""
CrowdStrike Specialist Agent

Expert agent that knows the full CrowdStrike Falcon platform and can:
- Query ASM (Attack Surface Management) for exposed assets
- Check SSPM (SaaS Security) for misconfigurations
- Search Falcon for endpoint threats
- Query Spotlight for vulnerabilities
- Search Intel for threat actors and campaigns
- Refine queries across multiple passes
"""

import json
import asyncio
from typing import Dict, Any, List, Optional
from pathlib import Path
from google import genai
from google.genai import types

# Import tools
from ..tools import crowdstrike


SPECIALIST_PROMPT = """# CrowdStrike Specialist Agent

You are an expert CTI analyst specializing in CrowdStrike Falcon platform intelligence.

## CRITICAL REQUIREMENT: VERIFIABLE CROWDSTRIKE URLs ONLY
**EVERY finding MUST have a clickable CrowdStrike Falcon URL for verification**. NO hypothetical examples.

- Threat Actors → https://falcon.crowdstrike.com/intelligence/actors/{{actor_id}}
- Indicators → https://falcon.crowdstrike.com/intelligence/indicators/{{indicator_id}}
- Vulnerabilities → https://falcon.crowdstrike.com/intelligence/vulnerabilities/cve/{{cve_id}}
- Incidents → https://falcon.crowdstrike.com/investigate/events/...
- ASM Assets → https://falcon.crowdstrike.com/asm/assets/...
- SSPM Findings → https://falcon.crowdstrike.com/sspm/...

If the data is from CrowdStrike API, the URL MUST be included. No exceptions.

## Your Mission
Given an organization profile, gather comprehensive threat intelligence using the full CrowdStrike Falcon suite.

## Available Tools & APIs

### Attack Surface Management (ASM)
- Discover external assets (domains, IPs, cloud services)
- Identify exposed services and misconfigurations
- Map attack surface

### SaaS Security Posture Management (SSPM)
- Find SaaS application vulnerabilities
- Detect misconfigurations in cloud apps
- Identify shadow IT

### Falcon (Endpoint Intelligence)
- Search for endpoint threats and indicators
- Malware detections
- Behavioral analysis

### Spotlight (Vulnerability Intelligence)
- CVE intelligence and exploitability scores
- Vulnerability prioritization
- Patch recommendations

### Identity Protection
- User risk scores and suspicious activity
- User/host correlation and anomalies
- Identity-based threat detection
- Compromised account indicators

### Intel (Threat Intelligence)
- Threat actor campaigns and profiles
- Industry-specific threats
- Adversary motivations and TTPs

### Research & Validation (Google Search)
You can search Google to:
- **Research the organization**: "[org_name] technology stack", "[org_name] cloud infrastructure"
- **Find competitors**: "[org_name] competitors [industry]"
- **Understand threat landscape**: "[industry] common vulnerabilities", "[industry] targeted attacks 2026"
- **Validate API usage**: "CrowdStrike Falcon API examples", "CrowdStrike ASM query syntax"
- **Tech stack context**: "[org_name] SaaS applications", "[industry] common platforms"

**How to use Google Search**: Examples:
- To find what assets to search → Search "[company] infrastructure cloud providers"
- To identify SaaS apps → Search "[company] technology stack SaaS"
- To find competitors → Search "[company] [industry] competitors"
- To understand threats → Search "[industry] security vulnerabilities 2026"

## Your Approach
1. **Research Context**: Use Google Search to understand org's tech stack and infrastructure
2. **ASM Queries**: Discover all external assets (*.domain.com, cloud services)
3. **SSPM Checks**: Identify SaaS apps and misconfigurations
4. **Identity Protection**: Check for risky users, compromised accounts, user/host anomalies
5. **Spotlight Search**: Find CVEs relevant to discovered tech stack
6. **Falcon Intelligence**: Search for endpoint threats and indicators
7. **Intel Analysis**: Query threat actors targeting this org/industry
8. **Expand Context**: Search competitors and industry-wide threats
9. **Refine Searches**: Use findings to guide deeper searches across 2-3 passes

**CRITICAL**: You MUST perform 2-3 refinement passes even if initial queries succeed. Each pass should:
- Start broad (ASM discovery) → narrow (specific CVEs, actors)
- Use discoveries to inform next searches
- Expand to competitors and industry
- Use Google Search to identify what to search for
- Build comprehensive attack surface picture

## Organization Profile
{org_profile}

## Instructions
Plan your search strategy across all Falcon APIs, execute queries across multiple refinement passes, and evaluate results.
Return findings as structured JSON with confidence scores.

Output JSON format:
{{
  "search_strategy": "Brief description of your multi-API approach",
  "queries_planned": ["asm:*.domain.com", "sspm:saas_apps", "spotlight:tech_stack_cves", ...],
  "findings": [
    {{
      "type": "asset|vulnerability|threat_actor|indicator|misconfiguration",
      "source_api": "asm|sspm|falcon|spotlight|intel",
      "value": "...",
      "confidence": "high|medium|low",
      "relevance": "Why this matters to the organization",
      "data": {{...}}
    }}
  ],
  "refinements_attempted": ["Explain all query refinements across 2-3 passes"],
  "coverage_assessment": "How comprehensive was the search across all APIs"
}}
"""


async def collect_intelligence(
    client: genai.Client,
    org_profile: Dict[str, Any]
) -> Dict[str, Any]:
    """
    CrowdStrike Specialist Agent - Full platform intelligence with 2-3 refinement passes

    Args:
        client: Gemini client
        org_profile: Organization profile dict

    Returns:
        Intelligence findings with confidence scores
    """
    print("\n[CrowdStrike Specialist] Starting multi-pass platform intelligence collection...")

    # Build prompt
    prompt_file = Path(__file__).parent.parent / "prompts" / "crowdstrike_specialist.md"
    if prompt_file.exists():
        with open(prompt_file) as f:
            system_instruction = f.read()
    else:
        system_instruction = SPECIALIST_PROMPT

    try:
        # Use the comprehensive search_all() which already has:
        # - 2-phase intelligent correlation
        # - All 10 CrowdStrike modules
        # - ThreatGraph + MalQuery enrichment
        print("[CrowdStrike Specialist] Using comprehensive 2-phase collection...")
        print("[CrowdStrike Specialist]   Phase 1: All 10 modules in parallel")
        print("[CrowdStrike Specialist]   Phase 2: ThreatGraph correlation + MalQuery enrichment")

        results = await crowdstrike.search_all(org_profile)

        # Calculate total findings
        total_findings = (
            len(results.get("indicators", [])) +
            len(results.get("threat_actors", [])) +
            len(results.get("vulnerabilities", [])) +
            len(results.get("sspm_misconfigs", [])) +
            len(results.get("asm_assets", [])) +
            len(results.get("identity_risks", [])) +
            len(results.get("falcon_detections", [])) +
            len(results.get("incidents", [])) +
            len(results.get("custom_iocs", [])) +
            len(results.get("threat_graph", [])) +
            len(results.get("malquery_samples", []))
        )

        print(f"[CrowdStrike Specialist] ✓ Collection complete")
        print(f"[CrowdStrike Specialist]   Total: {total_findings} findings across all 10 modules + correlations")

        return {
            "source": "crowdstrike",
            "findings": results,
            "total_modules": 10
        }

    except Exception as e:
        print(f"[CrowdStrike Specialist] ✗ Collection failed: {e}")
        import traceback
        traceback.print_exc()
        # Return empty results rather than fail completely
        return {
            "source": "crowdstrike",
            "findings": {
                "indicators": [],
                "threat_actors": [],
                "vulnerabilities": [],
                "sspm_misconfigs": [],
                "asm_assets": [],
                "identity_risks": [],
                "falcon_detections": [],
                "incidents": [],
                "custom_iocs": [],
                "threat_graph": [],
                "malquery_samples": []
            },
            "error": str(e)
        }


# Unused helper functions (_execute_pass, _merge_findings, _deduplicate_indicators,
# _deduplicate_actors) removed - using search_all() as primary method with built-in
# 2-phase correlation and intelligent enrichment
