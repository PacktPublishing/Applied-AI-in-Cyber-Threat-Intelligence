"""
Query Reasoner Agent

Researches API documentation and constructs valid queries through:
1. Reading local OpenAPI/Swagger specs
2. Searching Google for official API docs
3. Reasoning about appropriate query construction
4. Testing and refining queries
"""

import json
import asyncio
from typing import Dict, List, Any, Optional
from pathlib import Path
from google import genai
from google.genai import types


QUERY_REASONER_SYSTEM = """# Query Reasoner Agent

You are an expert at understanding API documentation and constructing valid queries.

## Your Mission

Given an organization profile and a target API, you will:

1. **Research the API**: Read schemas, search documentation, understand requirements
2. **Reason about queries**: Determine what data we have vs what the API expects
3. **Craft queries**: Build valid FQL/filter syntax that will work
4. **Validate**: Explain your reasoning and potential issues

## Research Tools Available

You have access to:
- **Local API schemas**: OpenAPI/Swagger specs in references/ folder
- **Google Search**: Search for official API documentation
- **Web crawling**: Fetch and read documentation pages

## Query Construction Principles

1. **Match data to API requirements**
   - API expects CVE IDs → Need CVE IDs, not product names
   - API expects hostnames → Domains are valid
   - API expects user emails → Need email addresses, not domains

2. **Use conservative syntax**
   - Start with exact matches
   - Avoid wildcards unless docs confirm support
   - Use simple filters before complex FQL

3. **Test iteratively**
   - Craft query
   - Predict potential issues
   - Suggest fallbacks

## Output Format

Always return JSON:
```json
{
  "should_query": true/false,
  "reasoning": "Clear explanation of your decision",
  "research_summary": "What you learned from API docs",
  "queries": [
    {
      "filter": "exact filter syntax",
      "params": {...},
      "expected_results": "what this should return",
      "confidence": "high|medium|low"
    }
  ],
  "fallback_strategies": ["If primary query fails, try X"],
  "risks": ["Potential issue 1", "Potential issue 2"]
}
```

## Important Notes

- If you don't have appropriate data, return `should_query: false`
- Explain your reasoning clearly for debugging
- When uncertain, research the documentation first
- Always provide fallback strategies
"""


async def research_and_craft_queries(
    client: genai.Client,
    org_profile: Dict[str, Any],
    api_info: Dict[str, str],
    model: str = "gemini-2.5-pro"
) -> Dict[str, Any]:
    """
    Research API documentation and craft appropriate queries

    Args:
        client: Gemini client with tools enabled
        org_profile: Available data (domains, org name, industry, etc.)
        api_info: Dict with:
            - name: API name (e.g., "CrowdStrike Spotlight")
            - module: Module name for logging
            - sdk_method: SDK method to call
            - sdk_class: SDK class name
            - local_schema_path: Path to local OpenAPI/Swagger spec (optional)
            - docs_url: Official documentation URL (optional)
        model: Model to use (default: gemini-2.5-pro)

    Returns:
        Dict with should_query, reasoning, queries list
    """
    print(f"\n[Query Reasoner] Researching {api_info['name']}...")

    # Build research context
    research_context = {
        "available_data": org_profile,
        "api_name": api_info["name"],
        "module": api_info["module"],
        "sdk_method": api_info["sdk_method"],
        "sdk_class": api_info["sdk_class"]
    }

    # Load local schema if available
    local_schema = None
    if "local_schema_path" in api_info:
        schema_path = Path(__file__).parent.parent.parent / api_info["local_schema_path"]
        if schema_path.exists():
            print(f"[Query Reasoner]   Reading local schema: {schema_path.name}")
            with open(schema_path, 'r') as f:
                local_schema = json.load(f)
                # Extract relevant endpoint info
                research_context["local_schema"] = _extract_endpoint_info(
                    local_schema,
                    api_info["sdk_method"]
                )

    # Build research prompt
    prompt = f"""# Research Task: {api_info['name']}

## Available Data
```json
{json.dumps(org_profile, indent=2)}
```

## API Information
- **Name**: {api_info['name']}
- **Module**: {api_info['module']}
- **SDK Class**: {api_info['sdk_class']}
- **SDK Method**: {api_info['sdk_method']}

{"## Local Schema" if local_schema else ""}
{"```json" if local_schema else ""}
{json.dumps(research_context.get("local_schema", {}), indent=2) if local_schema else ""}
{"```" if local_schema else ""}

## Your Research Steps

1. **Analyze Local Schema** (if available)
   - What parameters does this endpoint accept?
   - What filters/query syntax is supported?
   - Are there examples in the schema?

2. **Search for Documentation** (if needed)
   - Search: "{api_info['name']} API filter syntax examples"
   - Search: "{api_info['sdk_class']}.{api_info['sdk_method']} parameters"
   - Find official docs with query examples

3. **Reason About Queries**
   - What data do we have? (domains, org name, industry)
   - What does this API expect? (CVE IDs, hostnames, user IDs, etc.)
   - Can we construct a valid query?
   - What syntax should we use?

4. **Craft Query or Skip**
   - If we have appropriate data → craft query with conservative syntax
   - If we lack data → skip and explain why
   - If uncertain → research more or use safest approach

5. **Validate & Plan Fallbacks**
   - What could go wrong?
   - What's the fallback if this fails?
   - What's your confidence level?

## Return Your Decision

Provide JSON with your reasoning and decision.
"""

    # Configure with search tool
    tools = [
        types.Tool(
            google_search=types.GoogleSearch()
        )
    ]

    # Call agent with temperature 0.4 for balanced reasoning
    response = await client.aio.models.generate_content(
        model=model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.4,  # Balanced: conservative but creative
            system_instruction=QUERY_REASONER_SYSTEM,
            response_mime_type="application/json",
            tools=tools
        )
    )

    result = json.loads(response.text)

    # Log reasoning
    print(f"[Query Reasoner]   Decision: {'QUERY' if result.get('should_query') else 'SKIP'}")
    print(f"[Query Reasoner]   Reasoning: {result.get('reasoning', 'N/A')[:150]}...")

    if result.get("should_query") and result.get("queries"):
        print(f"[Query Reasoner]   Queries: {len(result['queries'])} planned")
        for i, q in enumerate(result["queries"][:3], 1):
            print(f"[Query Reasoner]     {i}. Filter: {q.get('filter', 'N/A')[:80]}")

    return result


def _extract_endpoint_info(swagger_spec: Dict, method_name: str) -> Dict[str, Any]:
    """
    Extract relevant endpoint information from Swagger/OpenAPI spec

    Args:
        swagger_spec: Full Swagger/OpenAPI spec
        method_name: Method name to find (e.g., "queryVulnerabilities")

    Returns:
        Dict with endpoint info (parameters, filters, examples)
    """
    endpoint_info = {
        "found": False,
        "parameters": [],
        "description": "",
        "examples": []
    }

    # Search through paths
    paths = swagger_spec.get("paths", {})
    for path, methods in paths.items():
        for http_method, details in methods.items():
            operation_id = details.get("operationId", "")

            # Match by operationId or summary
            if method_name.lower() in operation_id.lower():
                endpoint_info["found"] = True
                endpoint_info["path"] = path
                endpoint_info["http_method"] = http_method.upper()
                endpoint_info["description"] = details.get("description", "")
                endpoint_info["summary"] = details.get("summary", "")

                # Extract parameters
                for param in details.get("parameters", []):
                    param_info = {
                        "name": param.get("name"),
                        "in": param.get("in"),
                        "required": param.get("required", False),
                        "type": param.get("type", param.get("schema", {}).get("type")),
                        "description": param.get("description", "")
                    }
                    endpoint_info["parameters"].append(param_info)

                # Look for examples
                if "examples" in details:
                    endpoint_info["examples"] = details["examples"]

                # Found match, return
                return endpoint_info

    return endpoint_info


# Convenience wrapper for each API
async def craft_crowdstrike_queries(
    client: genai.Client,
    org_profile: Dict[str, Any],
    module_name: str,
    sdk_class: str,
    sdk_method: str
) -> Dict[str, Any]:
    """
    Craft CrowdStrike queries using local Swagger spec and research

    Args:
        client: Gemini client
        org_profile: Organization profile
        module_name: Module name (e.g., "spotlight", "asm", "intel")
        sdk_class: FalconPy class name (e.g., "SpotlightVulnerabilities")
        sdk_method: Method name (e.g., "queryVulnerabilities")

    Returns:
        Query reasoning result
    """
    api_info = {
        "name": f"CrowdStrike {module_name.title()}",
        "module": module_name,
        "sdk_class": sdk_class,
        "sdk_method": sdk_method,
        "local_schema_path": "references/crowdstrike-api/cs-api-swagger-mav.json",
        "docs_url": f"https://falcon.crowdstrike.com/documentation/{module_name}-apis"
    }

    return await research_and_craft_queries(client, org_profile, api_info)


async def craft_flashpoint_queries(
    client: genai.Client,
    org_profile: Dict[str, Any],
    endpoint_type: str
) -> Dict[str, Any]:
    """
    Craft Flashpoint queries using OpenAPI spec and research

    Args:
        client: Gemini client
        org_profile: Organization profile
        endpoint_type: Endpoint type (e.g., "indicators", "communities", "reports")

    Returns:
        Query reasoning result
    """
    api_info = {
        "name": f"Flashpoint {endpoint_type.title()}",
        "module": endpoint_type,
        "sdk_class": "Flashpoint API",
        "sdk_method": f"search_{endpoint_type}",
        "local_schema_path": "references/flashpoint-api/flashpoint_api_openapi_spec.json",
        "docs_url": "https://fp.tools/api/v4/documentation"
    }

    return await research_and_craft_queries(client, org_profile, api_info)


async def craft_google_ti_queries(
    client: genai.Client,
    org_profile: Dict[str, Any],
    resource_type: str
) -> Dict[str, Any]:
    """
    Craft Google TI queries using local OpenAPI spec

    Args:
        client: Gemini client
        org_profile: Organization profile
        resource_type: Resource type (e.g., "domains", "threat_actors", "reports")

    Returns:
        Query reasoning result
    """
    api_info = {
        "name": f"Google Threat Intelligence {resource_type.title()}",
        "module": resource_type,
        "sdk_class": "GoogleTI",
        "sdk_method": f"get_{resource_type}",
        "local_schema_path": "references/google-ti-api/GTI_API_v3_openapi_spec_10022025.json",
        "docs_url": "https://developers.google.com/threat-intelligence/docs"
    }

    return await research_and_craft_queries(client, org_profile, api_info)
