"""
Reporter Agent - HTML Report Generation

Generates clean HTML reports with Mermaid diagrams
"""

import json
import asyncio
from pathlib import Path
from typing import Dict, Any
from datetime import datetime
from google import genai
from google.genai import types
from ..utils.relevancy import score_all_contextual_items


async def generate_html_report(
    client: genai.Client,
    analyzed_data: Dict[str, Any],
    org_profile: Dict[str, Any],
    output_dir: str = "output",
    metadata: Dict[str, Any] = None
) -> str:
    """
    Generate HTML intelligence report

    Args:
        client: Gemini client
        analyzed_data: Analyzed intelligence
        org_profile: Organization profile
        output_dir: Output directory
        metadata: Collection metadata (sources, execution time, etc.)

    Returns:
        Path to generated HTML report
    """
    print("\n[Reporter] Generating HTML report...")

    # Load reporter prompt
    prompt_file = Path(__file__).parent.parent / "prompts" / "reporter.md"
    with open(prompt_file) as f:
        system_instruction = f.read()

    # Build report prompt
    metadata = metadata or {}
    prompt = f"""## Organization Profile
```json
{json.dumps(org_profile, indent=2)}
```

## Analyzed Intelligence
```json
{json.dumps(analyzed_data, indent=2)}
```

## Collection Metadata
```json
{json.dumps(metadata, indent=2)}
```

Generate a **TACTICAL CTI intelligence report** for INTERNAL security teams.

CRITICAL REQUIREMENTS:
1. Top 5 critical findings (NO executive summary)
2. Every statement MUST have source citations [1], [2], etc.
3. Map threats to INTERNAL assets (hosts, users, environments)
4. Include hunt queries (Splunk, Elastic, Kusto)
5. Include detection rules (Sigma)
6. Temporal sections: last 24h, 7d, 30d with trends and hypothesis
7. Industry vs. targeted analysis
8. Source appendix with all citation details

Output as JSON following the schema in the system instruction.
"""

    # Call Gemini Flash for report generation
    try:
        response = await asyncio.to_thread(
            client.models.generate_content,
            model='gemini-2.5-flash',
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.4,  # Slightly higher for creative formatting
                system_instruction=system_instruction,
                response_mime_type='application/json'
            )
        )

        # Parse response (handle invalid escape sequences from LLM)
        try:
            report_data = json.loads(response.text)
        except json.JSONDecodeError as e:
            # Try to fix common escape issues
            import re
            cleaned_text = response.text
            # Fix invalid escape sequences like \u followed by non-hex or incomplete
            # Replace problematic backslashes with double backslashes
            cleaned_text = re.sub(r'\\(?!["\\/bfnrtu])', r'\\\\', cleaned_text)
            try:
                report_data = json.loads(cleaned_text)
            except json.JSONDecodeError:
                # If still failing, log and create error report
                print(f"[Reporter] ✗ JSON parsing failed: {str(e)}")
                print(f"[Reporter]    Response preview: {response.text[:500]}")
                raise Exception(f"Report generation failed: {str(e)}")

        # Validate report quality with judge agent
        print("[Reporter] Validating report quality...")
        validation_result = await _validate_report_quality(client, report_data, org_profile)

        if not validation_result.get('passes_validation', True):
            print(f"[Reporter] ⚠️  Quality issues detected: {validation_result.get('issues', [])}")
            print("[Reporter] Attempting to improve report...")
            # Could regenerate here, but for now just warn
        else:
            print("[Reporter] ✓ Report passes CTI analyst quality standards")

        # Generate HTML from report data
        html = _generate_html(report_data, org_profile, metadata)

        # Save to file
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Create unique filename
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        report_id = f"report_{timestamp}"
        filename = output_path / f"{report_id}.html"

        with open(filename, 'w') as f:
            f.write(html)

        # Also save to history if configured
        history_path = output_path / "history"
        history_path.mkdir(exist_ok=True)
        history_file = history_path / f"{report_id}.html"

        with open(history_file, 'w') as f:
            f.write(html)

        # Save latest symlink
        latest_file = output_path / "latest_report.html"
        with open(latest_file, 'w') as f:
            f.write(html)

        print(f"[Reporter] ✓ Report saved: {filename}")
        print(f"[Reporter]   Latest: {latest_file}")

        return str(filename)

    except Exception as e:
        print(f"[Reporter] ✗ Report generation failed: {e}")
        # Generate minimal error report
        error_html = f"<html><body><h1>Report Generation Failed</h1><p>Error: {e}</p></body></html>"
        error_file = Path(output_dir) / "error_report.html"
        with open(error_file, 'w') as f:
            f.write(error_html)
        return str(error_file)


async def _validate_report_quality(
    client: genai.Client,
    report_data: Dict[str, Any],
    org_profile: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Judge agent to validate report quality against CTI analyst standards

    Args:
        client: Gemini client
        report_data: Generated report data
        org_profile: Organization profile

    Returns:
        Validation result with pass/fail and issues
    """
    judge_prompt = f"""You are a senior CTI analyst expert reviewing a tactical intelligence report.

## Organization
{org_profile.get('organization', 'Unknown')}

## Report to Review
```json
{json.dumps(report_data, indent=2)}
```

## Validation Criteria

Review this report against the following CTI analyst standards:

1. **Source Citations**: Does EVERY claim have a source citation [1], [2], etc.?
2. **URL Verification & Source Matching (CRITICAL)**: Are ALL source URLs verifiable AND do they match the claimed source?
   - **MUST VALIDATE**: If source claims "CrowdStrike", URL MUST be https://falcon.crowdstrike.com/...
   - **MUST VALIDATE**: If source claims "Flashpoint", URL MUST be https://fp.tools/...
   - **MUST VALIDATE**: If source claims "Google TI", URL MUST be https://www.virustotal.com/gui/... or https://security.google.com/...
   - **MUST VALIDATE**: OSINT sources MUST have real URLs (not placeholder https://example.com)
   - **REJECT**: Generic/placeholder URLs like "N/A", "#", "https://example.com"
   - **REJECT**: URL domain mismatch (e.g., claiming "CrowdStrike" but URL is fp.tools)
3. **Internal Asset Correlation**: Are threats mapped to ACTUAL internal assets found in tools (not hypothetical)?
4. **Hunt Queries**: Are hunt queries provided using CrowdStrike FQL only?
5. **Temporal Context**: Are findings time-scoped (24h/7d/30d)?
6. **IOCs**: Are all indicators extracted with source references?
7. **Actionable**: Can a SOC analyst/hunter immediately act on this?
8. **Evidence**: Is raw data/proof provided for claims?
9. **Industry vs. Targeted**: Is it clear if threats are org-specific or industry-wide?
10. **Research Recommendations**: Are next-step research queries provided?
11. **NO HALLUCINATION**: Are all claims backed by actual tool data (no hypothetical examples)?

Output validation result as JSON:
```json
{{
  "passes_validation": true/false,
  "overall_score": 0-100,
  "issues": [
    "Missing source citations in findings 1 and 3",
    "Hunt queries use Splunk but org uses CrowdStrike",
    "No internal asset correlation provided"
  ],
  "strengths": [
    "Excellent temporal scoping",
    "Strong evidence with raw data snippets"
  ],
  "recommendations": [
    "Add source citations to all claims",
    "Replace Splunk queries with CrowdStrike FQL"
  ]
}}
```
"""

    try:
        response = await asyncio.to_thread(
            client.models.generate_content,
            model='gemini-2.5-flash',
            contents=judge_prompt,
            config=types.GenerateContentConfig(
                temperature=0.2,  # Low temp for consistent evaluation
                response_mime_type='application/json'
            )
        )

        validation = json.loads(response.text)
        return validation

    except Exception as e:
        print(f"[Reporter] Judge validation failed: {e}")
        # If validation fails, assume report is okay
        return {
            "passes_validation": True,
            "overall_score": 80,
            "issues": [],
            "note": f"Validation failed: {e}"
        }


def _make_citations_clickable(html: str) -> str:
    """
    Convert inline citation markers [1], [2], etc. into clickable anchor links

    Args:
        html: HTML string with citation markers

    Returns:
        HTML with clickable citations
    """
    import re

    # Pattern to match [number] citations
    citation_pattern = r'\[(\d+)\]'

    # Replace with anchor links
    def replace_citation(match):
        citation_num = match.group(1)
        return f'<a href="#source-{citation_num}" class="citation" title="Jump to source {citation_num}">[{citation_num}]</a>'

    return re.sub(citation_pattern, replace_citation, html)


def _generate_html(report_data: Dict[str, Any], org_profile: Dict[str, Any], metadata: Dict[str, Any]) -> str:
    """
    Convert tactical report JSON to HTML

    Args:
        report_data: Report data from LLM
        org_profile: Organization profile
        metadata: Collection metadata

    Returns:
        HTML string
    """
    # Extract tactical report data with type validation
    top_5 = report_data.get('top_5_critical_findings', [])
    if not isinstance(top_5, list):
        print(f"[Reporter] WARNING: top_5_critical_findings is {type(top_5)}, expected list")
        top_5 = []

    last_24h = report_data.get('last_24_hours', {})
    if not isinstance(last_24h, dict):
        print(f"[Reporter] WARNING: last_24_hours is {type(last_24h)}, expected dict")
        last_24h = {}

    last_7d = report_data.get('last_7_days', {})
    if not isinstance(last_7d, dict):
        print(f"[Reporter] WARNING: last_7_days is {type(last_7d)}, expected dict")
        last_7d = {}

    last_30d = report_data.get('last_30_days', {})
    if not isinstance(last_30d, dict):
        print(f"[Reporter] WARNING: last_30_days is {type(last_30d)}, expected dict")
        last_30d = {}

    mermaid = report_data.get('threat_correlation_diagram', '')
    if not isinstance(mermaid, str):
        print(f"[Reporter] WARNING: threat_correlation_diagram is {type(mermaid)}, expected str")
        mermaid = ''

    sources_appendix = report_data.get('sources_appendix', [])
    if not isinstance(sources_appendix, list):
        print(f"[Reporter] WARNING: sources_appendix is {type(sources_appendix)}, expected list")
        sources_appendix = []

    intel_status = report_data.get('intelligence_source_status', {})
    if not isinstance(intel_status, dict):
        print(f"[Reporter] WARNING: intelligence_source_status is {type(intel_status)}, expected dict")
        intel_status = {}

    # Build HTML with tactical format
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CTI Tactical Intelligence Report - {org_profile.get('organization', 'Unknown')}</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
    <script>mermaid.initialize({{startOnLoad:true}});</script>
    <style>
        html {{
            scroll-behavior: smooth;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Courier New', monospace;
            line-height: 1.7;
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            background: #0d1117;
            color: #c9d1d9;
        }}
        .header {{
            background: linear-gradient(135deg, #d73a4a 0%, #8b5cf6 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            border: 1px solid #30363d;
        }}
        .header h1 {{
            margin: 0 0 15px 0;
            font-size: 2em;
        }}
        .metadata {{
            font-size: 0.9em;
            opacity: 0.9;
            font-family: monospace;
        }}
        .section {{
            background: #161b22;
            padding: 25px;
            margin-bottom: 20px;
            border-radius: 8px;
            border: 1px solid #30363d;
        }}
        .section h2 {{
            margin-top: 0;
            color: #58a6ff;
            border-bottom: 2px solid #21262d;
            padding-bottom: 10px;
            font-size: 1.5em;
        }}
        .section h3 {{
            color: #79c0ff;
            margin-top: 20px;
            font-size: 1.2em;
        }}
        .finding-card {{
            background: #0d1117;
            border: 2px solid #30363d;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
        }}
        .finding-card.priority-1 {{
            border-left: 6px solid #d73a4a;
            background: #1a0d0d;
        }}
        .finding-card.priority-2 {{
            border-left: 6px solid #ff6b35;
            background: #1a0e07;
        }}
        .finding-card.priority-3 {{
            border-left: 6px solid #ffc107;
            background: #1a1607;
        }}
        .finding-card.priority-4 {{
            border-left: 6px solid #58a6ff;
            background: #07111a;
        }}
        .finding-card.priority-5 {{
            border-left: 6px solid #8b5cf6;
            background: #0f071a;
        }}
        .finding-header {{
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }}
        .finding-title {{
            font-size: 1.3em;
            font-weight: bold;
            color: #f0f6fc;
            flex: 1;
        }}
        .finding-badges {{
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }}
        .badge {{
            display: inline-block;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 0.85em;
            font-weight: bold;
            font-family: monospace;
        }}
        .badge-risk {{
            background: #d73a4a;
            color: white;
        }}
        .badge-confidence-high {{
            background: #2ea043;
            color: white;
        }}
        .badge-confidence-medium {{
            background: #ffc107;
            color: #000;
        }}
        .badge-confidence-low {{
            background: #6e7681;
            color: white;
        }}
        .badge-temporal {{
            background: #8b5cf6;
            color: white;
        }}
        .subsection {{
            margin: 15px 0;
            padding: 15px;
            background: #0d1117;
            border-left: 3px solid #21262d;
            border-radius: 4px;
        }}
        .subsection-title {{
            font-weight: bold;
            color: #79c0ff;
            margin-bottom: 8px;
            text-transform: uppercase;
            font-size: 0.9em;
            letter-spacing: 0.5px;
        }}
        .asset-list {{
            font-family: monospace;
            background: #161b22;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #30363d;
        }}
        .ioc-item {{
            font-family: monospace;
            background: #161b22;
            padding: 8px;
            margin: 5px 0;
            border-radius: 4px;
            border-left: 3px solid #d73a4a;
        }}
        .query-box {{
            background: #0d1117;
            padding: 12px;
            margin: 8px 0;
            border-radius: 6px;
            font-family: 'Courier New', monospace;
            border: 1px solid #30363d;
            overflow-x: auto;
            font-size: 0.9em;
        }}
        .citation {{
            color: #58a6ff;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
        }}
        .citation:hover {{
            text-decoration: underline;
        }}
        .tool-link {{
            display: inline-block;
            padding: 2px 6px;
            margin: 0 2px;
            background: #1f6feb;
            color: white;
            text-decoration: none;
            border-radius: 3px;
            font-size: 0.75em;
            font-weight: 600;
            transition: all 0.2s;
        }}
        .tool-link:hover {{
            background: #388bfd;
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(31,111,235,0.3);
        }}
        .source-item {{
            background: #0d1117;
            padding: 15px;
            margin: 10px 0;
            border-radius: 6px;
            border: 1px solid #30363d;
            font-family: monospace;
            font-size: 0.9em;
            transition: all 0.3s ease;
        }}
        .source-item:target {{
            background: #1a2332;
            border-color: #58a6ff;
            box-shadow: 0 0 0 3px rgba(88, 166, 255, 0.2);
        }}
        .attack-chain {{
            font-family: monospace;
            background: #161b22;
            padding: 15px;
            border-radius: 6px;
            border: 1px solid #30363d;
            overflow-x: auto;
            white-space: pre;
        }}
        .mermaid {{
            background: #161b22;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #30363d;
        }}
        code {{
            background: #161b22;
            padding: 3px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
            color: #ff7b72;
        }}
        pre {{
            background: #0d1117;
            padding: 15px;
            border-radius: 6px;
            overflow-x: auto;
            border: 1px solid #30363d;
        }}
        a {{
            color: #58a6ff;
        }}
        .temporal-section {{
            background: #0d1117;
            border: 2px solid #30363d;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }}
        .trend-box {{
            background: #161b22;
            padding: 15px;
            border-left: 4px solid #ffc107;
            margin: 10px 0;
            border-radius: 4px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🎯 TACTICAL CTI INTELLIGENCE REPORT</h1>
        <div class="metadata">
            <strong>CLASSIFICATION:</strong> INTERNAL USE ONLY<br>
            <strong>Organization:</strong> {org_profile.get('organization', 'Unknown')}<br>
            <strong>Industry:</strong> {org_profile.get('industry', 'Unknown')}<br>
            {f"<strong>Tech Stack:</strong> {', '.join(org_profile.get('technologies', []) or org_profile.get('technology_stack', []))}<br>" if org_profile.get('technologies') or org_profile.get('technology_stack') else ''}
            <strong>Generated:</strong> {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}<br>
            <strong>Execution Time:</strong> {metadata.get('execution_time', 'N/A')}<br>
            <strong>Analyst:</strong> CTI Priority Intelligence System (Automated)
        </div>
    </div>

    {_render_temporal_section('Last 24 Hours - URGENT', last_24h, '24h')}

    {_render_top_5_findings(top_5)}

    {_render_temporal_section('Last 7 Days - Recent Activity', last_7d, '7d')}
    {_render_temporal_section('Last 30 Days - Monthly Trends', last_30d, '30d')}

    {f'<div class="section"><h2>🔗 Threat Correlation & Attack Chains</h2><div class="mermaid">\n{mermaid}\n</div></div>' if mermaid else ''}

    {_render_contextual_intelligence(
        metadata.get('contextual_intelligence', []),
        metadata.get('threats_found', []),
        org_profile
    )}

    {_render_sources_appendix(sources_appendix)}

    {_render_intel_source_status(intel_status, metadata)}

    <div class="section">
        <p style="text-align:center;color:#6e7681;font-size:0.9em;">
            Generated by CTI Priority Intelligence System<br>
            Powered by Google ADK & Gemini 2.5 Pro<br>
            For: Internal CTI/SOC/Threat Hunting/Detection Engineering Teams
        </p>
    </div>
</body>
</html>"""

    # Make all citations clickable
    html = _make_citations_clickable(html)

    return html


def _render_top_5_findings(findings: list) -> str:
    """Render top 5 critical findings in tactical format"""
    if not findings:
        return '<div class="section"><h2>🔴 TOP 5 CRITICAL FINDINGS</h2><p>No critical findings identified.</p></div>'

    cards_html = []
    for finding in findings[:5]:
        priority = finding.get('priority', 0)
        title = finding.get('title', 'Unknown Finding')
        summary = finding.get('summary', '')
        risk_score = finding.get('risk_score', 0)
        # Safe access - handle None values
        confidence = str(finding.get('confidence') or 'UNKNOWN').upper()
        temporal = finding.get('temporal_context', '')
        why_matters = finding.get('why_this_matters', '')
        internal_assets = finding.get('internal_assets', {})
        if not isinstance(internal_assets, dict):
            internal_assets = {}
        suspected_attribution = finding.get('suspected_attribution', {})
        if not isinstance(suspected_attribution, dict):
            suspected_attribution = {}
        threat_vector = finding.get('threat_vector', '')
        attack_chain = finding.get('attack_chain_ascii', '')
        sources = finding.get('sources', [])
        if not isinstance(sources, list):
            sources = []
        iocs = finding.get('iocs', [])
        if not isinstance(iocs, list):
            iocs = []
        hunt_queries = finding.get('hunt_queries', {})
        if not isinstance(hunt_queries, dict):
            hunt_queries = {}
        industry_vs_targeted = finding.get('industry_vs_targeted', '')
        recommendations = finding.get('research_recommendations', [])
        if not isinstance(recommendations, list):
            recommendations = []

        # Build sources citations
        sources_html = ''
        for src in sources:
            src_id = src.get('id', '?')
            src_name = src.get('source', 'Unknown')
            src_url = src.get('url', '#')
            src_query = src.get('query', 'N/A')
            src_timestamp = src.get('timestamp', 'N/A')
            src_raw = src.get('raw_data', 'No raw data')

            sources_html += f'''
            <div class="source-item">
                <strong>[{src_id}] {src_name}</strong><br>
                <strong>URL:</strong> <a href="{src_url}" target="_blank" class="citation">{src_url}</a><br>
                <strong>Query:</strong> <code>{src_query}</code><br>
                <strong>Timestamp:</strong> {src_timestamp}<br>
                <strong>Raw Data:</strong><br>
                <pre>{src_raw}</pre>
            </div>
            '''

        # Build IOCs with tool search links
        iocs_html = ''
        for ioc in iocs:
            ioc_type = ioc.get('type', 'unknown')
            ioc_value = ioc.get('value', '')
            ioc_source_ref = ioc.get('source', '?')

            # Generate tool search links for IOCs
            tool_links = []
            if ioc_type in ['domain', 'url']:
                tool_links.append(f'<a href="https://security.google.com/threat-intelligence/search?query={ioc_value}" target="_blank" class="tool-link" title="Search in Google Threat Intelligence">🔍 GTI</a>')
                tool_links.append(f'<a href="https://falcon.crowdstrike.com/investigate/domains/{ioc_value}" target="_blank" class="tool-link" title="Investigate in CrowdStrike">🦅 CS</a>')
            elif ioc_type == 'ip':
                tool_links.append(f'<a href="https://security.google.com/threat-intelligence/search?query={ioc_value}" target="_blank" class="tool-link" title="Search in Google Threat Intelligence">🔍 GTI</a>')
                tool_links.append(f'<a href="https://falcon.crowdstrike.com/investigate/ips/{ioc_value}" target="_blank" class="tool-link" title="Investigate in CrowdStrike">🦅 CS</a>')
            elif ioc_type in ['hash', 'sha256', 'md5', 'sha1']:
                tool_links.append(f'<a href="https://security.google.com/threat-intelligence/search?query={ioc_value}" target="_blank" class="tool-link" title="Search in Google Threat Intelligence">🔍 GTI</a>')
                tool_links.append(f'<a href="https://falcon.crowdstrike.com/investigate/files/{ioc_value}" target="_blank" class="tool-link" title="Investigate in CrowdStrike">🦅 CS</a>')
            elif ioc_type == 'email':
                tool_links.append(f'<a href="https://fp.tools/api/v4/indicators/simple?query=%2Bemail%3A%22{ioc_value}%22" target="_blank" class="tool-link" title="Search in Flashpoint">🔦 FP</a>')

            tool_links_html = ' '.join(tool_links) if tool_links else ''
            iocs_html += f'<div class="ioc-item">{ioc_type.upper()}: <code>{ioc_value}</code> {tool_links_html} <span class="citation">[{ioc_source_ref}]</span></div>\n'

        # Build hunt queries (CrowdStrike FQL only)
        hunt_html = ''
        for platform, query in hunt_queries.items():
            platform_name = platform.replace('crowdstrike_fql_', '').replace('_', ' ').title()
            hunt_html += f'<div class="subsection-title">CrowdStrike FQL - {platform_name}</div><div class="query-box">{query}</div>\n'

        # Build assets
        assets_html = '<div class="asset-list">'
        if internal_assets.get('users'):
            assets_html += f"<strong>Users:</strong> {', '.join(internal_assets['users'])}<br>"
        if internal_assets.get('roles'):
            assets_html += f"<strong>Roles:</strong> {', '.join(internal_assets['roles'])}<br>"
        if internal_assets.get('access'):
            assets_html += f"<strong>Access:</strong><br>"
            for access in internal_assets.get('access', []):
                assets_html += f"&nbsp;&nbsp;- {access}<br>"
        if internal_assets.get('department'):
            assets_html += f"<strong>Department:</strong> {internal_assets['department']}<br>"
        if internal_assets.get('location'):
            assets_html += f"<strong>Location:</strong> {internal_assets['location']}<br>"
        assets_html += '</div>'

        # Build recommendations
        rec_html = '<ul>'
        for rec in recommendations:
            rec_html += f'<li>{rec}</li>'
        rec_html += '</ul>'

        # Build suspected attribution section
        attribution_html = ''
        if suspected_attribution:
            actors = suspected_attribution.get('threat_actors', [])
            attr_confidence = suspected_attribution.get('confidence', 'UNKNOWN')
            reasoning = suspected_attribution.get('reasoning', '')

            attribution_html = f'''
            <div class="subsection">
                <div class="subsection-title">Suspected Attribution</div>
                <p><strong>Threat Actors:</strong> {", ".join(actors) if actors else "Unknown"}</p>
                <p><strong>Attribution Confidence:</strong> <span class="badge badge-confidence-{attr_confidence.lower()}">{attr_confidence}</span></p>
                <p><strong>Reasoning:</strong> {reasoning}</p>
            </div>
            '''

        card = f'''
        <div class="finding-card priority-{priority}">
            <div class="finding-header">
                <div class="finding-title">#{priority}: {title}</div>
                <div class="finding-badges">
                    <span class="badge badge-risk">RISK: {risk_score}/100</span>
                    <span class="badge badge-confidence-{confidence.lower()}">{confidence}</span>
                    <span class="badge badge-temporal">{temporal}</span>
                </div>
            </div>

            <div class="subsection">
                <div class="subsection-title">Summary</div>
                <p>{summary}</p>
            </div>

            <div class="subsection">
                <div class="subsection-title">Why This Matters</div>
                <p>{why_matters}</p>
            </div>

            {attribution_html}

            {f'<div class="subsection"><div class="subsection-title">Internal Assets Affected</div>{assets_html}</div>' if internal_assets else ''}

            {f'<div class="subsection"><div class="subsection-title">Threat Vector</div><p>{threat_vector}</p></div>' if threat_vector else ''}

            {f'<div class="subsection"><div class="subsection-title">Attack Chain</div><div class="attack-chain">{attack_chain}</div></div>' if attack_chain else ''}

            {f'<div class="subsection"><div class="subsection-title">Indicators of Compromise (IOCs)</div>{iocs_html}</div>' if iocs else ''}

            {f'<div class="subsection"><div class="subsection-title">CrowdStrike Threat Hunting Queries (Copy-Paste Ready)</div>{hunt_html}</div>' if hunt_queries else ''}

            {f'<div class="subsection"><div class="subsection-title">Industry vs. Targeted Analysis</div><p>{industry_vs_targeted}</p></div>' if industry_vs_targeted else ''}

            {f'<div class="subsection"><div class="subsection-title">Research Recommendations</div>{rec_html}</div>' if recommendations else ''}

            {f'<div class="subsection"><div class="subsection-title">Sources & Evidence</div>{sources_html}</div>' if sources else ''}
        </div>
        '''
        cards_html.append(card)

    return f'<div class="section"><h2>🔴 TOP 5 CRITICAL FINDINGS (Priority Order)</h2>{"".join(cards_html)}</div>'


def _render_temporal_section(title: str, data: Dict[str, Any], period: str) -> str:
    """Render temporal intelligence section (24h/7d/30d)"""
    if not data:
        return ''

    findings = data.get('findings', [])
    trends = data.get('trends', 'No significant trends identified.')
    hypothesis = data.get('hypothesis', 'No hypothesis provided.')

    findings_html = ''
    if findings:
        # Support both simple string findings and detailed finding objects
        if isinstance(findings, list) and len(findings) > 0:
            if isinstance(findings[0], dict):
                # Detailed findings with sources
                findings_html = ''
                for finding in findings:
                    finding_text = finding.get('description', finding.get('summary', ''))
                    sources = finding.get('sources', [])

                    # Build inline source citations
                    sources_inline = ''
                    if sources:
                        for src in sources:
                            src_id = src.get('id', '?')
                            src_url = src.get('url', '#')
                            src_name = src.get('source', 'Unknown')
                            sources_inline += f' <a href="{src_url}" target="_blank" class="citation" title="{src_name}">[{src_id}]</a>'

                    findings_html += f'<li>{finding_text}{sources_inline}</li>\n'
                findings_html = f'<ul>{findings_html}</ul>'
            else:
                # Simple string findings (legacy)
                findings_html = '<ul>'
                for finding in findings:
                    findings_html += f'<li>{finding}</li>'
                findings_html += '</ul>'
    else:
        findings_html = '<p>No new findings in this time period.</p>'

    return f'''
    <div class="section">
        <h2>📅 {title}</h2>
        <div class="temporal-section">
            <h3>Findings</h3>
            {findings_html}

            <div class="trend-box">
                <strong>Trends Observed:</strong><br>
                {trends}
            </div>

            <div class="trend-box">
                <strong>Analyst Hypothesis:</strong><br>
                {hypothesis}
            </div>
        </div>
    </div>
    '''


def _render_sources_appendix(sources: list) -> str:
    """Render full sources appendix"""
    if not sources:
        return ''

    sources_html = ''
    for src in sources:
        src_id = src.get('id', '?')
        src_name = src.get('source', 'Unknown')
        src_url = src.get('url', '#')
        src_query = src.get('query', 'N/A')
        src_timestamp = src.get('timestamp', 'N/A')

        sources_html += f'''
        <div id="source-{src_id}" class="source-item">
            <strong>[{src_id}] {src_name}</strong><br>
            <strong>URL:</strong> <a href="{src_url}" target="_blank" class="citation">{src_url}</a><br>
            <strong>Query:</strong> <code>{src_query}</code><br>
            <strong>Timestamp:</strong> {src_timestamp}
        </div>
        '''

    return f'''
    <div class="section">
        <h2>📚 Sources Appendix (Full Citations)</h2>
        <p>All source citations referenced in this report with verifiable URLs and query details.</p>
        {sources_html}
    </div>
    '''


def _render_intel_source_status(intel_status: Dict[str, Any], metadata: Dict[str, Any]) -> str:
    """Render intelligence source status with detailed API tracking"""
    sources_queried = metadata.get("sources_queried", []) if isinstance(metadata, dict) else []
    api_tracker = metadata.get("api_tracker", {}) if isinstance(metadata, dict) else {}

    rows = []

    # If we have detailed API tracker data, use it
    if api_tracker.get("by_source"):
        # Get the error details for extracting error codes
        all_errors = api_tracker.get("errors", [])

        for src_key, src_data in api_tracker["by_source"].items():
            src_name = src_key.replace('_', ' ').title()
            total_queries = src_data.get('total', 0)
            success_queries = src_data.get('success', 0)
            error_queries = src_data.get('error', 0)
            modules = src_data.get('modules', {})

            # Determine status icon based on errors
            if error_queries == 0 and success_queries > 0:
                status_icon = "✅"
                status_text = "Success"
                status_color = "#2ea043"
            elif error_queries > 0 and success_queries > 0:
                status_icon = "⚠️"
                status_text = "Partial"
                status_color = "#ffc107"
            elif error_queries > 0:
                status_icon = "✗"
                status_text = "Failed"
                status_color = "#d73a4a"
            else:
                status_icon = "⚠️"
                status_text = "Unknown"
                status_color = "#6e7681"

            # Build module details with error codes
            module_details = []
            for module_name, module_data in modules.items():
                module_success = module_data.get('success', 0)
                module_error = module_data.get('error', 0)
                module_results = module_data.get('result_count', 0)

                if module_error > 0:
                    # Extract detailed error information for this source+module
                    error_info = {}
                    operations_failed = []
                    endpoints_failed = []
                    example_queries = []

                    for err in all_errors:
                        if err.get('source') == src_key and err.get('module') == module_name:
                            # Try to extract HTTP error code from error message or error_code field
                            error_code = err.get('error_code')
                            if not error_code and err.get('error'):
                                # Extract code from error message like "status 403" or "403 Forbidden"
                                import re
                                match = re.search(r'\b(403|404|429|500|502|503|504)\b', err['error'])
                                if match:
                                    error_code = match.group(1)

                            if error_code:
                                error_info[error_code] = error_info.get(error_code, 0) + 1

                            # Track which operations failed
                            operation = err.get('operation', '')
                            if operation and operation not in operations_failed:
                                operations_failed.append(operation)

                            # Track which endpoints failed (for admin troubleshooting)
                            endpoint = err.get('endpoint', '')
                            if endpoint and endpoint not in endpoints_failed:
                                endpoints_failed.append(endpoint)

                            # Track example queries (for debugging what was searched)
                            query = err.get('query', '')
                            if query and query not in example_queries and len(example_queries) < 3:
                                example_queries.append(query)

                    # Build error display with codes and interpretation
                    error_parts = []
                    guidance_parts = []

                    for code, count in sorted(error_info.items()):
                        if code == '403':
                            error_parts.append(f"<span style='color:#d73a4a;font-weight:bold;'>403 PERMISSION DENIED</span> ({count}x)")
                            guidance_parts.append("Check API license/permissions with admin")
                        elif code == '429':
                            error_parts.append(f"<span style='color:#ffc107;font-weight:bold;'>429 QUOTA EXHAUSTED</span> ({count}x)")
                            guidance_parts.append("Wait for quota reset or upgrade plan")
                        elif code == '404':
                            error_parts.append(f"<span style='color:#8b949e;'>404 NOT FOUND</span> ({count}x)")
                            guidance_parts.append("Endpoint not available - check license tier")
                        elif code in ['500', '502', '503', '504']:
                            error_parts.append(f"<span style='color:#ff6b35;'>5xx SERVICE ERROR</span> ({count}x)")
                            guidance_parts.append("Temporary service issue - retry later")
                        else:
                            error_parts.append(f"{code} ({count}x)")

                    if not error_parts:
                        error_parts.append(f"{module_error} errors")

                    error_display = ', '.join(error_parts)

                    # Add API endpoints that failed (critical for admin troubleshooting)
                    if endpoints_failed:
                        endpoint_display = f"<br><span style='font-size:0.85em;color:#ff7b72;font-family:monospace;'>Endpoints: {', '.join(endpoints_failed[:2])}</span>"
                        if len(endpoints_failed) > 2:
                            endpoint_display += f" <span style='color:#6e7681;'>+{len(endpoints_failed)-2} more</span>"
                        error_display += endpoint_display

                    # Add operations that failed (secondary info)
                    if operations_failed:
                        ops_display = f"<br><span style='font-size:0.85em;color:#8b949e;'>Operations: {', '.join(operations_failed[:3])}</span>"
                        if len(operations_failed) > 3:
                            ops_display += f" <span style='color:#6e7681;'>+{len(operations_failed)-3} more</span>"
                        error_display += ops_display

                    # Add example queries (critical for debugging)
                    if example_queries:
                        queries_truncated = [q[:40] + '...' if len(q) > 40 else q for q in example_queries]
                        queries_display = f"<br><span style='font-size:0.85em;color:#8b949e;font-style:italic;'>Example queries: {', '.join(f'"{q}"' for q in queries_truncated)}</span>"
                        error_display += queries_display

                    # Add guidance
                    if guidance_parts:
                        guidance_display = f"<br><span style='font-size:0.85em;color:#58a6ff;'>→ {guidance_parts[0]}</span>"
                        error_display += guidance_display

                    module_details.append(f"<span style='color:#d73a4a;'>✗ {module_name}: {error_display}</span>")
                elif module_success > 0:
                    module_details.append(f"<span style='color:#2ea043;'>✓ {module_name}: {module_results} results</span>")

            details_html = f"{success_queries}/{total_queries} queries succeeded"
            if module_details:
                details_html += f"<br><small>{'<br>'.join(module_details)}</small>"

            row = f'''
                <tr style="border-bottom:1px solid #30363d;">
                    <td style="padding:10px;"><strong>{src_name}</strong></td>
                    <td style="padding:10px;color:{status_color};">{status_icon} {status_text}</td>
                    <td style="padding:10px;">{details_html}</td>
                </tr>
            '''
            rows.append(row)

    # Fallback: Use old intel_status format
    elif intel_status:
        for src_key, src_data in intel_status.items():
            src_name = src_key.replace('_', ' ').title()
            status = src_data.get('status', 'unknown')
            queries = src_data.get('queries_run', 0)
            findings_count = src_data.get('findings', 0)

            status_icon = "✅" if status == "active" else "⚠️"
            details = f"{queries} queries executed, {findings_count} findings"

            row = f'''
                <tr style="border-bottom:1px solid #30363d;">
                    <td style="padding:10px;"><strong>{src_name}</strong></td>
                    <td style="padding:10px;">{status_icon} {status.title()}</td>
                    <td style="padding:10px;">{details}</td>
                </tr>
            '''
            rows.append(row)

    # Final fallback: Basic sources list
    else:
        for src in ["google_ti", "flashpoint", "crowdstrike", "osint"]:
            status_icon = "✅" if src in sources_queried else "⚠️"
            status_text = "Active" if src in sources_queried else "Unavailable"
            details = "Data collected" if src in sources_queried else "Not configured"

            row = f'''
                <tr style="border-bottom:1px solid #30363d;">
                    <td style="padding:10px;"><strong>{src.replace("_", " ").title()}</strong></td>
                    <td style="padding:10px;">{status_icon} {status_text}</td>
                    <td style="padding:10px;">{details}</td>
                </tr>
            '''
            rows.append(row)

    return f'''
    <div class="section">
        <h2>📊 Intelligence Source Status</h2>
        <table style="width:100%;border-collapse:collapse;">
            <tr style="background:#161b22;border-bottom:2px solid #30363d;">
                <th style="padding:10px;text-align:left;">Source</th>
                <th style="padding:10px;text-align:left;">Status</th>
                <th style="padding:10px;text-align:left;">Details</th>
            </tr>
            {"".join(rows)}
        </table>
        <p style="margin-top:15px;color:#6e7681;font-size:0.9em;">
            <strong>Note:</strong> System works with any combination of sources. Missing sources can be added via Google Secret Manager.
        </p>
    </div>
    '''


def _render_contextual_intelligence(
    contextual_items: list,
    threats: list,
    org_profile: Dict[str, Any]
) -> str:
    """
    Render contextual intelligence section with relevancy scoring

    Args:
        contextual_items: News/advisories from OSINT
        threats: Actual threats found in analysis
        org_profile: Organization profile

    Returns:
        HTML string for contextual intelligence section
    """
    if not contextual_items:
        return ''

    # Score all items by relevancy to threats
    scored_items = score_all_contextual_items(contextual_items, threats, org_profile)

    # Only show items with relevancy score > 0
    relevant_items = [item for item in scored_items if item.get('relevancy_score', 0) > 0]

    if not relevant_items:
        return ''

    # Build HTML for each item
    items_html = []
    for item in relevant_items[:15]:  # Limit to top 15 items
        title = item.get('title', 'Untitled')
        summary = item.get('summary', '')
        why_matters = item.get('why_it_matters', '')
        category = item.get('category', 'general')
        url = item.get('url', '#')
        source = item.get('source', 'Unknown')
        score = item.get('relevancy_score', 0)
        details = item.get('relevancy_details', [])

        # Color code based on relevancy score
        if score >= 70:
            score_color = "#2ea043"  # Green
            score_badge = "HIGH"
        elif score >= 40:
            score_color = "#ffc107"  # Yellow
            score_badge = "MEDIUM"
        else:
            score_color = "#6e7681"  # Gray
            score_badge = "LOW"

        # Category badge colors
        category_colors = {
            'breach': '#d73a4a',
            'vulnerability': '#ff6b35',
            'supply_chain': '#8b5cf6',
            'regulatory': '#ffc107',
            'threat_actor': '#d73a4a',
            'geopolitical': '#58a6ff',
            'general': '#6e7681'
        }
        category_color = category_colors.get(category.lower(), '#6e7681')

        # Build relevancy details list
        details_html = ''
        if details:
            details_html = '<ul style="margin:5px 0;padding-left:20px;font-size:0.85em;color:#8b949e;">'
            for detail in details:
                details_html += f'<li>{detail}</li>'
            details_html += '</ul>'

        item_card = f'''
        <div style="background:#0d1117;border:1px solid #30363d;border-left:4px solid {category_color};padding:15px;margin:15px 0;border-radius:6px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px;">
                <div style="flex:1;">
                    <strong style="font-size:1.1em;color:#f0f6fc;">{title}</strong>
                </div>
                <div style="display:flex;gap:8px;">
                    <span style="background:{category_color};color:white;padding:4px 8px;border-radius:4px;font-size:0.8em;font-weight:bold;">{category.upper().replace('_', ' ')}</span>
                    <span style="background:{score_color};color:white;padding:4px 8px;border-radius:4px;font-size:0.8em;font-weight:bold;">RELEVANCY: {score_badge} ({score})</span>
                </div>
            </div>

            {f'<p style="margin:10px 0;line-height:1.6;">{summary}</p>' if summary else ''}

            {f'<div style="background:#161b22;padding:10px;border-left:3px solid #58a6ff;margin:10px 0;border-radius:4px;"><strong style="color:#58a6ff;">Why It Matters:</strong><br>{why_matters}</div>' if why_matters else ''}

            {f'<div style="margin:10px 0;"><strong style="color:#79c0ff;font-size:0.9em;">Relevancy Factors:</strong>{details_html}</div>' if details_html else ''}

            <div style="margin-top:10px;font-size:0.85em;color:#8b949e;">
                <strong>Source:</strong> {source} | <a href="{url}" target="_blank" style="color:#58a6ff;">Read More →</a>
            </div>
        </div>
        '''
        items_html.append(item_card)

    return f'''
    <div class="section">
        <h2>🌍 Contextual Intelligence (Complementary Threat Landscape)</h2>
        <p style="color:#8b949e;margin-bottom:20px;">
            The following news and advisories provide broader context about the current threat landscape.
            Items are scored by relevancy to identified threats and organizational context (0-100 scale).
            <strong>High relevancy (70+)</strong> indicates strong correlation with your threats.
        </p>
        {"".join(items_html)}
        <p style="margin-top:15px;color:#6e7681;font-size:0.85em;text-align:center;">
            Showing top {len(items_html)} most relevant items from {len(contextual_items)} total contextual intelligence findings.
        </p>
    </div>
    '''
