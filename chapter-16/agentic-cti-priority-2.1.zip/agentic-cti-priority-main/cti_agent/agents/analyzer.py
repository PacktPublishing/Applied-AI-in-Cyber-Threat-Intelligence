"""
Analyzer Agent - Correlation + Enrichment

Combines correlation and enrichment into single analysis pass
"""

import json
import asyncio
from pathlib import Path
from typing import Dict, Any
from google import genai
from google.genai import types


async def analyze(
    client: genai.Client,
    raw_data: Dict[str, Any],
    org_profile: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Analyze raw intelligence: correlate, deduplicate, enrich

    Args:
        client: Gemini client
        raw_data: Raw intelligence from all sources
        org_profile: Organization profile

    Returns:
        Analyzed intelligence dict
    """
    print("\n[Analyzer] Correlating and enriching intelligence...")

    # Load analyzer prompt
    prompt_file = Path(__file__).parent.parent / "prompts" / "analyzer.md"
    with open(prompt_file) as f:
        system_instruction = f.read()

    # Build analysis prompt
    # Convert all data to JSON-serializable format (handles WhistleBlowerDict and other special objects)
    def make_serializable(obj):
        """Convert objects to JSON-serializable format"""
        if isinstance(obj, dict):
            return {k: make_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [make_serializable(item) for item in obj]
        elif hasattr(obj, '__dict__'):
            return str(obj)  # Convert complex objects to string
        else:
            return obj

    serializable_data = make_serializable(raw_data)

    prompt = f"""## Organization Profile
```json
{json.dumps(org_profile, indent=2)}
```

## Raw Intelligence Data

### Google Threat Intelligence
```json
{json.dumps(serializable_data.get('google_ti', {}), indent=2)}
```

### Flashpoint Intelligence
```json
{json.dumps(serializable_data.get('flashpoint', {}), indent=2)}
```

### CrowdStrike Intelligence
```json
{json.dumps(serializable_data.get('crowdstrike', {}), indent=2)}
```

### OSINT Intelligence
```json
{json.dumps(serializable_data.get('osint', {}), indent=2)}
```

Analyze this intelligence and provide:
1. Deduplicated and correlated threats
2. MITRE ATT&CK TTP mappings
3. Threat actor attribution
4. Risk scoring with confidence levels
5. Asset mapping to organization

Output as JSON following the schema in the system instruction.
"""

    # Call Gemini Pro for analysis
    try:
        response = await asyncio.to_thread(
            client.models.generate_content,
            model='gemini-2.5-pro',
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.2,
                system_instruction=system_instruction,
                response_mime_type='application/json'
            )
        )

        # Validate response before parsing
        if not response.text or not response.text.strip():
            print(f"[Analyzer] ✗ Empty response from Gemini")
            return {
                "threats": [],
                "attack_surface": "Analysis failed - empty response",
                "threat_actors_identified": [],
                "key_findings": ["Analysis returned empty response"],
                "error": "Empty response from analysis model"
            }

        # Parse response
        analyzed = json.loads(response.text)

        print(f"[Analyzer] ✓ Identified {len(analyzed.get('threats', []))} threats")
        print(f"[Analyzer]   Threat actors: {', '.join(analyzed.get('threat_actors_identified', []))}")

        return analyzed

    except json.JSONDecodeError as e:
        print(f"[Analyzer] ✗ Failed to parse response: {e}")
        print(f"[Analyzer] Response text (first 200 chars): {response.text[:200] if hasattr(response, 'text') else 'No text'}")
        # Return minimal structure
        return {
            "threats": [],
            "attack_surface": "Analysis failed - JSON parse error",
            "threat_actors_identified": [],
            "key_findings": ["Analysis encountered errors"],
            "error": str(e)
        }

    except Exception as e:
        print(f"[Analyzer] ✗ Analysis failed: {e}")
        return {
            "threats": [],
            "attack_surface": "Analysis failed",
            "threat_actors_identified": [],
            "key_findings": [],
            "error": str(e)
        }
