"""
Flashpoint Specialist Agent

Expert agent that knows the full Flashpoint API and can:
- Search for compromised credentials
- Monitor underground forums
- Track dark web mentions
- Correlate leaked data with org profile
- Refine queries across multiple passes
"""

import json
import asyncio
from typing import Dict, Any, List, Optional
from pathlib import Path
from google import genai
from google.genai import types

# Import tools
from ..tools import flashpoint


SPECIALIST_PROMPT = """# Flashpoint Specialist Agent

You are an expert CTI analyst using Flashpoint's intelligence platform.

## CRITICAL REQUIREMENT: VERIFIABLE FLASHPOINT URLs ONLY
**EVERY finding MUST have a clickable Flashpoint URL for verification**. NO hypothetical examples.

- Credentials → https://fp.tools/indicators/credential-{{id}}
- Forum Posts → https://fp.tools/home/search/conversations?fpid={{post_id}}
- Intelligence Reports → https://fp.tools/home/intelligence/reports/{{report_id}}
- Vulnerabilities → https://fp.tools/home/vulnerabilities/cve/{{cve_id}}
- Marketplace Listings → https://fp.tools/home/search/marketplaces?fpid={{listing_id}}

If the data is from Flashpoint API, the URL MUST be included. No exceptions.

## IMPORTANT: What Flashpoint Is
Flashpoint monitors illicit communities (forums, marketplaces, Telegram, paste sites) and indexes:
- Compromised credentials from breaches
- Threat actor discussions and planning
- Exploit sales and ransomware ads
- Vulnerability exploitation chatter

**DO NOT** add "dark web" to your searches - Flashpoint's data IS ALREADY from these sources.

## Your Mission
Search Flashpoint for intelligence about the organization using SPECIFIC identifiers.

## Available Tools

### Intelligence Collection
- `search_credentials(domain)` - Find credential leaks (e.g., "ukg.com", NOT "ukg.com dark web")
- `search_reports(query)` - Analyst-written finished intelligence reports (e.g., "HCM sector threats", "ransomware")

**REMOVED ENDPOINTS (returned 404 during enumeration 2026-02-11):**
- ~~search_forums()~~ - Not available
- ~~search_vulnerabilities()~~ - Not available

### Research & Validation (Google Search)
Use Google to DISCOVER what to search Flashpoint for:
- **Legacy identities**: "[org_name] former names acquired companies"
- **Competitors**: "[org_name] competitors [industry]"
- **Key people**: "[org_name] executives leadership"
- **Brand variants**: "[org_name] brands subsidiaries"
- **Past incidents**: "[org_name] breach ransomware 2021"

**Example**: UKG → Google finds "formerly Kronos and Ultimate Software" → Search Flashpoint for "kronos.com" and "ultimatesoftware.com"

## Search Strategy (DO NOT add "dark web" to ANY search)

### Pass 1: Direct Identifiers
Search Flashpoint for:
- Organization domains (e.g., "ukg.com")
- Current brand names (e.g., "UKG")
- Product names if relevant

### Pass 2: Historical Context (Use Google to find these first)
Search Flashpoint for:
- Legacy company names (e.g., "Kronos", "Ultimate Software")
- Acquired company domains
- Former brand names
- Executive names (CEO, CISO, CTO)

### Pass 3: Industry & Competitors
Search Flashpoint for:
- Industry keywords (e.g., "payroll", "HCM", "workforce management")
- Competitor mentions (find competitors via Google first)
- Technology stack (e.g., "AWS EKS exploit")

## Output Format - Include Trends & Hypothesis

## Organization Profile
{org_profile}

## Instructions
Plan your search strategy, execute queries across multiple refinement passes, and evaluate results.
Return findings as structured JSON with confidence scores.

Output JSON format:
{{
  "search_strategy": "Brief description of your approach",
  "queries_planned": ["query1", "query2", ...],
  "findings": [
    {{
      "type": "credential|forum_mention",
      "value": "...",
      "confidence": "high|medium|low",
      "relevance": "Why this matters to the organization",
      "data": {{...}}
    }}
  ],
  "refinements_attempted": ["Explain all query refinements across 2-3 passes"],
  "coverage_assessment": "How comprehensive was the search"
}}
"""


async def collect_intelligence(
    client: genai.Client,
    org_profile: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Flashpoint Specialist Agent - Dark web intelligence with 2-3 refinement passes

    Args:
        client: Gemini client
        org_profile: Organization profile dict

    Returns:
        Intelligence findings with confidence scores
    """
    print("\n[Flashpoint Specialist] Starting multi-pass dark web collection...")

    # Build prompt
    prompt_file = Path(__file__).parent.parent / "prompts" / "flashpoint_specialist.md"
    if prompt_file.exists():
        with open(prompt_file) as f:
            system_instruction = f.read()
    else:
        system_instruction = SPECIALIST_PROMPT

    all_findings = {
        "credentials": [],
        "forum_mentions": [],
        "finished_intelligence": [],
        "vulnerabilities": [],
        "refinement_passes": []
    }

    try:
        # Pass 1: Direct searches on current identifiers
        print("[Flashpoint Specialist] Pass 1: Direct searches on current identifiers...")
        pass1_findings = await _execute_pass(
            client, org_profile, system_instruction,
            pass_number=1,
            previous_findings=None
        )
        all_findings["credentials"].extend(pass1_findings.get("credentials", []))
        all_findings["forum_mentions"].extend(pass1_findings.get("forum_mentions", []))
        all_findings["finished_intelligence"].extend(pass1_findings.get("finished_intelligence", []))
        all_findings["vulnerabilities"].extend(pass1_findings.get("vulnerabilities", []))
        all_findings["refinement_passes"].append(pass1_findings.get("pass_summary", {}))

        # Pass 2: Expand to legacy brands and competitors
        print("[Flashpoint Specialist] Pass 2: Expanding to legacy brands and competitors...")
        pass2_findings = await _execute_pass(
            client, org_profile, system_instruction,
            pass_number=2,
            previous_findings=all_findings
        )
        all_findings["credentials"].extend(pass2_findings.get("credentials", []))
        all_findings["forum_mentions"].extend(pass2_findings.get("forum_mentions", []))
        all_findings["finished_intelligence"].extend(pass2_findings.get("finished_intelligence", []))
        all_findings["vulnerabilities"].extend(pass2_findings.get("vulnerabilities", []))
        all_findings["refinement_passes"].append(pass2_findings.get("pass_summary", {}))

        # Pass 3: Industry-wide and deep underground searches
        print("[Flashpoint Specialist] Pass 3: Industry-wide and deep underground searches...")
        pass3_findings = await _execute_pass(
            client, org_profile, system_instruction,
            pass_number=3,
            previous_findings=all_findings
        )
        all_findings["credentials"].extend(pass3_findings.get("credentials", []))
        all_findings["forum_mentions"].extend(pass3_findings.get("forum_mentions", []))
        all_findings["finished_intelligence"].extend(pass3_findings.get("finished_intelligence", []))
        all_findings["vulnerabilities"].extend(pass3_findings.get("vulnerabilities", []))
        all_findings["refinement_passes"].append(pass3_findings.get("pass_summary", {}))

        # Deduplicate findings
        all_findings["credentials"] = _deduplicate_credentials(all_findings["credentials"])
        all_findings["forum_mentions"] = _deduplicate_mentions(all_findings["forum_mentions"])

        print(f"[Flashpoint Specialist] ✓ Completed 3 passes")
        print(f"[Flashpoint Specialist]   Total: {len(all_findings['credentials'])} credentials, {len(all_findings['forum_mentions'])} forum mentions")
        print(f"[Flashpoint Specialist]   Total: {len(all_findings['finished_intelligence'])} analyst reports, {len(all_findings['vulnerabilities'])} vulnerabilities")

        return {
            "source": "flashpoint",
            "findings": all_findings,
            "total_passes": 3
        }

    except Exception as e:
        print(f"[Flashpoint Specialist] ✗ Multi-pass collection failed: {e}")
        import traceback
        traceback.print_exc()
        # Fallback to basic collection
        return await _fallback_collection(org_profile)


async def _execute_pass(
    client: genai.Client,
    org_profile: Dict[str, Any],
    system_instruction: str,
    pass_number: int,
    previous_findings: Optional[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Execute a single refinement pass with adaptive query refinement

    Args:
        client: Gemini client
        org_profile: Organization profile
        system_instruction: Base prompt template
        pass_number: Which pass (1-3)
        previous_findings: Findings from previous passes

    Returns:
        Findings from this pass
    """
    print(f"[Flashpoint Specialist]   Pass {pass_number}: Adaptive query refinement...")

    domains = org_profile.get("domains", [])
    org_name = org_profile.get("organization", "")
    brands = org_profile.get("brands", [])
    industry = org_profile.get("industry", "")
    tech_stack = org_profile.get("technology_stack", [])

    all_findings = {
        "credentials": [],
        "forum_mentions": [],
        "finished_intelligence": [],
        "vulnerabilities": [],
        "refinements": []
    }

    try:
        if pass_number == 1:
            # Pass 1: Direct domain and org name searches
            print(f"[Flashpoint Specialist]     Strategy: Direct domain/org searches")

            # Search credentials for domains
            for domain in domains[:3]:
                try:
                    creds = await flashpoint.search_credentials(domain)
                    if creds:
                        all_findings["credentials"].extend(creds)
                        all_findings["refinements"].append(f"✓ Found {len(creds)} credentials for domain '{domain}'")
                    else:
                        all_findings["refinements"].append(f"⚠️  No credentials for domain '{domain}'")
                except Exception as e:
                    all_findings["refinements"].append(f"✗ Credential search for '{domain}' error: {str(e)[:50]}")

            # Search forums for org name
            if org_name:
                try:
                    mentions = await flashpoint.search_reports(org_name)
                    if mentions:
                        all_findings["forum_mentions"].extend(mentions)
                        all_findings["refinements"].append(f"✓ Found {len(mentions)} forum mentions for org '{org_name}'")
                    else:
                        all_findings["refinements"].append(f"⚠️  No forum mentions for org '{org_name}'")
                except Exception as e:
                    all_findings["refinements"].append(f"✗ Forum search for org error: {str(e)[:50]}")

        elif pass_number == 2:
            # Pass 2: Industry searches and brand variants
            print(f"[Flashpoint Specialist]     Strategy: Industry searches and brand variants")

            prev_cred_count = len(previous_findings.get("credentials", []))
            prev_mention_count = len(previous_findings.get("forum_mentions", []))

            # If low credentials, try brand names
            if prev_cred_count < 10 and brands:
                for brand in brands[:2]:
                    all_findings["refinements"].append(f"Adapting: Trying brand '{brand}'")
                    try:
                        mentions = await flashpoint.search_reports(brand)
                        if mentions:
                            all_findings["forum_mentions"].extend(mentions)
                            all_findings["refinements"].append(f"✓ Found {len(mentions)} mentions for brand '{brand}'")
                        else:
                            all_findings["refinements"].append(f"⚠️  No mentions for brand '{brand}'")
                    except Exception as e:
                        all_findings["refinements"].append(f"✗ Brand search error: {str(e)[:50]}")

            # Search finished intelligence for industry
            if industry:
                all_findings["refinements"].append(f"Searching analyst reports for industry '{industry}'")
                try:
                    reports = await flashpoint.search_reports(industry)
                    if reports:
                        all_findings["finished_intelligence"].extend(reports)
                        all_findings["refinements"].append(f"✓ Found {len(reports)} analyst reports for industry")
                    else:
                        all_findings["refinements"].append(f"⚠️  No analyst reports for industry '{industry}'")
                except Exception as e:
                    all_findings["refinements"].append(f"✗ Analyst reports search error: {str(e)[:50]}")

        else:  # pass 3
            # Pass 3: Alternative report searches
            print(f"[Flashpoint Specialist]     Strategy: Alternative report searches and broader terms")

            # Note: Vulnerability search endpoint removed (503 error during enumeration)
            # Using additional report searches instead

            # Try industry reports if low on findings
            if len(previous_findings.get("forum_mentions", [])) < 5 and industry:
                all_findings["refinements"].append(f"Adapting: Trying industry forums for '{industry}'")
                try:
                    mentions = await flashpoint.search_reports(industry)
                    if mentions:
                        all_findings["forum_mentions"].extend(mentions)
                        all_findings["refinements"].append(f"✓ Found {len(mentions)} industry forum mentions")
                    else:
                        all_findings["refinements"].append(f"⚠️  No industry forum mentions")
                except Exception as e:
                    all_findings["refinements"].append(f"✗ Industry forum search error: {str(e)[:50]}")

        # Print refinement summary
        print(f"[Flashpoint Specialist]     Refinements attempted: {len(all_findings['refinements'])}")
        for ref in all_findings["refinements"][:5]:  # Show first 5
            print(f"[Flashpoint Specialist]       {ref}")

        return {
            "credentials": all_findings["credentials"],
            "forum_mentions": all_findings["forum_mentions"],
            "finished_intelligence": all_findings.get("finished_intelligence", []),
            "vulnerabilities": all_findings.get("vulnerabilities", []),
            "pass_summary": {
                "pass": pass_number,
                "strategy": f"Pass {pass_number}: Adaptive refinement",
                "queries_planned": all_findings["refinements"],
                "results": {
                    "credentials": len(all_findings["credentials"]),
                    "forum_mentions": len(all_findings["forum_mentions"]),
                    "finished_intelligence": len(all_findings.get("finished_intelligence", [])),
                    "vulnerabilities": len(all_findings.get("vulnerabilities", []))
                }
            }
        }

    except Exception as e:
        print(f"[Flashpoint Specialist]   ✗ Pass {pass_number} failed: {e}")
        import traceback
        traceback.print_exc()
        return {
            "credentials": [],
            "forum_mentions": [],
            "finished_intelligence": [],
            "vulnerabilities": [],
            "pass_summary": {"pass": pass_number, "error": str(e)}
        }


def _deduplicate_credentials(credentials: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove duplicate credential entries"""
    seen = set()
    unique = []
    for item in credentials:
        # Use combination of domain + value as key
        key = f"{item.get('domain', '')}:{item.get('value', '')}"
        if key and key not in seen:
            seen.add(key)
            unique.append(item)
    return unique


def _deduplicate_mentions(mentions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove duplicate forum mention entries"""
    seen = set()
    unique = []
    for item in mentions:
        # Use URL as unique key
        url = item.get("url", "")
        if url and url not in seen:
            seen.add(url)
            unique.append(item)
    return unique


async def _fallback_collection(org_profile: Dict[str, Any]) -> Dict[str, Any]:
    """Fallback if agent fails"""
    print("[Flashpoint Specialist] Using fallback collection...")
    return await flashpoint.search_all(org_profile)
