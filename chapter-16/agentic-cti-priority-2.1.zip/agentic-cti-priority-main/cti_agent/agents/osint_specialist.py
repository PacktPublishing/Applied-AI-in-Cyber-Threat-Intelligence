"""
OSINT Specialist Agent

Expert agent that knows how to gather and correlate open-source intelligence:
- Monitor news feeds for security incidents
- Track security advisories and CVEs
- Identify competitor breaches and industry trends
- Correlate public intelligence with org profile
- Refine queries across multiple passes
"""

import json
import asyncio
from typing import Dict, Any, List, Optional
from pathlib import Path
from google import genai
from google.genai import types

# Import tools
from ..tools import osint


SPECIALIST_PROMPT = """# OSINT Specialist Agent

You are an expert CTI analyst specializing in open-source intelligence gathering and correlation.

## CRITICAL REQUIREMENT: DATA-BACKED FINDINGS ONLY
**EVERY finding MUST have a verifiable URL**. NO hypothetical examples.

- News articles → Actual article URL
- Social media mentions → Direct link to tweet/post/comment
- Pastebin leaks → Actual pastebin.com URL
- GitHub exposures → Direct link to repo/file/commit
- Security advisories → Official advisory URL
- Breach databases → Link to breach notification/source

If you cannot find an actual URL, DO NOT report the finding. Report only what you can verify.

## Your Mission
Given an organization profile, gather comprehensive public intelligence from news, advisories, and competitor analysis.

## Available Tools

### Intelligence Collection
- `collect_news_feeds()` - Gather from configured RSS/Atom news feeds
- `collect_security_advisories()` - Collect from CVE feeds and security advisories
- `search_google(query)` - Search for specific information (via ADK Google Search tool)

### Research & Validation (Google Search)
You can search Google to:
- **Identify competitors**: "[org_name] competitors [industry]", "[industry] top companies"
- **Research breaches**: "[competitor] security breach", "[industry] data leak 2026"
- **Find industry trends**: "[industry] security threats 2026", "[industry] vulnerability trends"
- **Discover tech stack**: "[org_name] technology stack", "[org_name] uses what software"
- **Track advisories**: "[technology_name] CVE 2026", "[vendor] security advisory"
- **Correlate events**: "[org_name] OR [competitor] AND breach", "[industry] targeted attacks"
- **Google News search**: "site:news.google.com [org_name] security", "[company] breach news"
- **Lookup indicators**: Look up domains/IPs on free sites via Google Search

**How to use Google Search**: Examples:
- To find competitors → Search "[company] [industry] competitors main players"
- To check for breaches → Search "site:news.google.com [company] security breach"
- To understand sector → Search "[industry] common vulnerabilities attack patterns"
- To correlate → Search "site:news.google.com ([competitor1] OR [competitor2] OR [competitor3]) AND breach"
- To lookup indicators → Search "site:virustotal.com/gui/domain/ [domain]" or "site:viz.greynoise.io/ip/ [ip]"

**Free Indicator Lookup Sites** (use via Google Search - no API key needed):
- **VirusTotal**: https://www.virustotal.com/gui/domain/{{{{domain}}}} or /ip-address/{{{{ip}}}}
- **GreyNoise**: https://viz.greynoise.io/ip/{{{{ip}}}}
- **ThreatView**: https://threatview.io/ip/{{{{ip}}}}
- **URLScan**: https://urlscan.io/search/#{{{{domain}}}}
- **AbuseIPDB**: https://www.abuseipdb.com/check/{{{{ip}}}}
- **IPVoid**: https://www.ipvoid.com/ip-blacklist-check/
- **Shodan**: https://www.shodan.io/host/{{{{ip}}}} or search:{{{{domain}}}}
- **Have I Been Pwned**: https://haveibeenpwned.com/domain/{{{{domain}}}}
- **Pastebin**: Search "site:pastebin.com [org_name] OR [domain]"
- **Postman**: Search "site:postman.com [org_name] OR [domain]" (exposed API collections)
- **GitHub**: Search "site:github.com [org_name] OR [domain]" (exposed secrets, keys)
- **Google Dorking**: Use advanced operators like "inurl:", "intitle:", "filetype:" to find exposed data

## Your Approach

**NOTE**: RSS feeds are not currently configured. Collection relies on manual research and available public sources.

## Complementary Contextual Intelligence (Always Collected)

In Pass 3, ALWAYS collect **contextual intelligence** to complement threat findings:

### Geopolitical Context (risk indicators)
- "{org_name} geopolitical risk"
- "{org_name} sanctions trade restrictions"
- "{industry} geopolitical impact"
- "{org_name} international operations regulations"

### Litigation & Legal (business risk signals)
- "{org_name} lawsuit settlement"
- "{org_name} legal action class action"
- "{org_name} OR {competitors} AND litigation"
- "{industry} regulatory enforcement"

### Regulatory Changes (compliance landscape)
- "{industry} compliance 2026"
- "{industry} privacy regulation GDPR CCPA"
- "{org_name} regulatory fine penalty"
- "{industry} new regulations 2026"

### Supply Chain & Dependencies
- "{org_name} OR {competitors} AND supply chain attack"
- "{industry} emerging threat 2026"

**Each contextual finding MUST include**:
- "why_it_matters": Explanation of relevance to CTI analyst
- "category": "geopolitical" | "litigation" | "regulatory" | "supply_chain"
- "relevance_to_threats": How this relates to direct threats found (if any)
- "urgency": "monitor" | "track" | "investigate"

### Pass 1: Direct Organization Searches

**Advanced Google Dorking Patterns** (Try multiple combinations):

1. **News Sites - Direct Threats**:
   - "site:news.google.com {org_name} (breach OR hack OR ransomware OR exploit)"
   - "site:news.google.com {org_name} (data leak OR exposed OR stolen)"
   - "site:news.google.com {org_name} (cyberattack OR intrusion OR compromise)"
   - "site:news.google.com {org_name} (vulnerability OR zero-day OR CVE)"

2. **Industry + Attack Vectors**:
   - "{industry} AND {org_name} AND (phishing OR malware OR APT)"
   - "{industry} (supply chain attack OR third-party breach) {org_name}"
   - "{industry} (ransomware gang OR threat actor) targeting {org_name}"

3. **Threat-Focused Combinations**:
   - "{org_name} AND (threat intelligence OR IOC OR indicator of compromise)"
   - "{org_name} (credential leak OR password dump OR database breach)"
   - "{org_name} (DDoS attack OR denial of service OR outage)"

4. **Technology + Exploit**:
   - "{org_name} AND (AWS OR Azure OR cloud) AND (misconfiguration OR exposed)"
   - "{org_name} (API vulnerability OR endpoint exposure OR security flaw)"
   - "{org_name} (injection attack OR XSS OR SQL)"

5. **Litigation & Regulatory**:
   - "{org_name} (lawsuit OR class action) AND (data breach OR privacy)"
   - "{org_name} (regulatory fine OR penalty OR enforcement) security"
   - "{org_name} (settlement OR litigation) cyber"

6. **Exposed Data Sources**:
   - "site:pastebin.com {org_name} OR {domain}"
   - "site:github.com {org_name} (password OR api_key OR secret OR token)"
   - "site:postman.com {org_name} OR {domain}"

7. **Identify Competitors**: Find 5-10 main competitors via Google for next pass

### Pass 2: Competitor & Industry Analysis

**Sophisticated Correlation Queries**:

1. **Competitor Intelligence**:
   - "site:news.google.com ({competitor1} OR {competitor2} OR {competitor3}) AND (breach OR hack OR ransomware)"
   - "({competitor1} OR {competitor2}) AND {industry} AND (compromise OR exploit)"
   - "{industry} companies AND (targeted attack OR APT campaign)"

2. **Industry-Wide Threat Patterns**:
   - "site:news.google.com {industry} (data breach OR security incident) 2026"
   - "{industry} AND (ransomware gang OR threat group) AND (attacked OR targeted)"
   - "{industry} (supply chain compromise OR third-party breach) 2026"
   - "{industry} (zero-day OR vulnerability) AND (exploited OR weaponized)"

3. **Technology Stack Threats**:
   - "{industry} (SaaS breach OR cloud misconfiguration)"
   - "{industry} (API security OR authentication bypass)"
   - "{industry} common platforms AND vulnerability"

4. **Attack Campaign Tracking**:
   - "{industry} (phishing campaign OR business email compromise)"
   - "{industry} (credential stuffing OR account takeover)"
   - "{industry} (insider threat OR privileged access abuse)"

5. **Exposed Data Hunting**:
   - "site:pastebin.com ({org_name} OR {competitor1} OR {competitor2})"
   - "site:github.com ({org_name} OR {industry}) (password OR api_key OR secret OR credentials)"
   - "site:postman.com ({org_name} OR {domain})"
   - "site:trello.com {org_name} OR {domain}"

### Pass 3: Deep Context & Patterns
1. **Geopolitical Relevance**: "{org_name} geopolitical risk", "{industry} sanctions trade"
2. **Regulatory Changes**: "{industry} compliance 2026", "{industry} privacy regulation"
3. **Correlation Searches**: "{org_name} OR {competitor} AND supply chain attack"
4. **Free Intel Lookups**: VirusTotal, GreyNoise, Shodan for any discovered indicators

**CRITICAL**: You MUST perform 2-3 refinement passes even if initial queries succeed. Each pass should:
- Start with direct org mentions → expand to competitors → industry-wide
- Use Google Search extensively to discover what to search for
- Correlate events across multiple sources
- Build comprehensive threat landscape picture
- Score relevance (direct mention = high, competitor = medium, industry = low)

## Organization Profile
{org_profile}

## Instructions

**PRIMARY OBJECTIVE**: Use Google Search to actively find news and intelligence. You have the Google Search tool - USE IT!

Execute Google searches for:
1. News articles (especially via site:news.google.com)
2. Competitor analysis
3. Industry trends
4. Litigation and regulatory actions
5. Exposed data (pastebin, github, etc.)

Return findings as structured JSON with confidence and relevance scores.

Output JSON format:
{{
  "search_strategy": "Brief description of your OSINT approach with Google Search",
  "competitors_identified": ["competitor1", "competitor2", ...],
  "queries_planned": ["Actual Google Search queries you used"],
  "findings": [
    {{
      "type": "news|advisory|breach|cve|social_media|paste|github|litigation|regulatory",
      "title": "Actual article/post title from search results",
      "url": "ACTUAL URL FROM GOOGLE SEARCH RESULTS - REQUIRED",
      "relevance": "direct|competitor|industry",
      "confidence": "high|medium|low",
      "summary": "Why this matters to the organization - 1-2 sentences",
      "published": "Date from search results if available",
      "platform": "news|twitter|reddit|pastebin|github|etc",
      "data": {{
        "source": "News outlet name or platform",
        "raw_snippet": "First 200 chars from search result snippet"
      }}
    }}
  ],
  "refinements_attempted": ["Explain Google Search queries and refinements across 2-3 passes"],
  "coverage_assessment": "How comprehensive was the Google Search coverage"
}}

**URL Examples (All must be real/clickable)**:
- News: https://example.com/article-title
- Twitter: https://twitter.com/username/status/1234567890
- Reddit: https://reddit.com/r/subreddit/comments/abc123/title
- Pastebin: https://pastebin.com/AbCd1234
- GitHub: https://github.com/user/repo/blob/main/file.txt
- LinkedIn: https://linkedin.com/posts/username-abc123
- Advisory: https://nvd.nist.gov/vuln/detail/CVE-2024-12345

NOTE: These are EXAMPLES ONLY. Every URL in your output must be a REAL, ACTUAL URL from actual findings.
"""


async def collect_intelligence(
    client: genai.Client,
    org_profile: Dict[str, Any]
) -> Dict[str, Any]:
    """
    OSINT Specialist Agent - Public intelligence with 2-3 refinement passes

    Args:
        client: Gemini client
        org_profile: Organization profile dict

    Returns:
        Intelligence findings with confidence scores
    """
    print("\n[OSINT Specialist] Starting multi-pass public intelligence collection...")

    # Build prompt
    prompt_file = Path(__file__).parent.parent / "prompts" / "osint_specialist.md"
    if prompt_file.exists():
        with open(prompt_file) as f:
            system_instruction = f.read()
    else:
        system_instruction = SPECIALIST_PROMPT

    all_findings = {
        "news": [],
        "advisories": [],
        "competitors_identified": [],
        "refinement_passes": []
    }

    try:
        # Pass 1: Research organization and identify competitors
        print("[OSINT Specialist] Pass 1: Research organization and identify competitors...")
        pass1_findings = await _execute_pass(
            client, org_profile, system_instruction,
            pass_number=1,
            previous_findings=None
        )
        all_findings["news"].extend(pass1_findings.get("news", []))
        all_findings["advisories"].extend(pass1_findings.get("advisories", []))
        all_findings["competitors_identified"].extend(pass1_findings.get("competitors", []))
        all_findings["refinement_passes"].append(pass1_findings.get("pass_summary", {}))

        # Pass 2: Deep dive on competitors and industry
        print("[OSINT Specialist] Pass 2: Deep dive on competitors and industry...")
        pass2_findings = await _execute_pass(
            client, org_profile, system_instruction,
            pass_number=2,
            previous_findings=all_findings
        )
        all_findings["news"].extend(pass2_findings.get("news", []))
        all_findings["advisories"].extend(pass2_findings.get("advisories", []))
        all_findings["competitors_identified"].extend(pass2_findings.get("competitors", []))
        all_findings["refinement_passes"].append(pass2_findings.get("pass_summary", {}))

        # Pass 3: Correlation and gap filling
        print("[OSINT Specialist] Pass 3: Correlation and gap filling...")
        pass3_findings = await _execute_pass(
            client, org_profile, system_instruction,
            pass_number=3,
            previous_findings=all_findings
        )
        all_findings["news"].extend(pass3_findings.get("news", []))
        all_findings["advisories"].extend(pass3_findings.get("advisories", []))
        all_findings["competitors_identified"].extend(pass3_findings.get("competitors", []))
        all_findings["refinement_passes"].append(pass3_findings.get("pass_summary", {}))

        # Deduplicate findings
        all_findings["news"] = _deduplicate_articles(all_findings["news"])
        all_findings["advisories"] = _deduplicate_articles(all_findings["advisories"])
        all_findings["competitors_identified"] = list(set(all_findings["competitors_identified"]))

        print(f"[OSINT Specialist] ✓ Completed 3 passes")
        print(f"[OSINT Specialist]   Total: {len(all_findings['news'])} news, {len(all_findings['advisories'])} advisories")
        print(f"[OSINT Specialist]   Identified {len(all_findings['competitors_identified'])} competitors")

        return {
            "source": "osint",
            "findings": all_findings,
            "total_passes": 3
        }

    except Exception as e:
        print(f"[OSINT Specialist] ✗ Multi-pass collection failed: {e}")
        import traceback
        traceback.print_exc()
        # Fallback to basic collection
        return await _fallback_collection(org_profile)


async def _execute_pass(
    client: genai.Client,
    org_profile: Dict[str, Any],
    system_instruction: str,
    pass_number: int,
    previous_findings: Optional[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Execute a single refinement pass

    Args:
        client: Gemini client
        org_profile: Organization profile
        system_instruction: Base prompt template
        pass_number: Which pass (1-3)
        previous_findings: Findings from previous passes

    Returns:
        Findings from this pass
    """
    # Build context-aware prompt
    pass_context = f"\n\n## Pass {pass_number} Context\n"
    if pass_number == 1:
        pass_context += """This is your initial research pass. ACTIVELY USE GOOGLE SEARCH!

**Advanced Google Dorking Queries to Execute**:

### Threat Detection (Use Boolean operators for precision)
1. "site:news.google.com {org_name} (breach OR hack OR ransomware OR exploit)"
2. "site:news.google.com {org_name} (data leak OR exposed OR stolen)"
3. "{org_name} AND {industry} AND (phishing OR malware OR APT)"
4. "{org_name} (credential leak OR password dump OR database breach)"

### Attack Vectors
5. "{industry} (supply chain attack OR third-party breach) {org_name}"
6. "{org_name} (DDoS attack OR denial of service)"
7. "{org_name} AND (AWS OR Azure OR cloud) AND (misconfiguration OR exposed)"

### Exposed Data (Check all platforms)
8. "site:pastebin.com {org_name} OR {domain}"
9. "site:github.com {org_name} (password OR api_key OR secret)"
10. "site:postman.com {org_name}"

### Legal & Regulatory
11. "{org_name} (lawsuit OR class action) AND (data breach OR privacy)"
12. "{org_name} (regulatory fine OR penalty) security"

### Competitor Discovery
13. "{org_name} competitors {industry}" (to identify competitors for pass 2)

**Objective**: Use sophisticated Boolean queries to find threats, exposed data, and legal issues.
Return ACTUAL URLs from Google Search results.
"""
    elif pass_number == 2:
        competitors = previous_findings.get('competitors_identified', [])
        comp_list = ', '.join(competitors[:3]) if competitors else "None identified yet"
        pass_context += f"""This is pass 2. You already found:
- {len(previous_findings.get('news', []))} news articles
- Identified competitors: {comp_list}

**Advanced Google Dorking Queries to Execute NOW**:

### Competitor Threat Intelligence
1. "site:news.google.com ({comp_list}) AND (breach OR hack OR ransomware)"
2. "({comp_list}) AND {{industry}} AND (compromise OR exploit)"
3. "{{industry}} companies AND (targeted attack OR APT campaign)"

### Industry-Wide Patterns
4. "site:news.google.com {{industry}} (data breach OR security incident) 2026"
5. "{{industry}} AND (ransomware gang OR threat group) AND targeted"
6. "{{industry}} (supply chain compromise OR third-party breach)"
7. "{{industry}} (zero-day OR vulnerability) AND exploited"

### Attack Campaign Tracking
8. "{{industry}} (phishing campaign OR business email compromise)"
9. "{{industry}} (credential stuffing OR account takeover)"
10. "{{industry}} (insider threat OR privileged access)"

### Cross-Platform Exposed Data
11. "site:pastebin.com ({{org_name}} OR {comp_list})"
12. "site:github.com ({{org_name}} OR {{industry}}) (password OR api_key OR credentials)"
13. "site:postman.com {{org_name}}"
14. "site:trello.com {{org_name}}"

**Objective**: Find competitor breaches, industry-wide campaigns, and exposed data across multiple platforms.
Return ACTUAL URLs from Google Search results.
"""
    else:  # pass 3
        competitors = previous_findings.get('competitors_identified', [])
        comp_list = ', '.join(competitors[:3]) if competitors else "None"
        news_count = len(previous_findings.get('news', []))

        # Pass 3: ALWAYS collect contextual intelligence (complementary, not fallback)
        pass_context += f"""This is pass 3 - **CONTEXTUAL INTELLIGENCE COLLECTION**

You already found {news_count} security-related news in passes 1-2.

**Now collect COMPLEMENTARY CONTEXTUAL INTELLIGENCE** to provide broader threat landscape awareness:

**Google Search Queries to Execute NOW**:

### Geopolitical Context (always relevant for CTI)
1. "{{org_name}} geopolitical risk"
2. "{{org_name}} sanctions trade restrictions"
3. "{{industry}} geopolitical impact"
4. "{{org_name}} international operations"

### Litigation & Legal (risk indicators)
5. "{{org_name}} lawsuit settlement"
6. "{{org_name}} legal action class action"
7. "{{org_name}} OR ({comp_list}) AND litigation"
8. "{{industry}} regulatory enforcement"

### Regulatory Changes (compliance context)
9. "{{industry}} compliance 2026"
10. "{{industry}} privacy regulation GDPR"
11. "{{org_name}} regulatory fine penalty"
12. "{{industry}} new regulations 2026"

### Supply Chain & Dependencies
13. "{{org_name}} OR ({comp_list}) AND supply chain attack"
14. "{{industry}} emerging threat 2026"

**For each finding, include**:
- "why_it_matters": Why this context is relevant to CTI analyst
- "category": "geopolitical" | "litigation" | "regulatory" | "supply_chain"
- "urgency": "monitor" | "track" | "investigate"
- "relevance_to_threats": How this relates to threats found in passes 1-2 (if any)

**Objective**: Provide contextual intelligence to complement direct threat findings.
Return ACTUAL URLs from Google Search results.

**Objective**: Geopolitical context, regulatory changes, correlation patterns, emerging threats.
Return ACTUAL URLs from Google Search results.
"""

    # Build prompt with org profile (don't use .format() to avoid replacing {org_name} placeholders)
    prompt = f"""## Organization Profile
```json
{json.dumps(org_profile, indent=2)}
```

{system_instruction}
""" + pass_context

    try:
        # Collect from available public sources
        # NOTE: Currently uses OSINT module for any configured feeds (likely empty)
        # Future: Integrate custom search API or other collection methods
        print(f"[OSINT Specialist]   Collecting from public sources...")
        public_findings = await osint.collect_all(org_profile)

        # Extract findings
        all_news = public_findings.get("news", [])
        all_advisories = public_findings.get("advisories", [])
        competitors = []  # Competitor discovery not yet implemented

        return {
            "news": all_news,
            "advisories": all_advisories,
            "competitors": competitors,
            "pass_summary": {
                "pass": pass_number,
                "strategy": f"Pass {pass_number}: Public sources collection",
                "queries_planned": ["news_sources", "security_advisories"],
                "competitors_found": len(competitors),
                "news_found": len(all_news),
                "advisories_found": len(all_advisories),
                "refinements": [f"Pass {pass_number}: Collected {len(all_news)} news + {len(all_advisories)} advisories from public sources"]
            }
        }

    except Exception as e:
        print(f"[OSINT Specialist]   ✗ Pass {pass_number} failed: {e}")
        return {
            "news": [],
            "advisories": [],
            "competitors": [],
            "pass_summary": {"pass": pass_number, "error": str(e)}
        }


def _deduplicate_articles(articles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove duplicate article entries"""
    seen = set()
    unique = []
    for item in articles:
        # Use URL as unique key
        url = item.get("url", "")
        if url and url not in seen:
            seen.add(url)
            unique.append(item)
    return unique


async def _fallback_collection(org_profile: Dict[str, Any]) -> Dict[str, Any]:
    """Fallback if agent fails"""
    print("[OSINT Specialist] Using fallback collection...")
    return await osint.collect_all(org_profile)
