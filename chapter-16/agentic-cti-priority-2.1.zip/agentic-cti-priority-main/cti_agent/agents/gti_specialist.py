"""
Google Threat Intelligence Specialist Agent

Expert agent that knows the full GTI/VirusTotal API and can:
- Search domains, IPs, files, URLs
- Hunt for threat actors and campaigns
- Refine queries when no results
- Explain findings with confidence scores
"""

import json
import asyncio
from typing import Dict, Any, List, Optional
from pathlib import Path
from google import genai
from google.genai import types

# Import tools
from ..tools import google_ti


SPECIALIST_PROMPT = """# Google Threat Intelligence Specialist Agent

You are an expert CTI analyst specializing in Google Threat Intelligence (VirusTotal).

## CRITICAL REQUIREMENT: VERIFIABLE SOURCES ONLY
**EVERY finding MUST have a clickable VirusTotal URL for verification**. NO hypothetical examples.

- Domains → https://www.virustotal.com/gui/domain/{{domain}}
- IPs → https://www.virustotal.com/gui/ip-address/{{ip}}
- Threat Actors → https://www.virustotal.com/gui/threat-actor/{{actor_id}}
- Reports → https://www.virustotal.com/gui/intelligence-overview
- Collections → VirusTotal collection URL

If the data is from GTI API, the URL MUST be included. No exceptions.

## Your Mission
Given an organization profile, gather comprehensive threat intelligence using the GTI API.

## Available Tools

### Intelligence Collection
- `search_domain(domain)` - Get domain reputation, categories, malware associations
- `search_ip(ip)` - Get IP reputation and geolocation
- `search_threat_actors(query)` - Search for threat actors by name/industry/region

### Research & Validation (Google Search)
You can search Google to:
- **Research the organization**: "[org_name] competitors", "[org_name] technology stack", "[org_name] industry sector"
- **Validate API syntax**: "VirusTotal API threat actor query syntax", "GTI search operators"
- **Find query examples**: "VirusTotal search for [industry] threats"
- **Check for schema updates**: "VirusTotal API v3 changes 2026"
- **Industry context**: "[industry] security threats 2026"

**How to use Google Search**: Think about what you need to know, then search for it. Examples:
- If org profile has minimal info → Search "[company_name] industry competitors"
- If unsure about query syntax → Search "VirusTotal API query examples"
- If no results → Search "[industry_name] threat actors APT groups"

## Your Approach
1. **Research Context**: Use Google Search to understand the organization and its threat landscape
2. **Initial Queries**: Start with direct org domains
3. **Expand Context**: Search for:
   - Industry-specific threat actors (research via Google)
   - Competitors (identify via Google search)
   - Common technologies in that sector
4. **Validate Approach**: If uncertain about API syntax, search for examples
5. **Refine Searches**: Use different query terms across 2-3 refinement passes
6. **Evaluate Results**: Score confidence based on relevance to org

**CRITICAL**: You MUST perform 2-3 refinement passes even if initial queries succeed. Each pass should:
- Try different search terms
- Expand to related entities (competitors, industry, tech stack)
- Use Google Search to find additional context
- Build a comprehensive threat picture

## Organization Profile
{org_profile}

## Instructions
Plan your search strategy, execute queries across multiple refinement passes, and evaluate results.
Return findings as structured JSON with confidence scores.

Output JSON format:
{{
  "search_strategy": "Brief description of your approach",
  "queries_planned": ["query1", "query2", ...],
  "findings": [
    {{
      "type": "domain|ip|threat_actor",
      "value": "...",
      "confidence": "high|medium|low",
      "relevance": "Why this matters to the organization",
      "data": {{...}}
    }}
  ],
  "refinements_attempted": ["Explain all query refinements across 2-3 passes"],
  "coverage_assessment": "How comprehensive was the search"
}}
"""


async def collect_intelligence(
    client: genai.Client,
    org_profile: Dict[str, Any]
) -> Dict[str, Any]:
    """
    GTI Specialist Agent - Intelligent threat intelligence gathering with 2-3 refinement passes

    Args:
        client: Gemini client
        org_profile: Organization profile dict

    Returns:
        Intelligence findings with confidence scores
    """
    print("\n[GTI Specialist] Starting multi-pass intelligence collection...")

    # Build prompt
    prompt_file = Path(__file__).parent.parent / "prompts" / "gti_specialist.md"
    if prompt_file.exists():
        with open(prompt_file) as f:
            system_instruction = f.read()
    else:
        system_instruction = SPECIALIST_PROMPT

    all_findings = {
        "domains": [],
        "threat_actors": [],
        "intelligence_reports": [],
        "collections": [],
        "refinement_passes": []
    }

    try:
        # Pass 1: Initial research and direct queries
        print("[GTI Specialist] Pass 1: Initial research and direct queries...")
        pass1_findings = await _execute_pass(
            client, org_profile, system_instruction,
            pass_number=1,
            previous_findings=None
        )
        all_findings["domains"].extend(pass1_findings.get("domains", []))
        all_findings["threat_actors"].extend(pass1_findings.get("threat_actors", []))
        all_findings["intelligence_reports"].extend(pass1_findings.get("intelligence_reports", []))
        all_findings["collections"].extend(pass1_findings.get("collections", []))
        all_findings["refinement_passes"].append(pass1_findings.get("pass_summary", {}))

        # Pass 2: Expand to competitors and industry
        print("[GTI Specialist] Pass 2: Expanding to competitors and industry...")
        pass2_findings = await _execute_pass(
            client, org_profile, system_instruction,
            pass_number=2,
            previous_findings=all_findings
        )
        all_findings["domains"].extend(pass2_findings.get("domains", []))
        all_findings["threat_actors"].extend(pass2_findings.get("threat_actors", []))
        all_findings["intelligence_reports"].extend(pass2_findings.get("intelligence_reports", []))
        all_findings["collections"].extend(pass2_findings.get("collections", []))
        all_findings["refinement_passes"].append(pass2_findings.get("pass_summary", {}))

        # Pass 3: Deep dive on gaps and related threats
        print("[GTI Specialist] Pass 3: Deep dive on gaps and related threats...")
        pass3_findings = await _execute_pass(
            client, org_profile, system_instruction,
            pass_number=3,
            previous_findings=all_findings
        )
        all_findings["domains"].extend(pass3_findings.get("domains", []))
        all_findings["threat_actors"].extend(pass3_findings.get("threat_actors", []))
        all_findings["intelligence_reports"].extend(pass3_findings.get("intelligence_reports", []))
        all_findings["collections"].extend(pass3_findings.get("collections", []))
        all_findings["refinement_passes"].append(pass3_findings.get("pass_summary", {}))

        # Deduplicate findings
        all_findings["domains"] = _deduplicate_domains(all_findings["domains"])
        all_findings["threat_actors"] = _deduplicate_actors(all_findings["threat_actors"])

        print(f"[GTI Specialist] ✓ Completed 3 passes")
        print(f"[GTI Specialist]   Total: {len(all_findings['domains'])} domains, {len(all_findings['threat_actors'])} threat actors")
        print(f"[GTI Specialist]   Total: {len(all_findings['intelligence_reports'])} reports, {len(all_findings['collections'])} collections")

        return {
            "source": "google_ti",
            "findings": all_findings,
            "total_passes": 3
        }

    except Exception as e:
        print(f"[GTI Specialist] ✗ Multi-pass collection failed: {e}")
        import traceback
        traceback.print_exc()
        # Fallback to basic collection
        return await _fallback_collection(org_profile)


async def _execute_pass(
    client: genai.Client,
    org_profile: Dict[str, Any],
    system_instruction: str,
    pass_number: int,
    previous_findings: Optional[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Execute a single refinement pass with adaptive query refinement

    Args:
        client: Gemini client
        org_profile: Organization profile
        system_instruction: Base prompt template
        pass_number: Which pass (1-3)
        previous_findings: Findings from previous passes

    Returns:
        Findings from this pass
    """
    print(f"[GTI Specialist]   Pass {pass_number}: Adaptive query refinement...")

    domains = org_profile.get("domains", [])
    org_name = org_profile.get("organization", "")
    industry = org_profile.get("industry", "")

    all_findings = {
        "domains": [],
        "threat_actors": [],
        "intelligence_reports": [],
        "collections": [],
        "refinements": []
    }

    try:
        if pass_number == 1:
            # Pass 1: Direct searches
            print(f"[GTI Specialist]     Strategy: Direct org searches")

            # Search domains
            for domain in domains[:5]:
                try:
                    result = await google_ti.search_domain(domain)
                    if result:
                        all_findings["domains"].append(result)
                        all_findings["refinements"].append(f"✓ Domain {domain} found")
                    else:
                        all_findings["refinements"].append(f"✗ Domain {domain} returned no data")
                except Exception as e:
                    all_findings["refinements"].append(f"✗ Domain {domain} error: {str(e)[:50]}")

            # Search threat actors by org name
            if org_name:
                try:
                    actors = await google_ti.search_threat_actors(org_name)
                    if actors:
                        all_findings["threat_actors"].extend(actors)
                        all_findings["refinements"].append(f"✓ Found {len(actors)} threat actors for '{org_name}'")
                    else:
                        all_findings["refinements"].append(f"⚠️  No threat actors for '{org_name}', will try industry in pass 2")
                except Exception as e:
                    all_findings["refinements"].append(f"✗ Threat actor search '{org_name}' error: {str(e)[:50]}")

        elif pass_number == 2:
            # Pass 2: Industry and alternative queries
            print(f"[GTI Specialist]     Strategy: Industry-wide searches and alternatives")

            prev_actor_count = len(previous_findings.get("threat_actors", []))

            # If we didn't find threat actors in pass 1, try industry
            if prev_actor_count == 0 and industry:
                all_findings["refinements"].append(f"Adapting: No actors in pass 1, searching by industry '{industry}'")
                try:
                    actors = await google_ti.search_threat_actors(industry)
                    if actors:
                        all_findings["threat_actors"].extend(actors)
                        all_findings["refinements"].append(f"✓ Found {len(actors)} threat actors for industry '{industry}'")
                    else:
                        all_findings["refinements"].append(f"⚠️  No threat actors for industry '{industry}', will try alternative terms in pass 3")
                except Exception as e:
                    all_findings["refinements"].append(f"✗ Industry threat actor search error: {str(e)[:50]}")

            # Search intelligence reports
            if industry:
                try:
                    reports = await google_ti.search_intelligence_reports(industry)
                    if reports:
                        all_findings["intelligence_reports"].extend(reports)
                        all_findings["refinements"].append(f"✓ Found {len(reports)} intel reports for '{industry}'")
                    else:
                        all_findings["refinements"].append(f"⚠️  No intel reports for '{industry}'")
                except Exception as e:
                    all_findings["refinements"].append(f"✗ Intel reports search error: {str(e)[:50]}")

            # Search collections
            if industry:
                try:
                    collections = await google_ti.search_collections(industry)
                    if collections:
                        all_findings["collections"].extend(collections)
                        all_findings["refinements"].append(f"✓ Found {len(collections)} collections for '{industry}'")
                    else:
                        all_findings["refinements"].append(f"⚠️  No collections for '{industry}'")
                except Exception as e:
                    all_findings["refinements"].append(f"✗ Collections search error: {str(e)[:50]}")

        else:  # pass 3
            # Pass 3: Alternative terms and gap filling
            print(f"[GTI Specialist]     Strategy: Alternative query terms and gap filling")

            prev_actor_count = len(previous_findings.get("threat_actors", []))
            # Safe access to refinement_passes - check length before indexing
            prev_reports = 0
            refinement_passes = previous_findings.get("refinement_passes", [])
            if len(refinement_passes) > 1:
                prev_reports = len(refinement_passes[1].get("intelligence_reports", []))

            # Try alternative search terms if we're still low on data
            if prev_actor_count < 3:
                alternative_terms = []
                if industry:
                    # Try broader industry terms
                    if "financial" in industry.lower() or "bank" in industry.lower():
                        alternative_terms = ["finance sector", "banking"]
                    elif "healthcare" in industry.lower() or "hcm" in industry.lower():
                        alternative_terms = ["healthcare", "HR technology"]
                    elif "tech" in industry.lower() or "software" in industry.lower():
                        alternative_terms = ["technology sector", "software companies"]
                    else:
                        alternative_terms = [f"{industry} sector"]

                for alt_term in alternative_terms[:2]:
                    all_findings["refinements"].append(f"Adapting: Trying alternative term '{alt_term}'")
                    try:
                        actors = await google_ti.search_threat_actors(alt_term)
                        if actors:
                            all_findings["threat_actors"].extend(actors)
                            all_findings["refinements"].append(f"✓ Alternative term '{alt_term}' found {len(actors)} actors")
                            break  # Found results, stop trying alternatives
                        else:
                            all_findings["refinements"].append(f"⚠️  Alternative term '{alt_term}' returned no results")
                    except Exception as e:
                        all_findings["refinements"].append(f"✗ Alternative term '{alt_term}' error: {str(e)[:50]}")

            # Try org-specific reports if we haven't already
            if org_name and prev_reports == 0:
                all_findings["refinements"].append(f"Adapting: No reports yet, searching org name '{org_name}'")
                try:
                    reports = await google_ti.search_intelligence_reports(org_name)
                    if reports:
                        all_findings["intelligence_reports"].extend(reports)
                        all_findings["refinements"].append(f"✓ Found {len(reports)} reports for org name")
                    else:
                        all_findings["refinements"].append(f"⚠️  No reports for org name '{org_name}'")
                except Exception as e:
                    all_findings["refinements"].append(f"✗ Org reports search error: {str(e)[:50]}")

        # Print refinement summary
        print(f"[GTI Specialist]     Refinements attempted: {len(all_findings['refinements'])}")
        for ref in all_findings["refinements"][:5]:  # Show first 5
            print(f"[GTI Specialist]       {ref}")

        return {
            "domains": all_findings["domains"],
            "threat_actors": all_findings["threat_actors"],
            "intelligence_reports": all_findings.get("intelligence_reports", []),
            "collections": all_findings.get("collections", []),
            "pass_summary": {
                "pass": pass_number,
                "strategy": f"Pass {pass_number}: Adaptive refinement",
                "queries_planned": all_findings["refinements"],
                "results": {
                    "domains": len(all_findings["domains"]),
                    "threat_actors": len(all_findings["threat_actors"]),
                    "intelligence_reports": len(all_findings.get("intelligence_reports", [])),
                    "collections": len(all_findings.get("collections", []))
                }
            }
        }

    except Exception as e:
        print(f"[GTI Specialist]   ✗ Pass {pass_number} failed: {e}")
        import traceback
        traceback.print_exc()
        return {
            "domains": [],
            "threat_actors": [],
            "intelligence_reports": [],
            "collections": [],
            "pass_summary": {"pass": pass_number, "error": str(e)}
        }


def _deduplicate_domains(domains: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove duplicate domain entries"""
    seen = set()
    unique = []
    for item in domains:
        domain = item.get("domain", "")
        if domain and domain not in seen:
            seen.add(domain)
            unique.append(item)
    return unique


def _deduplicate_actors(actors: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove duplicate threat actor entries"""
    seen = set()
    unique = []
    for item in actors:
        actor_id = item.get("id", "") or item.get("name", "")
        if actor_id and actor_id not in seen:
            seen.add(actor_id)
            unique.append(item)
    return unique


async def _fallback_collection(org_profile: Dict[str, Any]) -> Dict[str, Any]:
    """Fallback if agent fails"""
    print("[GTI Specialist] Using fallback collection...")
    return await google_ti.search_all(org_profile)
