"""
Google Secret Manager integration for CTI Priority Intelligence

Fetches secrets using gcloud auth context - no credentials on disk required
"""

import os
from typing import Dict, Optional
from google.cloud import secretmanager
from functools import lru_cache


class SecretManager:
    """
    Fetch secrets from Google Secret Manager using gcloud auth context

    No environment variables or credential files needed - uses ADC
    (Application Default Credentials) from gcloud auth login
    """

    def __init__(self, project_id: Optional[str] = None):
        """
        Initialize Secret Manager client

        Args:
            project_id: GCP project ID. If None, reads from GOOGLE_CLOUD_PROJECT env
                       or gcloud config
        """
        self.project_id = project_id or os.environ.get("GOOGLE_CLOUD_PROJECT")

        if not self.project_id:
            raise ValueError(
                "Project ID not found. Either:\n"
                "  1. Set GOOGLE_CLOUD_PROJECT env var\n"
                "  2. Run: gcloud config set project YOUR_PROJECT_ID\n"
                "  3. Pass project_id to SecretManager()"
            )

        # Create client using Application Default Credentials (gcloud auth)
        self.client = secretmanager.SecretManagerServiceClient()

        # Secret name mappings with proper prefix
        self.secret_names = {
            "GTI_API_KEY": "adk-cti-priority-gti-api-key",
            "FP_API_KEY": "adk-cti-priority-flashpoint-api-key",
            "CS_CLIENT_ID": "adk-cti-priority-crowdstrike-client-id",
            "CS_CLIENT_SECRET": "adk-cti-priority-crowdstrike-client-secret",
        }

    @lru_cache(maxsize=16)
    def get_secret(self, secret_name: str, version: str = "latest") -> str:
        """
        Get secret value from Google Secret Manager

        Results are cached in memory for performance

        Args:
            secret_name: Name of the secret in GSM (e.g., "cti-gti-api-key")
            version: Secret version (default: "latest")

        Returns:
            Secret value as string

        Raises:
            Exception: If secret not found or permission denied
        """
        # Build resource name
        name = f"projects/{self.project_id}/secrets/{secret_name}/versions/{version}"

        try:
            # Access secret
            response = self.client.access_secret_version(request={"name": name})
            secret_value = response.payload.data.decode("UTF-8")
            return secret_value

        except Exception as e:
            raise Exception(
                f"Failed to access secret '{secret_name}':\n"
                f"  Error: {str(e)}\n"
                f"  Ensure:\n"
                f"    1. You're authenticated: gcloud auth login\n"
                f"    2. Secret exists: gcloud secrets list --project={self.project_id}\n"
                f"    3. You have access: roles/secretmanager.secretAccessor\n"
            )

    def get_all_secrets(self) -> Dict[str, str]:
        """
        Get all CTI-related secrets

        All secrets are optional - system will fall back to OSINT if missing

        Returns:
            Dict mapping env var name to secret value
            Example: {"GTI_API_KEY": "abc123...", "FP_API_KEY": None}
        """
        secrets = {}

        for env_var, secret_name in self.secret_names.items():
            try:
                secrets[env_var] = self.get_secret(secret_name)
            except Exception as e:
                # All API keys are optional - graceful degradation
                source_name = {
                    "GTI_API_KEY": "Google Threat Intelligence",
                    "FP_API_KEY": "Flashpoint",
                    "CS_CLIENT_ID": "CrowdStrike",
                    "CS_CLIENT_SECRET": "CrowdStrike"
                }.get(env_var, env_var)

                print(f"  ⚠️  {source_name} API key not found (will skip this source)")
                secrets[env_var] = None

        return secrets

    def set_env_vars(self) -> None:
        """
        Fetch all secrets and set as environment variables

        This allows the rest of the app to access secrets via os.environ
        """
        secrets = self.get_all_secrets()

        for key, value in secrets.items():
            if value is not None:
                os.environ[key] = value

        print("✓ Secrets loaded from Google Secret Manager")

    def validate_secrets(self) -> bool:
        """
        Validate that at least OSINT is available (always true)

        Returns:
            True (system always works with OSINT fallback)
        """
        try:
            secrets = self.get_all_secrets()

            available = [key for key in secrets.keys() if secrets.get(key)]

            if not available:
                print("  ⚠️  No API keys found - will use OSINT sources only")
            else:
                source_names = {
                    "GTI_API_KEY": "GTI",
                    "FP_API_KEY": "Flashpoint",
                    "CS_CLIENT_ID": "CrowdStrike"
                }
                enabled = [source_names.get(k, k) for k in available if k in source_names]
                print(f"  ✓ Available sources: {', '.join(enabled)}, OSINT")

            return True

        except Exception as e:
            print(f"  ⚠️  Secret check warning: {e}")
            print("  Will proceed with OSINT only")
            return True


# Convenience function for easy import
def load_secrets_from_gsm(project_id: Optional[str] = None) -> SecretManager:
    """
    Load secrets from Google Secret Manager and set as env vars

    Args:
        project_id: Optional GCP project ID

    Returns:
        SecretManager instance

    Usage:
        from cti_agent.config.secrets import load_secrets_from_gsm

        # Load secrets (uses gcloud auth context)
        sm = load_secrets_from_gsm()

        # Now access via environment
        gti_key = os.environ["GTI_API_KEY"]
    """
    sm = SecretManager(project_id)
    sm.set_env_vars()
    return sm
