"""
Configuration loader for CTI Priority Intelligence

Loads settings from config.yaml
"""

import os
import yaml
from pathlib import Path
from typing import Dict, Any, List


class Settings:
    """Application settings loaded from config.yaml"""

    def __init__(self, config_path: str = "config.yaml"):
        """Load configuration from YAML file"""
        config_file = Path(config_path)
        if not config_file.exists():
            raise FileNotFoundError(
                f"Config file not found: {config_path}\n"
                f"  This file should exist in the project root.\n"
                f"  If you're missing it, check the project README or restore from backup."
            )

        try:
            with open(config_file) as f:
                self.config = yaml.safe_load(f)
                if self.config is None:
                    raise ValueError("Config file is empty")
        except yaml.YAMLError as e:
            raise ValueError(
                f"Invalid YAML in config file: {config_path}\n"
                f"  Error: {e}\n"
                f"  Fix the YAML syntax and try again."
            )

    # Organization settings
    @property
    def default_organization(self) -> Dict[str, Any]:
        """Get default organization profile"""
        return self.config.get("organization", {})

    # OSINT sources
    @property
    def osint_news_feeds(self) -> List[Dict]:
        """Get enabled news feed sources"""
        feeds = self.config.get("osint_sources", {}).get("news_feeds", [])
        return [f for f in feeds if f.get("enabled", True)]

    @property
    def osint_custom_sites(self) -> List[Dict]:
        """Get enabled custom sites to crawl"""
        sites = self.config.get("osint_sources", {}).get("custom_sites", [])
        return [s for s in sites if s.get("enabled", False)]

    @property
    def osint_advisories(self) -> List[Dict]:
        """Get enabled security advisory sources"""
        advisories = self.config.get("osint_sources", {}).get("advisories", [])
        return [a for a in advisories if a.get("enabled", True)]

    # Intelligence sources
    @property
    def intelligence_sources(self) -> Dict[str, Any]:
        """Get intelligence source configurations"""
        return self.config.get("intelligence_sources", {})

    def get_source_priority(self, source_name: str) -> int:
        """Get priority for intelligence source (lower = higher priority)"""
        source = self.intelligence_sources.get(source_name, {})
        return source.get("priority", 999)

    # Model configurations
    @property
    def model_orchestrator(self) -> Dict[str, Any]:
        """Get orchestrator model config"""
        return self.config.get("models", {}).get("orchestrator", {
            "name": "gemini-2.5-pro",
            "temperature": 0.2
        })

    @property
    def model_collectors(self) -> Dict[str, Any]:
        """Get collector model config"""
        return self.config.get("models", {}).get("collectors", {
            "name": "gemini-2.5-flash",
            "temperature": 0.3
        })

    @property
    def model_correlator(self) -> Dict[str, Any]:
        """Get correlator/analyzer model config"""
        return self.config.get("models", {}).get("correlator", {
            "name": "gemini-2.5-pro",
            "temperature": 0.2
        })

    @property
    def model_report_generator(self) -> Dict[str, Any]:
        """Get report generator model config"""
        return self.config.get("models", {}).get("report_generator", {
            "name": "gemini-2.5-flash",
            "temperature": 0.4
        })

    # Performance settings
    @property
    def max_concurrent_collectors(self) -> int:
        """Max concurrent collection tasks"""
        return self.config.get("performance", {}).get("max_concurrent_collectors", 5)

    @property
    def inter_agent_delay(self) -> float:
        """Delay between agent calls (seconds)"""
        return self.config.get("performance", {}).get("inter_agent_delay_seconds", 3.0)

    @property
    def regions_enabled(self) -> bool:
        """Is region rotation enabled?"""
        return self.config.get("performance", {}).get("region_rotation", {}).get("enabled", True)

    # Report settings
    @property
    def report_format(self) -> str:
        """Report output format"""
        return self.config.get("report", {}).get("format", "html")

    @property
    def report_output_dir(self) -> str:
        """Report output directory"""
        return self.config.get("report", {}).get("output_directory", "output")

    @property
    def report_save_historical(self) -> bool:
        """Save historical reports?"""
        return self.config.get("report", {}).get("save_historical", True)

    # Security settings
    @property
    def respect_robots_txt(self) -> bool:
        """Respect robots.txt when scraping?"""
        return self.config.get("security", {}).get("respect_robots_txt", True)

    @property
    def sanitize_outputs(self) -> bool:
        """Sanitize outputs for security?"""
        return self.config.get("security", {}).get("sanitize_outputs", True)


# Global settings instance
_settings = None

def load_settings(config_path: str = "config.yaml") -> Settings:
    """Load settings from config file"""
    global _settings
    _settings = Settings(config_path)
    return _settings

def get_settings() -> Settings:
    """Get current settings instance"""
    global _settings
    if _settings is None:
        _settings = load_settings()
    return _settings
