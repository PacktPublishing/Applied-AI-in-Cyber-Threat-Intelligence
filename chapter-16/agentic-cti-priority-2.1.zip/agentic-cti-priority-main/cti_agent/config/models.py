"""
Gemini model configurations for CTI Priority Intelligence
"""

from google.genai import types


# Retry configurations for quota management
AGGRESSIVE_RETRY_CONFIG = types.HttpOptions(
    retry_options=types.HttpRetryOptions(
        initial_delay=15,
        attempts=6,
        exp_base=6,
        max_delay=92,
        http_status_codes=[429, 500, 503, 504]
    )
)

FLASH_RETRY_CONFIG = types.HttpOptions(
    retry_options=types.HttpRetryOptions(
        initial_delay=8,
        attempts=4,
        exp_base=3,
        max_delay=72,
        http_status_codes=[429, 500, 503, 504]
    )
)


# Model configurations
MODELS = {
    'flash': {
        'name': 'gemini-2.5-flash',
        'retry_config': FLASH_RETRY_CONFIG,
        'default_temp': 0.3,
        'use_for': ['collection', 'enrichment', 'reporting']
    },
    'pro': {
        'name': 'gemini-2.5-pro',
        'retry_config': AGGRESSIVE_RETRY_CONFIG,
        'default_temp': 0.2,
        'use_for': ['orchestration', 'analysis', 'correlation']
    }
}


def get_model_config(model_type: str = 'flash') -> dict:
    """
    Get model configuration by type

    Args:
        model_type: 'flash' or 'pro'

    Returns:
        Model configuration dict
    """
    return MODELS.get(model_type, MODELS['flash'])


# Safety settings (block only high danger)
SAFETY_SETTINGS = types.SafetySettings(
    dangerous_content=types.SafetyBlockThreshold.BLOCK_ONLY_HIGH
)
