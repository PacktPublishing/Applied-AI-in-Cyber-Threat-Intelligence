"""
GCP Region Rotation for Vertex AI Quota Management

Distributes Gemini API calls across 8 regions to avoid quota exhaustion
"""

from datetime import datetime
from typing import List


# 8 GCP regions with Vertex AI Gemini support
VERTEX_REGIONS: List[str] = [
    "global",
    "us-central1",
    "us-east5",
    "us-south1",
    "us-west4",
    "us-east1",
    "us-east4",
    "us-west1"
]


def select_region() -> str:
    """
    Select region using round-robin based on current UTC hour

    Rotates through 8 regions, giving 8x quota capacity
    Same region used for ~1 hour before rotating

    Returns:
        Region name (e.g., "us-central1")

    Example rotation:
        Hour 00, 08, 16 UTC → global
        Hour 01, 09, 17 UTC → us-central1
        Hour 02, 10, 18 UTC → us-east5
        ...and so on
    """
    current_hour = datetime.utcnow().hour
    region_index = current_hour % len(VERTEX_REGIONS)
    return VERTEX_REGIONS[region_index]


def get_all_regions() -> List[str]:
    """
    Get list of all available regions

    Returns:
        List of region names
    """
    return VERTEX_REGIONS.copy()


# For testing/debugging
if __name__ == "__main__":
    print(f"Current region: {select_region()}")
    print(f"All regions: {get_all_regions()}")

    # Show rotation schedule
    print("\nRotation schedule (by UTC hour):")
    for hour in range(24):
        region = VERTEX_REGIONS[hour % len(VERTEX_REGIONS)]
        print(f"  Hour {hour:02d}: {region}")
