"""
CrowdStrike Falcon tools

Simple falconpy SDK wrappers for threat intelligence
Read-only operations

API Documentation & Validation:
All APIs use official FalconPy SDK (https://github.com/CrowdStrike/falconpy)

Modules implemented:
1. Intel - Threat Intelligence (query_indicator_entities, query_actor_entities, get_indicator_relationships)
   Docs: https://falcon.crowdstrike.com/documentation/45/crowdstrike-intelligence-apis

2. Spotlight - Vulnerability Management (queryVulnerabilities)
   Docs: https://falcon.crowdstrike.com/documentation/98/spotlight-apis

3. DriftIndicators - SSPM/Shield - SaaS Security Posture (query_drift_indicators)
   Docs: https://falcon.crowdstrike.com/documentation/210/drift-indicators-apis

4. Discover - Attack Surface Management/ASM (query_hosts)
   Docs: https://falcon.crowdstrike.com/documentation/93/discover-apis

5. IdentityProtection - Identity risks (api_preempt_proxy_post_graphql)
   Docs: https://falcon.crowdstrike.com/documentation/278/identity-protection-apis

6. Hosts - Falcon Endpoint Intelligence (QueryDevicesByFilter)
   Docs: https://falcon.crowdstrike.com/documentation/84/host-and-host-group-management-apis

7. Incidents - Security Incidents (query_incidents, get_incident_details)
   Docs: https://falcon.crowdstrike.com/documentation/86/incidents-apis

8. IOC - Custom Indicators of Compromise (query_ioc_devices_count, query_iocs)
   Docs: https://falcon.crowdstrike.com/documentation/74/custom-ioc-apis

9. MalQuery - Malware Sample Search (exact_search, hunt)
   Docs: https://falcon.crowdstrike.com/documentation/99/malquery-apis

10. ThreatGraph - Indicator relationships and correlations (via Intel.get_indicator_relationships)
    Docs: https://falcon.crowdstrike.com/documentation/45/crowdstrike-intelligence-apis

All methods validated against FalconPy SDK v1.4+ (see validate_falcon_apis.py)
"""

import os
import asyncio
from typing import Dict, List, Optional, Any
from falconpy import Intel, SpotlightVulnerabilities, Discover, IdentityProtection, Hosts, Incidents, IOC, MalQuery, DriftIndicators
from ._rate_limiter import rate_limit_crowdstrike
from ._retry import retry_async
from ._time_utils import TIME_RANGES, add_recency_score, format_trend_summary
from ._api_tracker import log_api_call


def get_credentials() -> tuple:
    """
    Get CrowdStrike API credentials from environment

    Returns:
        Tuple of (client_id, client_secret)

    Raises:
        ValueError: If credentials not found
    """
    client_id = os.environ.get("CS_CLIENT_ID")
    client_secret = os.environ.get("CS_CLIENT_SECRET")

    if not client_id or not client_secret:
        raise ValueError(
            "CrowdStrike credentials not found in environment.\n"
            "Required: CS_CLIENT_ID, CS_CLIENT_SECRET\n"
            "Run: gcloud auth login\n"
            "Secrets should be loaded from GSM automatically."
        )

    return client_id, client_secret


@retry_async("crowdstrike")
async def search_indicators(query: str, limit: int = 100) -> List[Dict[str, Any]]:
    """
    Search CrowdStrike Intelligence for indicators

    Args:
        query: Search query (domain, IP, etc.)
        limit: Max results

    Returns:
        List of indicator dicts

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_crowdstrike()

    client_id, client_secret = get_credentials()

    # Initialize Falcon Intel client
    falcon = Intel(client_id=client_id, client_secret=client_secret)

    try:
        # Query indicators (read-only) - use correct SDK method name
        response = await asyncio.to_thread(
            falcon.query_indicator_entities,
            q=query,
            limit=limit
        )

        # Validate response is a dict before accessing fields
        if not isinstance(response, dict):
            error_msg = f"Invalid response type: {type(response)}"
            log_api_call(
                source="crowdstrike",
                module="intel",
                operation="search_indicators",
                query=query,
                status="error",
                error=error_msg,
                endpoint="/intel/combined/indicators/v1"
            )
            raise Exception(f"CrowdStrike returned invalid response type: {type(response)}")

        status_code = response.get('status_code', 'UNKNOWN')
        if status_code != 200:
            error_msg = f"Status {status_code}"
            log_api_call(
                source="crowdstrike",
                module="intel",
                operation="search_indicators",
                query=query,
                status="error",
                error=error_msg,
                error_code=str(status_code),
                endpoint="/intel/combined/indicators/v1"
            )
            raise Exception(f"CrowdStrike API error: status {status_code}")

        indicators = []
        for resource in response.get('body', {}).get('resources', []):
            indicators.append({
                "indicator": resource.get('indicator', ''),
                "type": resource.get('type', ''),
                "malicious_confidence": resource.get('malicious_confidence', ''),
                "published_date": resource.get('published_date', ''),
                "labels": resource.get('labels', []),
                "threat_types": resource.get('threat_types', []),
                "source": "crowdstrike"
            })

        # Log successful query
        log_api_call(
            source="crowdstrike",
            module="intel",
            operation="search_indicators",
            query=query,
            status="success",
            result_count=len(indicators),
            endpoint="/intel/combined/indicators/v1"
        )

        return indicators

    except Exception as e:
        # Log error if not already logged
        if "status" not in str(e):
            log_api_call(
                source="crowdstrike",
                module="intel",
                operation="search_indicators",
                query=query,
                status="error",
                error=str(e),
                endpoint="/intel/combined/indicators/v1"
            )
        raise


@retry_async("crowdstrike")
async def search_actors(query: str, limit: int = 50) -> List[Dict[str, Any]]:
    """
    Search for threat actors in CrowdStrike Intelligence

    Args:
        query: Search query (org, industry, etc.)
        limit: Max results

    Returns:
        List of threat actor dicts

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_crowdstrike()

    client_id, client_secret = get_credentials()
    falcon = Intel(client_id=client_id, client_secret=client_secret)

    try:
        # Query threat actors (read-only) - use correct SDK method name
        response = await asyncio.to_thread(
            falcon.query_actor_entities,
            q=query,
            limit=limit
        )

        if response['status_code'] != 200:
            error_msg = f"Status {response['status_code']}"
            log_api_call(
                source="crowdstrike",
                module="intel",
                operation="search_actors",
                query=query,
                status="error",
                error=error_msg,
                error_code=str(response['status_code']),
                endpoint="/intel/combined/actors/v1"
            )
            raise Exception(f"CrowdStrike API error: status {response['status_code']}")

        actors = []
        for resource in response.get('body', {}).get('resources', []):
            actors.append({
                "name": resource.get('name', ''),
                "short_description": resource.get('short_description', ''),
                "known_as": resource.get('known_as', ''),
                "target_countries": resource.get('target_countries', []),
                "target_industries": resource.get('target_industries', []),
                "origins": resource.get('origins', []),
                "motivations": resource.get('motivations', []),
                "first_activity_date": resource.get('first_activity_date', ''),
                "last_activity_date": resource.get('last_activity_date', ''),
                "source": "crowdstrike"
            })

        # Log successful query
        log_api_call(
            source="crowdstrike",
            module="intel",
            operation="search_actors",
            query=query,
            status="success",
            result_count=len(actors),
            endpoint="/intel/combined/actors/v1"
        )

        return actors

    except Exception as e:
        # Log error if not already logged
        if "status" not in str(e):
            log_api_call(
                source="crowdstrike",
                module="intel",
                operation="search_actors",
                query=query,
                status="error",
                error=str(e),
                endpoint="/intel/combined/actors/v1"
            )
        raise


@retry_async("crowdstrike")
async def search_spotlight_vulnerabilities(query: str, limit: int = 100) -> List[Dict[str, Any]]:
    """
    Search CrowdStrike Spotlight for vulnerabilities (CVEs)

    Args:
        query: Search query (domain, product, etc.)
        limit: Max results

    Returns:
        List of vulnerability dicts

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_crowdstrike()

    client_id, client_secret = get_credentials()

    falcon = SpotlightVulnerabilities(client_id=client_id, client_secret=client_secret)

    try:
        # Query vulnerabilities
        response = await asyncio.to_thread(
            falcon.queryVulnerabilities,
            filter=f"cve.id:*'{query}'*",
            limit=limit
        )

        if not isinstance(response, dict):
            error_msg = f"Invalid response type: {type(response)}"
            log_api_call(
                source="crowdstrike",
                module="spotlight",
                operation="search_vulnerabilities",
                query=query,
                status="error",
                error=error_msg,
                endpoint="/spotlight/combined/vulnerabilities/v1"
            )
            raise Exception(f"CrowdStrike Spotlight returned invalid response type: {type(response)}")

        status_code = response.get('status_code', 'UNKNOWN')
        if status_code != 200:
            error_msg = f"Status {status_code}"
            log_api_call(
                source="crowdstrike",
                module="spotlight",
                operation="search_vulnerabilities",
                query=query,
                status="error",
                error=error_msg,
                error_code=str(status_code),
                endpoint="/spotlight/combined/vulnerabilities/v1"
            )
            raise Exception(f"CrowdStrike Spotlight API error: status {status_code}")

        vulnerabilities = []
        for resource in response.get('body', {}).get('resources', []):
            vulnerabilities.append({
                "cve_id": resource.get('cve', {}).get('id', ''),
                "description": resource.get('cve', {}).get('description', ''),
                "severity": resource.get('cve', {}).get('base_score', 0),
                "published_date": resource.get('cve', {}).get('published_date', ''),
                "remediation": resource.get('remediation', ''),
                "exploited": resource.get('cve', {}).get('exploit_status', 0) > 0,
                "source": "crowdstrike"
            })

        log_api_call(
            source="crowdstrike",
            module="spotlight",
            operation="search_vulnerabilities",
            query=query,
            status="success",
            result_count=len(vulnerabilities),
            endpoint="/spotlight/combined/vulnerabilities/v1"
        )

        return vulnerabilities

    except Exception as e:
        if "status" not in str(e):
            log_api_call(
                source="crowdstrike",
                module="spotlight",
                operation="search_vulnerabilities",
                query=query,
                status="error",
                error=str(e),
                endpoint="/spotlight/combined/vulnerabilities/v1"
            )
        raise


@retry_async("crowdstrike")
async def search_asm_assets(query: str, limit: int = 100) -> List[Dict[str, Any]]:
    """
    Search CrowdStrike ASM (Attack Surface Management) for external assets

    Args:
        query: Search query (domain, etc.)
        limit: Max results

    Returns:
        List of external asset dicts

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_crowdstrike()

    client_id, client_secret = get_credentials()

    falcon = Discover(client_id=client_id, client_secret=client_secret)

    try:
        # Query external assets
        # Use exact hostname match (wildcards may not be supported)
        response = await asyncio.to_thread(
            falcon.query_hosts,
            filter=f"hostname:'{query}'",
            limit=limit
        )

        if not isinstance(response, dict):
            error_msg = f"Invalid response type: {type(response)}"
            log_api_call(
                source="crowdstrike",
                module="asm",
                operation="search_assets",
                query=query,
                status="error",
                error=error_msg,
                endpoint="/discover/queries/hosts/v1"
            )
            raise Exception(f"CrowdStrike ASM returned invalid response type: {type(response)}")

        status_code = response.get('status_code', 'UNKNOWN')
        if status_code != 200:
            error_msg = f"Status {status_code}"
            log_api_call(
                source="crowdstrike",
                module="asm",
                operation="search_assets",
                query=query,
                status="error",
                error=error_msg,
                error_code=str(status_code),
                endpoint="/discover/queries/hosts/v1"
            )
            raise Exception(f"CrowdStrike ASM API error: status {status_code}")

        assets = []
        for resource in response.get('body', {}).get('resources', []):
            assets.append({
                "hostname": resource.get('hostname', ''),
                "ip_addresses": resource.get('external_ip', []),
                "risk_score": resource.get('risk_score', 0),
                "last_seen": resource.get('last_seen_timestamp', ''),
                "services": resource.get('services', []),
                "source": "crowdstrike"
            })

        log_api_call(
            source="crowdstrike",
            module="asm",
            operation="search_assets",
            query=query,
            status="success",
            result_count=len(assets),
            endpoint="/discover/queries/hosts/v1"
        )

        return assets

    except Exception as e:
        if "status" not in str(e):
            log_api_call(
                source="crowdstrike",
                module="asm",
                operation="search_assets",
                query=query,
                status="error",
                error=str(e),
                endpoint="/discover/queries/hosts/v1"
            )
        raise


@retry_async("crowdstrike")
async def search_identity_risks(query: str, limit: int = 100) -> List[Dict[str, Any]]:
    """
    Search CrowdStrike Identity Protection for identity risks

    Args:
        query: Search query (domain, user, etc.)
        limit: Max results

    Returns:
        List of identity risk dicts

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_crowdstrike()

    client_id, client_secret = get_credentials()

    falcon = IdentityProtection(client_id=client_id, client_secret=client_secret)

    try:
        # Query identity risks using GraphQL endpoint
        # GraphQL query to find identity risks
        graphql_query = """
        query IdentityRisks($filter: String!) {
            identity_risks(filter: $filter, limit: %d) {
                user_name
                risk_score
                risk_factors
                timestamp
                is_compromised
            }
        }
        """ % limit

        response = await asyncio.to_thread(
            falcon.api_preempt_proxy_post_graphql,
            body={"query": graphql_query, "variables": {"filter": query}}
        )

        if not isinstance(response, dict):
            error_msg = f"Invalid response type: {type(response)}"
            log_api_call(
                source="crowdstrike",
                module="identity",
                operation="search_identity_risks",
                query=query,
                status="error",
                error=error_msg,
                endpoint="/identity-protection/combined/graphql/v1"
            )
            raise Exception(f"CrowdStrike Identity returned invalid response type: {type(response)}")

        status_code = response.get('status_code', 'UNKNOWN')
        if status_code != 200:
            error_msg = f"Status {status_code}"
            log_api_call(
                source="crowdstrike",
                module="identity",
                operation="search_identity_risks",
                query=query,
                status="error",
                error=error_msg,
                error_code=str(status_code),
                endpoint="/identity-protection/combined/graphql/v1"
            )
            raise Exception(f"CrowdStrike Identity API error: status {status_code}")

        risks = []
        for resource in response.get('body', {}).get('resources', []):
            risks.append({
                "user": resource.get('user_name', ''),
                "risk_score": resource.get('risk_score', 0),
                "risk_factors": resource.get('risk_factors', []),
                "last_activity": resource.get('timestamp', ''),
                "compromised": resource.get('is_compromised', False),
                "source": "crowdstrike"
            })

        log_api_call(
            source="crowdstrike",
            module="identity",
            operation="search_identity_risks",
            query=query,
            status="success",
            result_count=len(risks),
            endpoint="/identity-protection/combined/graphql/v1"
        )

        return risks

    except Exception as e:
        if "status" not in str(e):
            log_api_call(
                source="crowdstrike",
                module="identity",
                operation="search_identity_risks",
                query=query,
                status="error",
                error=str(e),
                endpoint="/identity-protection/combined/graphql/v1"
            )
        raise


@retry_async("crowdstrike")
async def search_falcon_detections(query: str, limit: int = 100) -> List[Dict[str, Any]]:
    """
    Search CrowdStrike Falcon for endpoint detections

    Args:
        query: Search query (hostname, domain, etc.)
        limit: Max results

    Returns:
        List of detection dicts

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_crowdstrike()

    client_id, client_secret = get_credentials()

    falcon = Hosts(client_id=client_id, client_secret=client_secret)

    try:
        # Query hosts for detections
        # Use exact hostname match (wildcards may not be supported)
        response = await asyncio.to_thread(
            falcon.QueryDevicesByFilter,
            filter=f"hostname:'{query}'",
            limit=limit
        )

        if not isinstance(response, dict):
            error_msg = f"Invalid response type: {type(response)}"
            log_api_call(
                source="crowdstrike",
                module="falcon",
                operation="search_detections",
                query=query,
                status="error",
                error=error_msg,
                endpoint="/devices/queries/devices/v1"
            )
            raise Exception(f"CrowdStrike Falcon returned invalid response type: {type(response)}")

        status_code = response.get('status_code', 'UNKNOWN')
        if status_code != 200:
            error_msg = f"Status {status_code}"
            log_api_call(
                source="crowdstrike",
                module="falcon",
                operation="search_detections",
                query=query,
                status="error",
                error=error_msg,
                error_code=str(status_code),
                endpoint="/devices/queries/devices/v1"
            )
            raise Exception(f"CrowdStrike Falcon API error: status {status_code}")

        detections = []
        for resource in response.get('body', {}).get('resources', []):
            detections.append({
                "hostname": resource.get('hostname', ''),
                "local_ip": resource.get('local_ip', ''),
                "os_version": resource.get('os_version', ''),
                "status": resource.get('status', ''),
                "last_seen": resource.get('last_seen', ''),
                "tags": resource.get('tags', []),
                "source": "crowdstrike"
            })

        log_api_call(
            source="crowdstrike",
            module="falcon",
            operation="search_detections",
            query=query,
            status="success",
            result_count=len(detections),
            endpoint="/devices/queries/devices/v1"
        )

        return detections

    except Exception as e:
        if "status" not in str(e):
            log_api_call(
                source="crowdstrike",
                module="falcon",
                operation="search_detections",
                query=query,
                status="error",
                error=str(e),
                endpoint="/devices/queries/devices/v1"
            )
        raise


@retry_async("crowdstrike")
async def search_sspm_misconfigurations(query: str, limit: int = 100) -> List[Dict[str, Any]]:
    """
    Search CrowdStrike SSPM/Shield for SaaS misconfigurations and drift

    Args:
        query: Search query (domain, cloud app, etc.)
        limit: Max results

    Returns:
        List of misconfiguration/drift dicts

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_crowdstrike()

    client_id, client_secret = get_credentials()

    falcon = DriftIndicators(client_id=client_id, client_secret=client_secret)

    try:
        # Query drift indicators (SaaS misconfigurations)
        response = await asyncio.to_thread(
            falcon.query_drift_indicators,
            filter=f"cloud_provider:*+,indicator_value:*'{query}'*",
            limit=limit,
            sort="created_timestamp.desc"
        )

        if not isinstance(response, dict):
            error_msg = f"Invalid response type: {type(response)}"
            log_api_call(
                source="crowdstrike",
                module="sspm",
                operation="search_misconfigurations",
                query=query,
                status="error",
                error=error_msg,
                endpoint="/indicators/queries/drift-indicators/v1"
            )
            raise Exception(f"CrowdStrike SSPM returned invalid response type: {type(response)}")

        status_code = response.get('status_code', 'UNKNOWN')
        if status_code != 200:
            error_msg = f"Status {status_code}"
            log_api_call(
                source="crowdstrike",
                module="sspm",
                operation="search_misconfigurations",
                query=query,
                status="error",
                error=error_msg,
                error_code=str(status_code),
                endpoint="/indicators/queries/drift-indicators/v1"
            )
            raise Exception(f"CrowdStrike SSPM API error: status {status_code}")

        misconfigs = []
        for resource in response.get('body', {}).get('resources', []):
            misconfigs.append({
                "indicator_id": resource.get('id', ''),
                "cloud_provider": resource.get('cloud_provider', ''),
                "service_name": resource.get('service_name', ''),
                "resource_type": resource.get('resource_type', ''),
                "indicator_value": resource.get('indicator_value', ''),
                "severity": resource.get('severity', ''),
                "finding_type": resource.get('finding_type', ''),
                "remediation": resource.get('remediation', ''),
                "created_timestamp": resource.get('created_timestamp', ''),
                "source": "crowdstrike"
            })

        log_api_call(
            source="crowdstrike",
            module="sspm",
            operation="search_misconfigurations",
            query=query,
            status="success",
            result_count=len(misconfigs),
            endpoint="/indicators/queries/drift-indicators/v1"
        )

        return misconfigs

    except Exception as e:
        if "status" not in str(e):
            log_api_call(
                source="crowdstrike",
                module="sspm",
                operation="search_misconfigurations",
                query=query,
                status="error",
                error=str(e),
                endpoint="/indicators/queries/drift-indicators/v1"
            )
        raise


@retry_async("crowdstrike")
async def search_incidents(query: str, limit: int = 100) -> List[Dict[str, Any]]:
    """
    Search CrowdStrike Incidents for security events

    Args:
        query: Search query (domain, hostname, etc.)
        limit: Max results

    Returns:
        List of incident dicts

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_crowdstrike()

    client_id, client_secret = get_credentials()

    falcon = Incidents(client_id=client_id, client_secret=client_secret)

    try:
        # Query incidents
        response = await asyncio.to_thread(
            falcon.query_incidents,
            filter=f"host_name:*'{query}'*+,tactics:*",
            limit=limit,
            sort="created_time.desc"
        )

        if not isinstance(response, dict):
            error_msg = f"Invalid response type: {type(response)}"
            log_api_call(
                source="crowdstrike",
                module="incidents",
                operation="search_incidents",
                query=query,
                status="error",
                error=error_msg,
                endpoint="/incidents/queries/incidents/v1"
            )
            raise Exception(f"CrowdStrike Incidents returned invalid response type: {type(response)}")

        status_code = response.get('status_code', 'UNKNOWN')
        if status_code != 200:
            error_msg = f"Status {status_code}"
            log_api_call(
                source="crowdstrike",
                module="incidents",
                operation="search_incidents",
                query=query,
                status="error",
                error=error_msg,
                error_code=str(status_code),
                endpoint="/incidents/queries/incidents/v1"
            )
            raise Exception(f"CrowdStrike Incidents API error: status {status_code}")

        incidents = []
        for resource in response.get('body', {}).get('resources', []):
            incidents.append({
                "incident_id": resource.get('incident_id', ''),
                "name": resource.get('name', ''),
                "description": resource.get('description', ''),
                "status": resource.get('status', ''),
                "severity": resource.get('severity', 0),
                "tactics": resource.get('tactics', []),
                "techniques": resource.get('techniques', []),
                "hosts": resource.get('hosts', []),
                "created_time": resource.get('created_time', ''),
                "source": "crowdstrike"
            })

        log_api_call(
            source="crowdstrike",
            module="incidents",
            operation="search_incidents",
            query=query,
            status="success",
            result_count=len(incidents),
            endpoint="/incidents/queries/incidents/v1"
        )

        return incidents

    except Exception as e:
        if "status" not in str(e):
            log_api_call(
                source="crowdstrike",
                module="incidents",
                operation="search_incidents",
                query=query,
                status="error",
                error=str(e),
                endpoint="/incidents/queries/incidents/v1"
            )
        raise


@retry_async("crowdstrike")
async def search_custom_iocs(query: str, limit: int = 100) -> List[Dict[str, Any]]:
    """
    Search CrowdStrike Custom IOCs (Indicators of Compromise)

    Args:
        query: Search query (domain, IP, hash, etc.)
        limit: Max results

    Returns:
        List of custom IOC dicts with device counts

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_crowdstrike()

    client_id, client_secret = get_credentials()

    falcon = IOC(client_id=client_id, client_secret=client_secret)

    try:
        # Query custom IOCs
        # Use exact value match (wildcards may not be supported)
        response = await asyncio.to_thread(
            falcon.indicator_combined_v1,
            filter=f"value:'{query}'",
            limit=limit,
            sort="created_on.desc"
        )

        if not isinstance(response, dict):
            error_msg = f"Invalid response type: {type(response)}"
            log_api_call(
                source="crowdstrike",
                module="ioc",
                operation="search_custom_iocs",
                query=query,
                status="error",
                error=error_msg,
                endpoint="/iocs/combined/indicator/v1"
            )
            raise Exception(f"CrowdStrike IOC returned invalid response type: {type(response)}")

        status_code = response.get('status_code', 'UNKNOWN')
        if status_code != 200:
            error_msg = f"Status {status_code}"
            log_api_call(
                source="crowdstrike",
                module="ioc",
                operation="search_custom_iocs",
                query=query,
                status="error",
                error=error_msg,
                error_code=str(status_code),
                endpoint="/iocs/combined/indicator/v1"
            )
            raise Exception(f"CrowdStrike IOC API error: status {status_code}")

        iocs = []
        for resource in response.get('body', {}).get('resources', []):
            iocs.append({
                "ioc_id": resource.get('id', ''),
                "type": resource.get('type', ''),
                "value": resource.get('value', ''),
                "severity": resource.get('severity', ''),
                "platforms": resource.get('platforms', []),
                "action": resource.get('action', ''),
                "device_count": resource.get('device_count', 0),
                "created_on": resource.get('created_on', ''),
                "modified_on": resource.get('modified_on', ''),
                "source": "crowdstrike"
            })

        log_api_call(
            source="crowdstrike",
            module="ioc",
            operation="search_custom_iocs",
            query=query,
            status="success",
            result_count=len(iocs),
            endpoint="/iocs/combined/indicator/v1"
        )

        return iocs

    except Exception as e:
        if "status" not in str(e):
            log_api_call(
                source="crowdstrike",
                module="ioc",
                operation="search_custom_iocs",
                query=query,
                status="error",
                error=str(e),
                endpoint="/iocs/combined/indicator/v1"
            )
        raise


@retry_async("crowdstrike")
async def search_malquery_samples(query: str, limit: int = 50) -> List[Dict[str, Any]]:
    """
    Search MalQuery for malware samples related to query

    Args:
        query: Search query (hex pattern, yara rule, hash)
        limit: Max results

    Returns:
        List of malware sample dicts

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_crowdstrike()

    client_id, client_secret = get_credentials()

    falcon = MalQuery(client_id=client_id, client_secret=client_secret)

    try:
        # Exact search for malware samples
        # Note: MalQuery requires hex patterns or file metadata, not domain names
        # We'll search by file metadata that might contain the query string
        response = await asyncio.to_thread(
            falcon.exact_search,
            body={
                "options": {
                    "filter_meta": [f"*{query}*"],
                    "limit": limit
                }
            }
        )

        if not isinstance(response, dict):
            error_msg = f"Invalid response type: {type(response)}"
            log_api_call(
                source="crowdstrike",
                module="malquery",
                operation="search_samples",
                query=query,
                status="error",
                error=error_msg,
                endpoint="/malquery/combined/exact-search/v1"
            )
            raise Exception(f"CrowdStrike MalQuery returned invalid response type: {type(response)}")

        status_code = response.get('status_code', 'UNKNOWN')
        if status_code != 200:
            error_msg = f"Status {status_code}"
            log_api_call(
                source="crowdstrike",
                module="malquery",
                operation="search_samples",
                query=query,
                status="error",
                error=error_msg,
                error_code=str(status_code),
                endpoint="/malquery/combined/exact-search/v1"
            )
            raise Exception(f"CrowdStrike MalQuery API error: status {status_code}")

        samples = []
        for resource in response.get('body', {}).get('resources', []):
            samples.append({
                "sha256": resource.get('sha256', ''),
                "file_type": resource.get('file_type', ''),
                "file_size": resource.get('file_size', 0),
                "first_seen": resource.get('first_seen_timestamp', ''),
                "label": resource.get('label', ''),
                "family": resource.get('family', ''),
                "source": "crowdstrike"
            })

        log_api_call(
            source="crowdstrike",
            module="malquery",
            operation="search_samples",
            query=query,
            status="success",
            result_count=len(samples),
            endpoint="/malquery/combined/exact-search/v1"
        )

        return samples

    except Exception as e:
        if "status" not in str(e):
            log_api_call(
                source="crowdstrike",
                module="malquery",
                operation="search_samples",
                query=query,
                status="error",
                error=str(e),
                endpoint="/malquery/combined/exact-search/v1"
            )
        raise


@retry_async("crowdstrike")
async def get_indicator_relationships(indicator_value: str) -> Dict[str, Any]:
    """
    Get ThreatGraph relationships for an indicator (Falcon Indicator Graph)

    Args:
        indicator_value: Indicator value (domain, IP, hash) to get relationships for

    Returns:
        Dict with related indicators and actors

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_crowdstrike()

    client_id, client_secret = get_credentials()

    falcon = Intel(client_id=client_id, client_secret=client_secret)

    try:
        # Get indicator graph/relationships
        response = await asyncio.to_thread(
            falcon.query_indicator_entities,
            q=indicator_value,
            include_relations=True,
            limit=50
        )

        if not isinstance(response, dict):
            error_msg = f"Invalid response type: {type(response)}"
            log_api_call(
                source="crowdstrike",
                module="threatgraph",
                operation="get_relationships",
                query=indicator_value,
                status="error",
                error=error_msg,
                endpoint="/intel/combined/indicators/v1"
            )
            raise Exception(f"CrowdStrike ThreatGraph returned invalid response type: {type(response)}")

        status_code = response.get('status_code', 'UNKNOWN')
        if status_code != 200:
            error_msg = f"Status {status_code}"
            log_api_call(
                source="crowdstrike",
                module="threatgraph",
                operation="get_relationships",
                query=indicator_value,
                status="error",
                error=error_msg,
                error_code=str(status_code),
                endpoint="/intel/combined/indicators/v1"
            )
            raise Exception(f"CrowdStrike ThreatGraph API error: status {status_code}")

        # Extract relationships
        relationships = {
            "indicator": indicator_value,
            "related_indicators": [],
            "related_actors": [],
            "malware_families": [],
            "source": "crowdstrike"
        }

        for resource in response.get('body', {}).get('resources', []):
            # Get relations from the indicator
            relations = resource.get('relations', [])
            for relation in relations:
                rel_type = relation.get('type', '')
                if 'indicator' in rel_type.lower():
                    relationships["related_indicators"].append({
                        "value": relation.get('indicator', ''),
                        "type": relation.get('indicator_type', ''),
                        "relationship": rel_type
                    })
                elif 'actor' in rel_type.lower():
                    relationships["related_actors"].append({
                        "name": relation.get('actor', ''),
                        "relationship": rel_type
                    })
                elif 'malware' in rel_type.lower():
                    relationships["malware_families"].append(relation.get('malware_family', ''))

        log_api_call(
            source="crowdstrike",
            module="threatgraph",
            operation="get_relationships",
            query=indicator_value,
            status="success",
            result_count=len(relationships["related_indicators"]) + len(relationships["related_actors"]),
            endpoint="/intel/combined/indicators/v1"
        )

        return relationships

    except Exception as e:
        if "status" not in str(e):
            log_api_call(
                source="crowdstrike",
                module="threatgraph",
                operation="get_relationships",
                query=indicator_value,
                status="error",
                error=str(e),
                endpoint="/intel/combined/indicators/v1"
            )
        raise


async def search_all(org_profile: Dict[str, Any]) -> Dict[str, Any]:
    """
    Collect all CrowdStrike intelligence for organization

    Args:
        org_profile: Organization profile dict

    Returns:
        Combined intelligence from CrowdStrike
    """
    print("  [CrowdStrike] Collecting intelligence across ALL 10 modules...")

    # Extract search targets
    domains = org_profile.get("domains", [])
    org_name = org_profile.get("organization", "")
    industry = org_profile.get("industry", "")
    tech_stack = org_profile.get("technology_stack", [])
    saas_apps = org_profile.get("saas_applications", [])

    # PHASE 1: Initial parallel queries across ALL CrowdStrike modules
    tasks = []

    # 1. Intel - Indicator searches for domains
    for domain in domains[:3]:  # Limit to first 3 domains
        tasks.append(search_indicators(domain))

    # 2. Intel - Actor searches
    if org_name:
        tasks.append(search_actors(org_name))
    if industry:
        tasks.append(search_actors(industry))

    # 3. Spotlight - Vulnerability searches
    # NOTE: Spotlight API expects CVE IDs (e.g., "CVE-2024-1234"), not product names
    # We don't have CVE IDs to query, so skip Spotlight for now
    # TODO: Add CVE enrichment to org_profile to enable Spotlight queries
    pass

    # 4. SSPM/Shield - SaaS misconfigurations
    # NOTE: SSPM API expects cloud_provider and indicator_value filters
    # Current filter syntax doesn't support SaaS app name searches
    # Skip SSPM until we have proper cloud provider/indicator data
    # TODO: Add cloud asset discovery to enable SSPM queries
    pass

    # 5. ASM - Attack Surface Management
    # ASM Discover API uses hostname filter - use exact matches only (no wildcards)
    for domain in domains[:3]:
        tasks.append(search_asm_assets(domain))  # Exact hostname match

    # 6. Identity Protection - Identity risks (skip - needs user/identity data)
    # Identity Protection expects user emails or identity queries, not domains
    # Skip for now unless org_profile includes executive names or key personnel
    pass

    # 7. Falcon - Endpoint detections
    # Falcon API uses hostname filters - only query with domains
    for domain in domains[:3]:
        tasks.append(search_falcon_detections(domain))
    # Skip malware family names - Falcon filter expects hostnames, not detection names

    # 8. Incidents - Security events (skip - needs incident IDs or specific filters)
    # Incidents API expects incident IDs or date filters, not organization names
    # Skip generic queries
    pass

    # 9. Custom IOCs - Organization-specific indicators (domains only, not org names)
    # Custom IOCs expects actual IOCs - domains are valid, org names are not
    for domain in domains[:3]:
        tasks.append(search_custom_iocs(domain))

    print(f"  [CrowdStrike] Phase 1: Executing {len(tasks)} parallel queries across 10 modules...")

    # Execute initial queries in parallel
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # Organize Phase 1 results by type
    indicators = []
    threat_actors = []
    vulnerabilities = []
    sspm_misconfigs = []
    asm_assets = []
    identity_risks = []
    falcon_detections = []
    incidents = []
    custom_iocs = []

    for result in results:
        if isinstance(result, Exception):
            continue

        if isinstance(result, list):
            for item in result:
                if "indicator" in item and "type" not in item and "indicator_id" not in item:  # Intel indicators
                    indicators.append(item)
                elif "name" in item and "motivations" in item:  # Threat actors
                    threat_actors.append(item)
                elif "cve_id" in item:  # Spotlight vulnerabilities
                    vulnerabilities.append(item)
                elif "indicator_id" in item and "cloud_provider" in item:  # SSPM misconfigs
                    sspm_misconfigs.append(item)
                elif "hostname" in item and "risk_score" in item:  # ASM assets
                    asm_assets.append(item)
                elif "user" in item and "risk_factors" in item:  # Identity risks
                    identity_risks.append(item)
                elif "hostname" in item and "os_version" in item:  # Falcon detections
                    falcon_detections.append(item)
                elif "incident_id" in item:  # Incidents
                    incidents.append(item)
                elif "ioc_id" in item:  # Custom IOCs
                    custom_iocs.append(item)

    print(f"  [CrowdStrike] Phase 1 complete: {len(indicators)} indicators, {len(sspm_misconfigs)} SSPM, {len(custom_iocs)} IOCs, {len(incidents)} incidents")

    # PHASE 2: INTELLIGENT CORRELATION - Query ThreatGraph and MalQuery for top indicators
    correlation_tasks = []

    # Get ThreatGraph relationships for top 5 indicators
    top_indicators = sorted(indicators, key=lambda x: x.get('recency_score', 0), reverse=True)[:5]
    for indicator in top_indicators:
        indicator_value = indicator.get('indicator', '')
        if indicator_value:
            print(f"  [CrowdStrike] Phase 2: Getting ThreatGraph for '{indicator_value}'")
            correlation_tasks.append(get_indicator_relationships(indicator_value))

    # Search MalQuery for domains (if we have hash indicators, search those too)
    for domain in domains[:2]:
        print(f"  [CrowdStrike] Phase 2: MalQuery search for '{domain}'")
        correlation_tasks.append(search_malquery_samples(domain))

    # Execute correlation queries
    if correlation_tasks:
        print(f"  [CrowdStrike] Phase 2: Executing {len(correlation_tasks)} correlation queries...")
        correlation_results = await asyncio.gather(*correlation_tasks, return_exceptions=True)

        # Process correlation results
        threat_graph_relationships = []
        malquery_samples = []

        for result in correlation_results:
            if isinstance(result, Exception):
                continue

            if isinstance(result, dict):
                if "related_indicators" in result:  # ThreatGraph result
                    threat_graph_relationships.append(result)
            elif isinstance(result, list):
                for item in result:
                    if "sha256" in item:  # MalQuery result
                        malquery_samples.append(item)

        print(f"  [CrowdStrike] Phase 2 complete: {len(threat_graph_relationships)} graphs, {len(malquery_samples)} malware samples")

    # Add recency scoring to all results
    indicators = add_recency_score(indicators, "published_date")
    threat_actors = add_recency_score(threat_actors, "last_activity_date")
    vulnerabilities = add_recency_score(vulnerabilities, "published_date")
    sspm_misconfigs = add_recency_score(sspm_misconfigs, "created_timestamp")
    asm_assets = add_recency_score(asm_assets, "last_seen")
    identity_risks = add_recency_score(identity_risks, "last_activity")
    falcon_detections = add_recency_score(falcon_detections, "last_seen")
    incidents = add_recency_score(incidents, "created_time")
    custom_iocs = add_recency_score(custom_iocs, "created_on")

    print(f"  [CrowdStrike] ✓ Collected across ALL 10 modules + correlations:")
    print(f"    - {len(indicators)} indicators (Intel) {format_trend_summary(indicators, 'published_date')}")
    print(f"    - {len(threat_actors)} threat actors (Intel) {format_trend_summary(threat_actors, 'last_activity_date')}")
    print(f"    - {len(vulnerabilities)} vulnerabilities (Spotlight) {format_trend_summary(vulnerabilities, 'published_date')}")
    print(f"    - {len(sspm_misconfigs)} SaaS misconfigs (SSPM/Shield) {format_trend_summary(sspm_misconfigs, 'created_timestamp')}")
    print(f"    - {len(asm_assets)} external assets (ASM) {format_trend_summary(asm_assets, 'last_seen')}")
    print(f"    - {len(identity_risks)} identity risks (Identity) {format_trend_summary(identity_risks, 'last_activity')}")
    print(f"    - {len(falcon_detections)} endpoint findings (Falcon) {format_trend_summary(falcon_detections, 'last_seen')}")
    print(f"    - {len(incidents)} incidents {format_trend_summary(incidents, 'created_time')}")
    print(f"    - {len(custom_iocs)} custom IOCs {format_trend_summary(custom_iocs, 'created_on')}")
    if correlation_tasks:
        print(f"    - {len(threat_graph_relationships)} indicator graphs (ThreatGraph)")
        print(f"    - {len(malquery_samples)} malware samples (MalQuery)")

    return {
        "indicators": indicators,
        "threat_actors": threat_actors,
        "vulnerabilities": vulnerabilities,
        "sspm_misconfigs": sspm_misconfigs,
        "asm_assets": asm_assets,
        "identity_risks": identity_risks,
        "falcon_detections": falcon_detections,
        "incidents": incidents,
        "custom_iocs": custom_iocs,
        "threat_graph": threat_graph_relationships if correlation_tasks else [],
        "malquery_samples": malquery_samples if correlation_tasks else [],
        "source": "crowdstrike"
    }
