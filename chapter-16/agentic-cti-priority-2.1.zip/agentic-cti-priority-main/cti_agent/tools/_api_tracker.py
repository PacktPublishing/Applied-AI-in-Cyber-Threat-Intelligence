"""
API Query Tracker

Tracks all API queries, results, and errors for detailed reporting
"""

from typing import Dict, List, Any, Optional
from datetime import datetime
import threading


class APITracker:
    """Thread-safe tracker for API queries and results"""

    def __init__(self):
        self._lock = threading.Lock()
        self._queries: List[Dict[str, Any]] = []

    def log_query(
        self,
        source: str,
        module: str,
        operation: str,
        query: str,
        status: str,
        result_count: int = 0,
        error: Optional[str] = None,
        error_code: Optional[str] = None,
        endpoint: Optional[str] = None
    ):
        """
        Log an API query attempt

        Args:
            source: Source name (google_ti, flashpoint, crowdstrike, osint)
            module: Module/API name (intel, asm, sspm, spotlight, etc.)
            operation: Operation name (search_indicators, search_actors, etc.)
            query: Query string or identifier
            status: Status (success, error, partial, skipped)
            result_count: Number of results returned
            error: Error message if failed
            error_code: Error code (403, 404, 503, etc.)
            endpoint: API endpoint path (e.g., /intel/combined/indicators/v1)
        """
        with self._lock:
            self._queries.append({
                "timestamp": datetime.utcnow().isoformat(),
                "source": source,
                "module": module,
                "operation": operation,
                "query": query,
                "status": status,
                "result_count": result_count,
                "error": error,
                "error_code": error_code,
                "endpoint": endpoint
            })

    def get_summary(self) -> Dict[str, Any]:
        """
        Get summary of all API queries

        Returns:
            Summary dict with per-source and per-module breakdowns
        """
        with self._lock:
            summary = {
                "total_queries": len(self._queries),
                "by_source": {},
                "by_module": {},
                "errors": []
            }

            for query in self._queries:
                source = query["source"]
                module = query["module"]
                status = query["status"]

                # Per-source tracking
                if source not in summary["by_source"]:
                    summary["by_source"][source] = {
                        "total": 0,
                        "success": 0,
                        "error": 0,
                        "modules": {}
                    }

                summary["by_source"][source]["total"] += 1
                if status == "success":
                    summary["by_source"][source]["success"] += 1
                elif status == "error":
                    summary["by_source"][source]["error"] += 1

                # Per-module tracking
                module_key = f"{source}.{module}"
                if module_key not in summary["by_source"][source]["modules"]:
                    summary["by_source"][source]["modules"][module] = {
                        "total": 0,
                        "success": 0,
                        "error": 0,
                        "result_count": 0
                    }

                summary["by_source"][source]["modules"][module]["total"] += 1
                if status == "success":
                    summary["by_source"][source]["modules"][module]["success"] += 1
                    summary["by_source"][source]["modules"][module]["result_count"] += query.get("result_count", 0)
                elif status == "error":
                    summary["by_source"][source]["modules"][module]["error"] += 1

                # Track errors
                if status == "error":
                    summary["errors"].append({
                        "source": source,
                        "module": module,
                        "operation": query["operation"],
                        "query": query["query"],
                        "error": query["error"],
                        "error_code": query.get("error_code")
                    })

            return summary

    def get_detailed_log(self) -> List[Dict[str, Any]]:
        """Get full detailed log of all queries"""
        with self._lock:
            return list(self._queries)

    def reset(self):
        """Clear all tracked queries"""
        with self._lock:
            self._queries.clear()


# Global tracker instance with thread-safe singleton pattern
_tracker = None
_tracker_lock = threading.Lock()


def get_tracker() -> APITracker:
    """Get the global API tracker instance (thread-safe singleton)"""
    global _tracker
    if _tracker is None:
        with _tracker_lock:
            if _tracker is None:  # Double-check locking
                _tracker = APITracker()
    return _tracker


def log_api_call(
    source: str,
    module: str,
    operation: str,
    query: str,
    status: str,
    result_count: int = 0,
    error: Optional[str] = None,
    error_code: Optional[str] = None,
    endpoint: Optional[str] = None
):
    """Convenience function to log an API call"""
    get_tracker().log_query(
        source=source,
        module=module,
        operation=operation,
        query=query,
        status=status,
        result_count=result_count,
        error=error,
        error_code=error_code,
        endpoint=endpoint
    )
