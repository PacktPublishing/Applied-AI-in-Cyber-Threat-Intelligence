"""
Query logging utility for debugging collection tools
"""

import json
from pathlib import Path
from datetime import datetime


class QueryLogger:
    """Log all API queries and responses for debugging"""

    def __init__(self, log_dir: str = "logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)

        # Create session log file
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        self.log_file = self.log_dir / f"query_log_{timestamp}.jsonl"

    def log_query(self, source: str, query_type: str, query: str, response_summary: dict):
        """
        Log a query and its response

        Args:
            source: Source name (google_ti, flashpoint, crowdstrike, osint)
            query_type: Type of query (domain, actor, credential, etc.)
            query: Actual query string
            response_summary: Summary of response (count, error, etc.)
        """
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "source": source,
            "query_type": query_type,
            "query": query,
            "response": response_summary
        }

        with open(self.log_file, 'a') as f:
            f.write(json.dumps(log_entry) + '\n')

        # Also print to console for immediate visibility
        status = "✓" if response_summary.get("count", 0) > 0 else "⚠"
        print(f"    {status} [{source}] {query_type}: '{query}' → {response_summary.get('count', 0)} results")


# Global logger instance
_logger = None


def get_logger() -> QueryLogger:
    """Get or create global logger instance"""
    global _logger
    if _logger is None:
        _logger = QueryLogger()
    return _logger
