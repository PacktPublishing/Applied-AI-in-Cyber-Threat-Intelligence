"""
OSINT tools for public intelligence gathering

Collects from news feeds, custom sites, and security advisories
Configured via config.yaml
"""

import asyncio
import requests
import feedparser
from typing import Dict, List, Any
from datetime import datetime, timedelta
from ..config.settings import get_settings
from ._rate_limiter import rate_limit_osint_rss
from ._retry import retry_async
from ._time_utils import TIME_RANGES, add_recency_score, format_trend_summary
from ._api_tracker import log_api_call


async def collect_news_feeds() -> List[Dict[str, Any]]:
    """
    Collect from news feeds configured in config.yaml

    Returns:
        List of news articles
    """
    settings = get_settings()
    feeds = settings.osint_news_feeds

    if not feeds:
        return []

    print(f"    [OSINT] Fetching {len(feeds)} news feeds...")

    articles = []
    for feed in feeds:
        # Rate limiting between RSS feeds (2s delay)
        await rate_limit_osint_rss()

        try:
            # Fetch RSS feed
            feed_data = await asyncio.to_thread(feedparser.parse, feed['url'])

            # Process entries
            entry_count = 0
            for entry in feed_data.entries[:10]:  # Limit to 10 per feed
                articles.append({
                    "title": entry.get('title', ''),
                    "summary": entry.get('summary', entry.get('description', ''))[:500],
                    "url": entry.get('link', ''),
                    "published": entry.get('published', ''),
                    "source": feed['name'],
                    "priority": feed.get('priority', 'medium'),
                    "type": "news"
                })
                entry_count += 1

            # Log successful RSS fetch
            log_api_call(
                source="osint",
                module="news_feeds",
                operation="collect_rss",
                query=feed['name'],
                status="success",
                result_count=entry_count
            )

        except Exception as e:
            print(f"    [OSINT] Error fetching {feed['name']}: {e}")
            # Log error
            log_api_call(
                source="osint",
                module="news_feeds",
                operation="collect_rss",
                query=feed['name'],
                status="error",
                error=str(e)
            )
            continue

    # Add recency scoring
    articles = add_recency_score(articles, "published")

    return articles


async def collect_security_advisories() -> List[Dict[str, Any]]:
    """
    Collect from security advisory sources

    Returns:
        List of security advisories
    """
    settings = get_settings()
    advisories = settings.osint_advisories

    if not advisories:
        return []

    print(f"    [OSINT] Fetching {len(advisories)} advisory feeds...")

    results = []
    for advisory in advisories:
        # Rate limiting between RSS feeds (2s delay)
        await rate_limit_osint_rss()

        try:
            feed_data = await asyncio.to_thread(feedparser.parse, advisory['url'])

            entry_count = 0
            for entry in feed_data.entries[:10]:
                results.append({
                    "title": entry.get('title', ''),
                    "summary": entry.get('summary', entry.get('description', ''))[:500],
                    "url": entry.get('link', ''),
                    "published": entry.get('published', ''),
                    "source": advisory['name'],
                    "priority": advisory.get('priority', 'high'),
                    "type": "advisory"
                })
                entry_count += 1

            # Log successful advisory fetch
            log_api_call(
                source="osint",
                module="advisories",
                operation="collect_rss",
                query=advisory['name'],
                status="success",
                result_count=entry_count
            )

        except Exception as e:
            print(f"    [OSINT] Error fetching {advisory['name']}: {e}")
            # Log error
            log_api_call(
                source="osint",
                module="advisories",
                operation="collect_rss",
                query=advisory['name'],
                status="error",
                error=str(e)
            )


            continue

    # Add recency scoring
    results = add_recency_score(results, "published")

    return results


async def search_google_news(query: str) -> List[Dict[str, Any]]:
    """
    Search Google News for security incidents and intelligence

    Note: This is a placeholder - the OSINT Specialist agent will use
    Google Search tool directly with queries like "site:news.google.com [query]"
    or targeted news searches

    Args:
        query: Search query

    Returns:
        List of news results (agent handles this via Google Search tool)
    """
    # Agent uses Google Search tool directly
    return []


async def lookup_indicators(indicators: List[str]) -> Dict[str, Any]:
    """
    Lookup indicators on free threat intel sites (no API key needed)

    Sites to check:
    - VirusTotal (public interface)
    - GreyNoise
    - ThreatView
    - URLScan.io
    - AbuseIPDB
    - IPVoid

    Args:
        indicators: List of IPs, domains, URLs, hashes to lookup

    Returns:
        Aggregated lookup results
    """
    print(f"    [OSINT] Looking up {len(indicators)} indicators on free intel sites...")

    # TODO: Implement web scraping/API-less lookups for:
    # - https://www.virustotal.com/gui/domain/{domain}
    # - https://viz.greynoise.io/ip/{ip}
    # - https://threatview.io/ip/{ip}
    # - https://urlscan.io/search/#{domain}
    # - https://www.abuseipdb.com/check/{ip}

    # For now, return placeholder structure
    # Future: Use WebFetch tool to scrape these pages

    return {
        "indicators_checked": len(indicators),
        "free_lookups": [],
        "note": "Free indicator lookups will be implemented via WebFetch in next iteration"
    }


async def collect_all(org_profile: Dict[str, Any]) -> Dict[str, Any]:
    """
    Collect all OSINT intelligence

    Args:
        org_profile: Organization profile dict

    Returns:
        Combined OSINT intelligence
    """
    print("  [OSINT] Collecting public intelligence...")

    # Parallel collection
    news_task = collect_news_feeds()
    advisory_task = collect_security_advisories()

    news, advisories = await asyncio.gather(
        news_task,
        advisory_task,
        return_exceptions=True
    )

    # Handle exceptions
    if isinstance(news, Exception):
        print(f"  [OSINT] News collection failed: {news}")
        news = []

    if isinstance(advisories, Exception):
        print(f"  [OSINT] Advisory collection failed: {advisories}")
        advisories = []

    # Filter for org relevance (simple keyword matching)
    org_keywords = [
        org_profile.get("organization", "").lower(),
        org_profile.get("industry", "").lower()
    ] + [d.lower() for d in org_profile.get("domains", [])]
    org_keywords = [k for k in org_keywords if k]

    # Score relevance for each item
    def score_relevance(item: Dict) -> float:
        """Simple relevance scoring"""
        text = (item.get("title", "") + " " + item.get("summary", "")).lower()
        score = 0.0
        for keyword in org_keywords:
            if keyword in text:
                score += 1.0
        return score

    # Add relevance scores
    for item in news + advisories:
        item["relevance_score"] = score_relevance(item)

    # Sort by relevance and recency
    all_items = news + advisories
    all_items.sort(key=lambda x: (x.get("relevance_score", 0), x.get("published", "")), reverse=True)

    print(f"  [OSINT] ✓ Collected:")
    print(f"    - {len(news)} news articles {format_trend_summary(news, 'published')}")
    print(f"    - {len(advisories)} security advisories {format_trend_summary(advisories, 'published')}")
    print(f"    - {len([i for i in all_items if i.get('relevance_score', 0) > 0])} relevant to org")

    return {
        "news": news,
        "advisories": advisories,
        "all_items": all_items[:50],  # Top 50 most relevant
        "source": "osint"
    }
