"""
Retry logic with exponential backoff and jitter for all CTI APIs

Handles:
- Exponential backoff with jitter (prevents thundering herd)
- Region fallback for Vertex AI
- Standard retry for external APIs
- Rate limit detection and backoff
"""

import asyncio
import random
from typing import Callable, Optional, Any, List
from functools import wraps


class RetryConfig:
    """Configuration for retry behavior"""

    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 2.0,
        max_delay: float = 60.0,
        exponential_base: float = 2.0,
        jitter: bool = True,
        jitter_range: float = 0.5,  # +/- 50% jitter
        retryable_errors: Optional[List[type]] = None
    ):
        """
        Initialize retry configuration

        Args:
            max_retries: Maximum number of retry attempts
            base_delay: Initial delay in seconds
            max_delay: Maximum delay in seconds
            exponential_base: Base for exponential backoff (2.0 = double each time)
            jitter: Whether to add random jitter
            jitter_range: Jitter range as fraction of delay (0.5 = +/- 50%)
            retryable_errors: List of exception types to retry on
        """
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.jitter = jitter
        self.jitter_range = jitter_range
        self.retryable_errors = retryable_errors or [
            ConnectionError,
            TimeoutError,
            Exception  # Catch-all for unknown errors
        ]

    def calculate_delay(self, attempt: int) -> float:
        """
        Calculate delay for retry attempt with exponential backoff and jitter

        Args:
            attempt: Retry attempt number (0-indexed)

        Returns:
            Delay in seconds
        """
        # Exponential backoff
        delay = min(
            self.base_delay * (self.exponential_base ** attempt),
            self.max_delay
        )

        # Add jitter to prevent thundering herd
        if self.jitter:
            jitter_amount = delay * self.jitter_range
            delay = delay + random.uniform(-jitter_amount, jitter_amount)

        return max(0.0, delay)  # Never negative

    def is_retryable(self, error: Exception) -> bool:
        """Check if error is retryable"""
        # Never retry 404 errors (not found is permanent)
        error_str = str(error).lower()
        error_type = type(error).__name__
        if "404" in error_str or "not found" in error_str or "NotFoundError" in error_type:
            return False

        # Check for rate limit errors (always retry with backoff)
        if any(keyword in error_str for keyword in ["rate limit", "quota", "429", "503", "too many requests"]):
            return True

        # Check if error type is in retryable list
        return any(isinstance(error, err_type) for err_type in self.retryable_errors)


# Predefined retry configurations for different API types
RETRY_CONFIGS = {
    "vertex": RetryConfig(
        max_retries=3,  # Fewer retries needed (proactive load balancing handles quota)
        base_delay=2.0,  # Standard delay (we distribute load upfront)
        max_delay=30.0,  # Shorter max (shouldn't hit quota with load balancing)
        exponential_base=2.0,
        jitter=True
    ),
    "gti": RetryConfig(
        max_retries=3,
        base_delay=2.0,
        max_delay=30.0,
        exponential_base=2.0,
        jitter=True
    ),
    "flashpoint": RetryConfig(
        max_retries=3,
        base_delay=5.0,  # More aggressive starting delay
        max_delay=120.0,  # Allow longer waits for rate limits
        exponential_base=3.0,  # More aggressive exponential growth
        jitter=True
    ),
    "crowdstrike": RetryConfig(
        max_retries=3,
        base_delay=2.0,
        max_delay=30.0,
        exponential_base=2.0,
        jitter=True
    ),
    "osint": RetryConfig(
        max_retries=2,  # Fewer retries for free sources
        base_delay=5.0,  # Longer delay to be polite
        max_delay=60.0,
        exponential_base=2.0,
        jitter=True
    ),
    "default": RetryConfig()
}


async def retry_with_backoff(
    func: Callable,
    config: Optional[RetryConfig] = None,
    config_name: Optional[str] = None,
    on_retry: Optional[Callable[[int, Exception, float], None]] = None,
    **kwargs
) -> Any:
    """
    Execute function with exponential backoff retry

    Args:
        func: Async function to execute
        config: RetryConfig instance (overrides config_name)
        config_name: Name of predefined config (vertex, gti, flashpoint, etc.)
        on_retry: Optional callback called before each retry (attempt, error, delay)
        **kwargs: Arguments to pass to func

    Returns:
        Result of func

    Raises:
        Last exception if all retries exhausted
    """
    # Get retry configuration
    if config is None:
        config = RETRY_CONFIGS.get(config_name or "default", RETRY_CONFIGS["default"])

    last_error = None

    for attempt in range(config.max_retries + 1):
        try:
            # Execute function
            result = await func(**kwargs)
            return result

        except Exception as e:
            last_error = e

            # Check if we should retry
            if attempt >= config.max_retries:
                # Out of retries
                raise

            if not config.is_retryable(e):
                # Error is not retryable
                raise

            # Calculate delay
            delay = config.calculate_delay(attempt)

            # Call retry callback if provided
            if on_retry:
                on_retry(attempt, e, delay)

            # Wait before retry
            await asyncio.sleep(delay)

    # Should never reach here, but just in case
    if last_error:
        raise last_error
    raise Exception("Retry logic failed unexpectedly")


def retry_async(config_name: str = "default", config: Optional[RetryConfig] = None):
    """
    Decorator for async functions to add retry logic

    Args:
        config_name: Name of predefined retry config
        config: Custom RetryConfig (overrides config_name)

    Example:
        @retry_async("gti")
        async def search_domain(domain: str):
            # API call here
            pass
    """
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            retry_config = config or RETRY_CONFIGS.get(config_name, RETRY_CONFIGS["default"])

            def on_retry(attempt: int, error: Exception, delay: float):
                print(f"  [Retry] Attempt {attempt + 1}/{retry_config.max_retries} failed: {error}")
                print(f"  [Retry] Waiting {delay:.1f}s before retry...")

            async def _execute():
                return await func(*args, **kwargs)

            return await retry_with_backoff(
                _execute,
                config=retry_config,
                on_retry=on_retry
            )

        return wrapper
    return decorator


# Vertex AI specific retry with region fallback
async def retry_vertex_with_region_fallback(
    func: Callable,
    client,
    org_dict: dict,
    regions: Optional[List[str]] = None
) -> Any:
    """
    Retry Vertex AI call with region fallback

    If one region hits quota, try other regions

    Args:
        func: Function that takes (client, org_dict) args
        client: Gemini client
        org_dict: Organization profile dict
        regions: List of regions to try (None = use default rotation)

    Returns:
        Result from func

    Raises:
        Last exception if all regions exhausted
    """
    from ..config import regions as regions_module

    # Get available regions
    if regions is None:
        regions = regions_module.AVAILABLE_REGIONS

    last_error = None
    config = RETRY_CONFIGS["vertex"]

    for region_idx, region in enumerate(regions):
        try:
            print(f"  [Vertex] Trying region: {region} ({region_idx + 1}/{len(regions)})")

            # Update client location
            client._location = region

            # Retry this region with exponential backoff
            result = await retry_with_backoff(
                func,
                config=config,
                client=client,
                org_dict=org_dict
            )

            return result

        except Exception as e:
            last_error = e
            error_str = str(e).lower()

            # Check if it's a quota error
            is_quota_error = any(keyword in error_str for keyword in [
                "quota", "resource exhausted", "rate limit", "429"
            ])

            if is_quota_error and region_idx < len(regions) - 1:
                print(f"  [Vertex] Region {region} quota exhausted, trying next region...")
                continue
            else:
                # Not a quota error or out of regions
                if region_idx >= len(regions) - 1:
                    print(f"  [Vertex] All {len(regions)} regions exhausted")
                raise

    # Should never reach here
    if last_error:
        raise last_error
    raise Exception("Vertex region fallback failed unexpectedly")


def print_retry_config_summary():
    """Print summary of retry configurations"""
    print("\n" + "="*60)
    print("RETRY CONFIGURATION SUMMARY")
    print("="*60)

    for name, config in RETRY_CONFIGS.items():
        print(f"\n{name.upper():20}")
        print(f"  Max Retries: {config.max_retries}")
        print(f"  Base Delay: {config.base_delay}s")
        print(f"  Max Delay: {config.max_delay}s")
        print(f"  Exponential Base: {config.exponential_base}x")
        print(f"  Jitter: {'Enabled' if config.jitter else 'Disabled'}")

        # Show example delays
        print(f"  Example delays: ", end="")
        example_delays = [config.calculate_delay(i) for i in range(min(3, config.max_retries))]
        print(", ".join([f"{d:.1f}s" for d in example_delays]))

    print("="*60 + "\n")
