"""
Flashpoint Intelligence tools

Simple REST API wrappers for dark web intelligence gathering
Read-only operations

⚠️  RAW API IMPLEMENTATION - NO SDK AVAILABLE
This module uses raw HTTP requests to Flashpoint API v4.
Endpoints enumerated and validated: 2026-02-11

API Documentation: https://docs.flashpoint.io/api/v4/
Base URL: https://fp.tools/api/v4

VALIDATED ENDPOINTS (enumeration 2026-02-11):
1. GET /api/v4/indicators/simple ✓ (200 OK)
   - Query syntax: "+domain:\"example.com\"" (Lucene-style)
   - Params: query (string), limit (int), types (csv), since/until (ISO8601)
   - Response: {data: [{Attribute: {...}}]}
   - Supports multiple indicator types:
     * email - Email addresses
     * credential-pair - Username:password combos
     * domain - Domain names
     * ip-dst - IP addresses
     * url - URLs
     * md5/sha1/sha256 - File hashes

2. GET /api/v4/indicators/attribute ✓ (200 OK)
   - Alternate endpoint for indicator searches
   - Query syntax: Similar to /indicators/simple
   - Params: query (string), limit (int)

REMOVED ENDPOINTS (returned 404 during enumeration):
- /forums/posts (404)
- /finished-intelligence/reports (404)
- /vulnerabilities (503 - service unavailable)
- All other /search endpoints (404)

⚠️ The /indicators/simple endpoint is powerful - it can search for credentials,
   domains, IPs, and other indicators all through one unified interface.

QUERY SYNTAX:
- Lucene syntax: "+domain:\"example.com\""
- Multiple types: types=email,credential-pair,domain
- Time filters: since/until in ISO8601 format

ERROR HANDLING:
- 404: Endpoint not found (non-retryable)
- 429/503: Rate limit exceeded (retryable with backoff)
- 401/403: Authentication failure
- 200: Success with {data: [...]} response
"""

import os
import asyncio
import requests
from typing import Dict, List, Optional, Any
from ._query_logger import get_logger
from ._rate_limiter import rate_limit_flashpoint, check_circuit_breaker, record_api_success, record_api_failure
from ._retry import retry_async
from ._time_utils import TIME_RANGES, add_recency_score, format_trend_summary
from ._api_tracker import log_api_call

# Suppress SSL warnings for corporate proxy/firewall environments
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_BASE_URL = "https://fp.tools/api/v4"

# Expected response schemas for validation
EXPECTED_SCHEMAS = {
    "indicators": {
        "root_key": "data",
        "required_fields": ["Attribute"],
        "nested_fields": {"Attribute": ["type", "value"]}
    },
    "forums": {
        "root_key": "data",
        "required_fields": ["title", "body", "site", "published_at"],
        "nested_fields": {"body": ["text"], "site": ["title"], "published_at": ["date-time"]}
    },
    "reports": {
        "root_key": "data",
        "required_fields": ["id", "title", "summary", "published_at"],
        "nested_fields": {"published_at": ["date-time"]}
    },
    "vulnerabilities": {
        "root_key": "data",
        "required_fields": ["cve_id", "title", "description", "cvss_score"]
    }
}


def validate_response_schema(data: dict, endpoint_type: str) -> bool:
    """
    Validate Flashpoint API response matches expected schema

    Args:
        data: JSON response from API
        endpoint_type: One of: indicators, forums, reports, vulnerabilities

    Returns:
        True if schema matches, False otherwise (logs warnings)
    """
    if endpoint_type not in EXPECTED_SCHEMAS:
        print(f"[Flashpoint] ⚠️  Unknown endpoint type for validation: {endpoint_type}")
        return True  # Skip validation for unknown types

    schema = EXPECTED_SCHEMAS[endpoint_type]

    # Check root key exists
    if schema["root_key"] not in data:
        # Check if this is actually an error response
        if "error" in data or "message" in data or "errors" in data:
            error_msg = data.get("error") or data.get("message") or data.get("errors")
            print(f"[Flashpoint] ⚠️  API returned error with 200 OK status")
            print(f"[Flashpoint]    Error: {error_msg}")
            print(f"[Flashpoint]    Full response keys: {list(data.keys())}")
            return False

        # Not an error response, but missing expected structure
        print(f"[Flashpoint] ⚠️  API SCHEMA CHANGE: Missing root key '{schema['root_key']}' in response")
        print(f"[Flashpoint]    Response keys: {list(data.keys())}")

        # Log a sample of the response to help diagnose
        import json
        response_preview = json.dumps(data, indent=2)[:500]
        print(f"[Flashpoint]    Response preview: {response_preview}...")
        print(f"[Flashpoint]    ⚠️  This may indicate an API version change - validate against docs!")
        return False

    items = data[schema["root_key"]]
    if not items or len(items) == 0:
        return True  # Empty results are valid

    # Check first item for required fields
    first_item = items[0]

    # Type check: first_item should be a dict, not a list
    if not isinstance(first_item, dict):
        print(f"[Flashpoint] ⚠️  API SCHEMA CHANGE: Expected dict, got {type(first_item).__name__}")
        print(f"[Flashpoint]    First item value: {str(first_item)[:200]}")
        print(f"[Flashpoint]    ⚠️  This may indicate an API version change - validate against docs!")
        return False

    missing_fields = []

    for field in schema["required_fields"]:
        if field not in first_item:
            missing_fields.append(field)

    if missing_fields:
        print(f"[Flashpoint] ⚠️  API SCHEMA CHANGE: Missing fields in {endpoint_type} response: {missing_fields}")
        print(f"[Flashpoint]    Available fields: {list(first_item.keys())}")
        print(f"[Flashpoint]    ⚠️  This may indicate an API version change - validate against docs!")
        return False

    # Check nested fields if defined
    if "nested_fields" in schema:
        for parent_field, nested_fields in schema["nested_fields"].items():
            if parent_field in first_item and isinstance(first_item[parent_field], dict):
                for nested_field in nested_fields:
                    if nested_field not in first_item[parent_field]:
                        print(f"[Flashpoint] ⚠️  API SCHEMA CHANGE: Missing nested field {parent_field}.{nested_field}")

    return True


class FlashpointNotFoundError(Exception):
    """Raised when Flashpoint returns 404 (non-retryable)"""
    pass


class FlashpointRateLimitError(Exception):
    """Raised when Flashpoint returns 503/429 (rate limit - retryable)"""
    pass


def get_api_key() -> str:
    """
    Get Flashpoint API key from environment

    Returns:
        API key string

    Raises:
        ValueError: If FP_API_KEY not found
    """
    api_key = os.environ.get("FP_API_KEY")
    if not api_key:
        raise ValueError(
            "FP_API_KEY not found in environment.\n"
            "Run: gcloud auth login\n"
            "Secrets should be loaded from GSM automatically."
        )
    return api_key


@retry_async("flashpoint")
async def search_credentials(domain: str, limit: int = 100) -> List[Dict[str, Any]]:
    """
    Search for compromised credentials related to domain

    Args:
        domain: Domain to search (e.g., "example.com")
        limit: Max results

    Returns:
        List of credential leak records

    Raises:
        FlashpointNotFoundError: If 404 (non-retryable)
        FlashpointRateLimitError: If 503/429 (retryable)
    """
    # Check circuit breaker before attempting request
    if not check_circuit_breaker("flashpoint"):
        log_api_call(
            source="flashpoint",
            module="indicators",
            operation="search_credentials",
            query=domain,
            status="skipped",
            error="Circuit breaker OPEN - skipping request",
            endpoint="/api/v4/indicators/simple"
        )
        return []  # Return empty results when circuit is open

    # Rate limiting
    await rate_limit_flashpoint()

    def _sync_search():
        api_key = get_api_key()
        headers = {"Authorization": f"Bearer {api_key}"}
        url = f"{API_BASE_URL}/indicators/simple"

        # Add time filtering for recency
        time_filter = TIME_RANGES["context"].format_api_filter("flashpoint")

        params = {
            "query": f"+domain:\"{domain}\"",
            "limit": limit,
            "types": "email,credential-pair",
            **time_filter  # Add since/until params
        }

        try:
            # Disable SSL verification for corporate proxy/firewall environments
            resp = requests.get(url, headers=headers, params=params, timeout=30, verify=False)

            # Handle different HTTP status codes
            if resp.status_code == 404:
                # Not found - don't retry, record failure
                record_api_failure("flashpoint", is_rate_limit=False)
                log_api_call(
                    source="flashpoint",
                    module="indicators",
                    operation="search_credentials",
                    query=domain,
                    status="error",
                    error="Not found",
                    error_code="404",
                    endpoint="/api/v4/indicators/simple"
                )
                raise FlashpointNotFoundError(f"Flashpoint endpoint not found: {url}")

            elif resp.status_code in [429, 503]:
                # Rate limit - retry with backoff
                record_api_failure("flashpoint", is_rate_limit=True)
                log_api_call(
                    source="flashpoint",
                    module="indicators",
                    operation="search_credentials",
                    query=domain,
                    status="error",
                    error="Rate limit exceeded",
                    error_code=str(resp.status_code),
                    endpoint="/api/v4/indicators/simple"
                )
                raise FlashpointRateLimitError(f"Flashpoint rate limit: HTTP {resp.status_code}")

            elif resp.status_code != 200:
                # Other error - retry
                record_api_failure("flashpoint", is_rate_limit=False)
                log_api_call(
                    source="flashpoint",
                    module="indicators",
                    operation="search_credentials",
                    query=domain,
                    status="error",
                    error=f"HTTP {resp.status_code}",
                    error_code=str(resp.status_code),
                    endpoint="/api/v4/indicators/simple"
                )
                raise Exception(f"Flashpoint API error: HTTP {resp.status_code}")

            # Success
            data = resp.json()

            # /indicators/simple returns a LIST directly, not {"data": [...]}
            if not isinstance(data, list):
                print(f"[Flashpoint] ⚠️  Expected list, got {type(data).__name__}")
                print(f"[Flashpoint]    Response: {str(data)[:200]}")
                record_api_failure("flashpoint", is_rate_limit=False)
                return []

            results = [{
                "domain": domain,
                "indicator_type": item.get("Attribute", {}).get("type", "unknown"),
                "value": item.get("Attribute", {}).get("value", ""),
                "first_seen": item.get("Attribute", {}).get("first_observed_at", {}).get("date-time", ""),
                "source": "flashpoint"
            } for item in data]

            # Record success for circuit breaker
            record_api_success("flashpoint")

            # Log successful query
            log_api_call(
                source="flashpoint",
                module="indicators",
                operation="search_credentials",
                query=domain,
                status="success",
                result_count=len(results),
                endpoint="/api/v4/indicators/simple"
            )

            return results

        except (FlashpointNotFoundError, FlashpointRateLimitError):
            # Re-raise custom exceptions
            raise
        except Exception as e:
            # Log unexpected errors
            record_api_failure("flashpoint", is_rate_limit=False)
            if "HTTP" not in str(e):
                log_api_call(
                    source="flashpoint",
                    module="indicators",
                    operation="search_credentials",
                    query=domain,
                    status="error",
                    error=str(e),
                    endpoint="/api/v4/indicators/simple"
                )
            raise

    return await asyncio.to_thread(_sync_search)


@retry_async("flashpoint")
async def search_reports(query: str, limit: int = 10) -> List[Dict[str, Any]]:
    """
    Search Flashpoint finished intelligence reports

    Args:
        query: Search query (industry, threat actor, org)
        limit: Max results

    Returns:
        List of analyst-written intelligence reports

    Raises:
        FlashpointNotFoundError: If 404 (non-retryable)
        FlashpointRateLimitError: If 503/429 (retryable)
    """
    # Check circuit breaker
    if not check_circuit_breaker("flashpoint"):
        log_api_call(
            source="flashpoint",
            module="reports",
            operation="search_reports",
            query=query,
            status="skipped",
            error="Circuit breaker OPEN - skipping request",
            endpoint="/api/v4/reports"
        )
        return []

    # Rate limiting
    await rate_limit_flashpoint()

    def _sync_search():
        api_key = get_api_key()
        headers = {"Authorization": f"Bearer {api_key}"}
        url = f"{API_BASE_URL}/reports"

        # Add time filtering
        time_filter = TIME_RANGES["context"].format_api_filter("flashpoint")

        params = {
            "query": query,
            "limit": limit,
            **time_filter
        }

        try:
            # Disable SSL verification for corporate proxy/firewall environments
            resp = requests.get(url, headers=headers, params=params, timeout=30, verify=False)

            # Handle different HTTP status codes
            if resp.status_code == 404:
                record_api_failure("flashpoint", is_rate_limit=False)
                log_api_call(
                    source="flashpoint",
                    module="reports",
                    operation="search_reports",
                    query=query,
                    status="error",
                    error="Not found",
                    error_code="404",
                    endpoint="/api/v4/reports"
                )
                raise FlashpointNotFoundError(f"Flashpoint endpoint not found: {url}")

            elif resp.status_code in [429, 503]:
                record_api_failure("flashpoint", is_rate_limit=True)
                log_api_call(
                    source="flashpoint",
                    module="reports",
                    operation="search_reports",
                    query=query,
                    status="error",
                    error="Rate limit exceeded",
                    error_code=str(resp.status_code),
                    endpoint="/api/v4/reports"
                )
                raise FlashpointRateLimitError(f"Flashpoint rate limit: HTTP {resp.status_code}")

            elif resp.status_code != 200:
                record_api_failure("flashpoint", is_rate_limit=False)
                log_api_call(
                    source="flashpoint",
                    module="reports",
                    operation="search_reports",
                    query=query,
                    status="error",
                    error=f"HTTP {resp.status_code}",
                    error_code=str(resp.status_code),
                    endpoint="/api/v4/reports"
                )
                raise Exception(f"Flashpoint API error: HTTP {resp.status_code}")

            # Success
            data = resp.json()

            # Extract results
            results = []
            for item in data.get("data", []):
                results.append({
                    "id": item.get("id", ""),
                    "title": item.get("title", ""),
                    "summary": item.get("summary", "")[:500],
                    "date": item.get("posted_at", ""),
                    "tags": item.get("tags", []),
                    "platform_url": item.get("platform_url", ""),
                    "source": "flashpoint"
                })

            record_api_success("flashpoint")
            log_api_call(
                source="flashpoint",
                module="reports",
                operation="search_reports",
                query=query,
                status="success",
                result_count=len(results),
                endpoint="/api/v4/reports"
            )

            return results

        except (FlashpointNotFoundError, FlashpointRateLimitError):
            raise
        except Exception as e:
            record_api_failure("flashpoint", is_rate_limit=False)
            if "HTTP" not in str(e):
                log_api_call(
                    source="flashpoint",
                    module="reports",
                    operation="search_reports",
                    query=query,
                    status="error",
                    error=str(e),
                    endpoint="/api/v4/reports"
                )
            raise

    return await asyncio.to_thread(_sync_search)


@retry_async("flashpoint")
# REMOVED (404): async def search_forums(query: str, limit: int = 50) -> List[Dict[str, Any]]:
# REMOVED (404):     """
# REMOVED (404):     Search underground forums for mentions
# REMOVED (404): 
# REMOVED (404):     Args:
# REMOVED (404):         query: Search query (org name, brand, etc.)
# REMOVED (404):         limit: Max results
# REMOVED (404): 
# REMOVED (404):     Returns:
# REMOVED (404):         List of forum posts/mentions
# REMOVED (404): 
# REMOVED (404):     Raises:
# REMOVED (404):         FlashpointNotFoundError: If 404 (non-retryable)
# REMOVED (404):         FlashpointRateLimitError: If 503/429 (retryable)
# REMOVED (404):     """
# REMOVED (404):     # Check circuit breaker
# REMOVED (404):     if not check_circuit_breaker("flashpoint"):
# REMOVED (404):         log_api_call(
# REMOVED (404):             source="flashpoint",
# REMOVED (404):             module="forums",
# REMOVED (404):             operation="search_forums",
# REMOVED (404):             query=query,
# REMOVED (404):             status="skipped",
# REMOVED (404):             error="Circuit breaker OPEN - skipping request",
# REMOVED (404):             endpoint="/api/v4/forums/posts"
# REMOVED (404):         )
# REMOVED (404):         return []
# REMOVED (404): 
# REMOVED (404):     # Rate limiting
# REMOVED (404):     await rate_limit_flashpoint()
# REMOVED (404): 
# REMOVED (404):     def _sync_search():
# REMOVED (404):         api_key = get_api_key()
# REMOVED (404):         headers = {"Authorization": f"Bearer {api_key}"}
# REMOVED (404):         url = f"{API_BASE_URL}/forums/posts"
# REMOVED (404): 
# REMOVED (404):         # Add time filtering
# REMOVED (404):         time_filter = TIME_RANGES["context"].format_api_filter("flashpoint")
# REMOVED (404): 
# REMOVED (404):         params = {
# REMOVED (404):             "query": query,
# REMOVED (404):             "limit": limit,
# REMOVED (404):             **time_filter
# REMOVED (404):         }
# REMOVED (404): 
# REMOVED (404):         try:
# REMOVED (404):             # Disable SSL verification for corporate proxy/firewall environments
# REMOVED (404):             resp = requests.get(url, headers=headers, params=params, timeout=30, verify=False)
# REMOVED (404): 
# REMOVED (404):             # Handle different HTTP status codes
# REMOVED (404):             if resp.status_code == 404:
# REMOVED (404):                 record_api_failure("flashpoint", is_rate_limit=False)
# REMOVED (404):                 log_api_call(
# REMOVED (404):                     source="flashpoint",
# REMOVED (404):                     module="forums",
# REMOVED (404):                     operation="search_forums",
# REMOVED (404):                     query=query,
# REMOVED (404):                     status="error",
# REMOVED (404):                     error="Not found",
# REMOVED (404):                     error_code="404",
# REMOVED (404):                     endpoint="/api/v4/forums/posts"
# REMOVED (404):                 )
# REMOVED (404):                 raise FlashpointNotFoundError(f"Flashpoint endpoint not found: {url}")
# REMOVED (404): 
# REMOVED (404):             elif resp.status_code in [429, 503]:
# REMOVED (404):                 record_api_failure("flashpoint", is_rate_limit=True)
# REMOVED (404):                 log_api_call(
# REMOVED (404):                     source="flashpoint",
# REMOVED (404):                     module="forums",
# REMOVED (404):                     operation="search_forums",
# REMOVED (404):                     query=query,
# REMOVED (404):                     status="error",
# REMOVED (404):                     error="Rate limit exceeded",
# REMOVED (404):                     error_code=str(resp.status_code),
# REMOVED (404):                     endpoint="/api/v4/forums/posts"
# REMOVED (404):                 )
# REMOVED (404):                 raise FlashpointRateLimitError(f"Flashpoint rate limit: HTTP {resp.status_code}")
# REMOVED (404): 
# REMOVED (404):             elif resp.status_code != 200:
# REMOVED (404):                 record_api_failure("flashpoint", is_rate_limit=False)
# REMOVED (404):                 log_api_call(
# REMOVED (404):                     source="flashpoint",
# REMOVED (404):                     module="forums",
# REMOVED (404):                     operation="search_forums",
# REMOVED (404):                     query=query,
# REMOVED (404):                     status="error",
# REMOVED (404):                     error=f"HTTP {resp.status_code}",
# REMOVED (404):                     error_code=str(resp.status_code),
# REMOVED (404):                     endpoint="/api/v4/forums/posts"
# REMOVED (404):                 )
# REMOVED (404):                 raise Exception(f"Flashpoint API error: HTTP {resp.status_code}")
# REMOVED (404): 
# REMOVED (404):             # Success
# REMOVED (404):             data = resp.json()
# REMOVED (404): 
# REMOVED (404):             # Validate response schema
# REMOVED (404):             validate_response_schema(data, "forums")
# REMOVED (404): 
# REMOVED (404):             results = [{
# REMOVED (404):                 "query": query,
# REMOVED (404):                 "title": item.get("title", ""),
# REMOVED (404):                 "snippet": item.get("body", {}).get("text", {}).get("preview", "")[:200],
# REMOVED (404):                 "forum": item.get("site", {}).get("title", "Unknown"),
# REMOVED (404):                 "date": item.get("published_at", {}).get("date-time", ""),
# REMOVED (404):                 "url": item.get("fpid", ""),
# REMOVED (404):                 "source": "flashpoint"
# REMOVED (404):             } for item in data.get("data", [])]
# REMOVED (404): 
# REMOVED (404):             record_api_success("flashpoint")
# REMOVED (404):             log_api_call(
# REMOVED (404):                 source="flashpoint",
# REMOVED (404):                 module="forums",
# REMOVED (404):                 operation="search_forums",
# REMOVED (404):                 query=query,
# REMOVED (404):                 status="success",
# REMOVED (404):                 result_count=len(results),
# REMOVED (404):                 endpoint="/api/v4/forums/posts"
# REMOVED (404):             )
# REMOVED (404): 
# REMOVED (404):             return results
# REMOVED (404): 
# REMOVED (404):         except (FlashpointNotFoundError, FlashpointRateLimitError):
# REMOVED (404):             raise
# REMOVED (404):         except Exception as e:
# REMOVED (404):             record_api_failure("flashpoint", is_rate_limit=False)
# REMOVED (404):             if "HTTP" not in str(e):
# REMOVED (404):                 log_api_call(
# REMOVED (404):                     source="flashpoint",
# REMOVED (404):                     module="forums",
# REMOVED (404):                     operation="search_forums",
# REMOVED (404):                     query=query,
# REMOVED (404):                     status="error",
# REMOVED (404):                     error=str(e),
# REMOVED (404):                     endpoint="/api/v4/forums/posts"
# REMOVED (404):                 )
# REMOVED (404):             raise
# REMOVED (404): 
# REMOVED (404):     return await asyncio.to_thread(_sync_search)
# REMOVED (404): 
# REMOVED (404): 
@retry_async("flashpoint")
# REMOVED (404): async def search_finished_intelligence(query: str, limit: int = 10) -> List[Dict[str, Any]]:
# REMOVED (404):     """
# REMOVED (404):     Search Flashpoint Finished Intelligence (analyst reports)
# REMOVED (404): 
# REMOVED (404):     Args:
# REMOVED (404):         query: Search query (industry, threat actor, org)
# REMOVED (404):         limit: Max results
# REMOVED (404): 
# REMOVED (404):     Returns:
# REMOVED (404):         List of analyst-written intelligence reports
# REMOVED (404): 
# REMOVED (404):     Raises:
# REMOVED (404):         FlashpointNotFoundError: If 404 (non-retryable)
# REMOVED (404):         FlashpointRateLimitError: If 503/429 (retryable)
# REMOVED (404):     """
# REMOVED (404):     # Check circuit breaker
# REMOVED (404):     if not check_circuit_breaker("flashpoint"):
# REMOVED (404):         log_api_call(
# REMOVED (404):             source="flashpoint",
# REMOVED (404):             module="finished_intelligence",
# REMOVED (404):             operation="search_finished_intelligence",
# REMOVED (404):             query=query,
# REMOVED (404):             status="skipped",
# REMOVED (404):             error="Circuit breaker OPEN - skipping request",
# REMOVED (404):             endpoint="/api/v4/finished-intelligence/reports"
# REMOVED (404):         )
# REMOVED (404):         return []
# REMOVED (404): 
# REMOVED (404):     # Rate limiting
# REMOVED (404):     await rate_limit_flashpoint()
# REMOVED (404): 
# REMOVED (404):     def _sync_search():
# REMOVED (404):         api_key = get_api_key()
# REMOVED (404):         headers = {"Authorization": f"Bearer {api_key}"}
# REMOVED (404):         url = f"{API_BASE_URL}/finished-intelligence/reports"
# REMOVED (404): 
# REMOVED (404):         # Add time filtering
# REMOVED (404):         time_filter = TIME_RANGES["context"].format_api_filter("flashpoint")
# REMOVED (404): 
# REMOVED (404):         params = {
# REMOVED (404):             "query": query,
# REMOVED (404):             "limit": limit,
# REMOVED (404):             **time_filter
# REMOVED (404):         }
# REMOVED (404): 
# REMOVED (404):         try:
# REMOVED (404):             # Disable SSL verification for corporate proxy/firewall environments
# REMOVED (404):             resp = requests.get(url, headers=headers, params=params, timeout=30, verify=False)
# REMOVED (404): 
# REMOVED (404):             # Handle different HTTP status codes
# REMOVED (404):             if resp.status_code == 404:
# REMOVED (404):                 record_api_failure("flashpoint", is_rate_limit=False)
# REMOVED (404):                 log_api_call(
# REMOVED (404):                     source="flashpoint",
# REMOVED (404):                     module="finished_intelligence",
# REMOVED (404):                     operation="search_finished_intelligence",
# REMOVED (404):                     query=query,
# REMOVED (404):                     status="error",
# REMOVED (404):                     error="Not found",
# REMOVED (404):                     error_code="404",
# REMOVED (404):                     endpoint="/api/v4/finished-intelligence/reports"
# REMOVED (404):                 )
# REMOVED (404):                 raise FlashpointNotFoundError(f"Flashpoint endpoint not found: {url}")
# REMOVED (404): 
# REMOVED (404):             elif resp.status_code in [429, 503]:
# REMOVED (404):                 record_api_failure("flashpoint", is_rate_limit=True)
# REMOVED (404):                 log_api_call(
# REMOVED (404):                     source="flashpoint",
# REMOVED (404):                     module="finished_intelligence",
# REMOVED (404):                     operation="search_finished_intelligence",
# REMOVED (404):                     query=query,
# REMOVED (404):                     status="error",
# REMOVED (404):                     error="Rate limit exceeded",
# REMOVED (404):                     error_code=str(resp.status_code),
# REMOVED (404):                     endpoint="/api/v4/finished-intelligence/reports"
# REMOVED (404):                 )
# REMOVED (404):                 raise FlashpointRateLimitError(f"Flashpoint rate limit: HTTP {resp.status_code}")
# REMOVED (404): 
# REMOVED (404):             elif resp.status_code != 200:
# REMOVED (404):                 record_api_failure("flashpoint", is_rate_limit=False)
# REMOVED (404):                 log_api_call(
# REMOVED (404):                     source="flashpoint",
# REMOVED (404):                     module="finished_intelligence",
# REMOVED (404):                     operation="search_finished_intelligence",
# REMOVED (404):                     query=query,
# REMOVED (404):                     status="error",
# REMOVED (404):                     error=f"HTTP {resp.status_code}",
# REMOVED (404):                     error_code=str(resp.status_code),
# REMOVED (404):                     endpoint="/api/v4/finished-intelligence/reports"
# REMOVED (404):                 )
# REMOVED (404):                 raise Exception(f"Flashpoint API error: HTTP {resp.status_code}")
# REMOVED (404): 
# REMOVED (404):             # Success
# REMOVED (404):             data = resp.json()
# REMOVED (404): 
# REMOVED (404):             # Validate response schema
# REMOVED (404):             validate_response_schema(data, "reports")
# REMOVED (404): 
# REMOVED (404):             results = [{
# REMOVED (404):                 "id": item.get("id", ""),
# REMOVED (404):                 "title": item.get("title", ""),
# REMOVED (404):                 "summary": item.get("summary", "")[:500],
# REMOVED (404):                 "date": item.get("published_at", {}).get("date-time", ""),
# REMOVED (404):                 "report_type": item.get("report_type", ""),
# REMOVED (404):                 "tags": item.get("tags", []),
# REMOVED (404):                 "source": "flashpoint",
# REMOVED (404):                 "url": f"https://fp.tools/home/intelligence/reports/{item.get('id', '')}"
# REMOVED (404):             } for item in data.get("data", [])]
# REMOVED (404): 
# REMOVED (404):             record_api_success("flashpoint")
# REMOVED (404):             log_api_call(
# REMOVED (404):                 source="flashpoint",
# REMOVED (404):                 module="finished_intelligence",
# REMOVED (404):                 operation="search_finished_intelligence",
# REMOVED (404):                 query=query,
# REMOVED (404):                 status="success",
# REMOVED (404):                 result_count=len(results),
# REMOVED (404):                 endpoint="/api/v4/finished-intelligence/reports"
# REMOVED (404):             )
# REMOVED (404): 
# REMOVED (404):             return results
# REMOVED (404): 
# REMOVED (404):         except (FlashpointNotFoundError, FlashpointRateLimitError):
# REMOVED (404):             raise
# REMOVED (404):         except Exception as e:
# REMOVED (404):             record_api_failure("flashpoint", is_rate_limit=False)
# REMOVED (404):             if "HTTP" not in str(e):
# REMOVED (404):                 log_api_call(
# REMOVED (404):                     source="flashpoint",
# REMOVED (404):                     module="finished_intelligence",
# REMOVED (404):                     operation="search_finished_intelligence",
# REMOVED (404):                     query=query,
# REMOVED (404):                     status="error",
# REMOVED (404):                     error=str(e),
# REMOVED (404):                     endpoint="/api/v4/finished-intelligence/reports"
# REMOVED (404):                 )
# REMOVED (404):             raise
# REMOVED (404): 
# REMOVED (404):     return await asyncio.to_thread(_sync_search)
# REMOVED (404): 
# REMOVED (404): 
@retry_async("flashpoint")
# REMOVED (503): async def search_vulnerabilities(product: str, limit: int = 20) -> List[Dict[str, Any]]:
# REMOVED (503):     """
# REMOVED (503):     Search Flashpoint VulnDB for technology stack vulnerabilities
# REMOVED (503): 
# REMOVED (503):     Args:
# REMOVED (503):         product: Product/vendor name (e.g., "aws", "kubernetes")
# REMOVED (503):         limit: Max results
# REMOVED (503): 
# REMOVED (503):     Returns:
# REMOVED (503):         List of vulnerability records with exploit info
# REMOVED (503): 
# REMOVED (503):     Raises:
# REMOVED (503):         FlashpointNotFoundError: If 404 (non-retryable)
# REMOVED (503):         FlashpointRateLimitError: If 503/429 (retryable)
# REMOVED (503):     """
# REMOVED (503):     # Check circuit breaker
# REMOVED (503):     if not check_circuit_breaker("flashpoint"):
# REMOVED (503):         log_api_call(
# REMOVED (503):             source="flashpoint",
# REMOVED (503):             module="vulnerabilities",
# REMOVED (503):             operation="search_vulnerabilities",
# REMOVED (503):             query=product,
# REMOVED (503):             status="skipped",
# REMOVED (503):             error="Circuit breaker OPEN - skipping request",
# REMOVED (503):             endpoint="/api/v4/vulnerabilities"
# REMOVED (503):         )
# REMOVED (503):         return []
# REMOVED (503): 
# REMOVED (503):     # Rate limiting
# REMOVED (503):     await rate_limit_flashpoint()
# REMOVED (503): 
# REMOVED (503):     def _sync_search():
# REMOVED (503):         api_key = get_api_key()
# REMOVED (503):         headers = {"Authorization": f"Bearer {api_key}"}
# REMOVED (503):         url = f"{API_BASE_URL}/vulnerabilities"
# REMOVED (503): 
# REMOVED (503):         # Add time filtering (recent 30 days for vulns)
# REMOVED (503):         time_filter = TIME_RANGES["context"].format_api_filter("flashpoint")
# REMOVED (503): 
# REMOVED (503):         params = {
# REMOVED (503):             "query": product,
# REMOVED (503):             "limit": limit,
# REMOVED (503):             **time_filter
# REMOVED (503):         }
# REMOVED (503): 
# REMOVED (503):         try:
# REMOVED (503):             # Disable SSL verification for corporate proxy/firewall environments
# REMOVED (503):             resp = requests.get(url, headers=headers, params=params, timeout=30, verify=False)
# REMOVED (503): 
# REMOVED (503):             # Handle different HTTP status codes
# REMOVED (503):             if resp.status_code == 404:
# REMOVED (503):                 record_api_failure("flashpoint", is_rate_limit=False)
# REMOVED (503):                 log_api_call(
# REMOVED (503):                     source="flashpoint",
# REMOVED (503):                     module="vulnerabilities",
# REMOVED (503):                     operation="search_vulnerabilities",
# REMOVED (503):                     query=product,
# REMOVED (503):                     status="error",
# REMOVED (503):                     error="Not found",
# REMOVED (503):                     error_code="404",
# REMOVED (503):                     endpoint="/api/v4/vulnerabilities"
# REMOVED (503):                 )
# REMOVED (503):                 raise FlashpointNotFoundError(f"Flashpoint endpoint not found: {url}")
# REMOVED (503): 
# REMOVED (503):             elif resp.status_code in [429, 503]:
# REMOVED (503):                 record_api_failure("flashpoint", is_rate_limit=True)
# REMOVED (503):                 log_api_call(
# REMOVED (503):                     source="flashpoint",
# REMOVED (503):                     module="vulnerabilities",
# REMOVED (503):                     operation="search_vulnerabilities",
# REMOVED (503):                     query=product,
# REMOVED (503):                     status="error",
# REMOVED (503):                     error="Rate limit exceeded",
# REMOVED (503):                     error_code=str(resp.status_code),
# REMOVED (503):                     endpoint="/api/v4/vulnerabilities"
# REMOVED (503):                 )
# REMOVED (503):                 raise FlashpointRateLimitError(f"Flashpoint rate limit: HTTP {resp.status_code}")
# REMOVED (503): 
# REMOVED (503):             elif resp.status_code != 200:
# REMOVED (503):                 record_api_failure("flashpoint", is_rate_limit=False)
# REMOVED (503):                 log_api_call(
# REMOVED (503):                     source="flashpoint",
# REMOVED (503):                     module="vulnerabilities",
# REMOVED (503):                     operation="search_vulnerabilities",
# REMOVED (503):                     query=product,
# REMOVED (503):                     status="error",
# REMOVED (503):                     error=f"HTTP {resp.status_code}",
# REMOVED (503):                     error_code=str(resp.status_code),
# REMOVED (503):                     endpoint="/api/v4/vulnerabilities"
# REMOVED (503):                 )
# REMOVED (503):                 raise Exception(f"Flashpoint API error: HTTP {resp.status_code}")
# REMOVED (503): 
# REMOVED (503):             # Success
# REMOVED (503):             data = resp.json()
# REMOVED (503): 
# REMOVED (503):             # Validate response schema
# REMOVED (503):             validate_response_schema(data, "vulnerabilities")
# REMOVED (503): 
# REMOVED (503):             results = [{
# REMOVED (503):                 "cve_id": item.get("cve_id", ""),
# REMOVED (503):                 "title": item.get("title", ""),
# REMOVED (503):                 "description": item.get("description", "")[:300],
# REMOVED (503):                 "cvss_score": item.get("cvss_score", 0),
# REMOVED (503):                 "exploit_available": item.get("exploit_available", False),
# REMOVED (503):                 "exploited_in_wild": item.get("exploited_in_wild", False),
# REMOVED (503):                 "published_date": item.get("published_date", ""),
# REMOVED (503):                 "source": "flashpoint"
# REMOVED (503):             } for item in data.get("data", [])]
# REMOVED (503): 
# REMOVED (503):             record_api_success("flashpoint")
# REMOVED (503):             log_api_call(
# REMOVED (503):                 source="flashpoint",
# REMOVED (503):                 module="vulnerabilities",
# REMOVED (503):                 operation="search_vulnerabilities",
# REMOVED (503):                 query=product,
# REMOVED (503):                 status="success",
# REMOVED (503):                 result_count=len(results),
# REMOVED (503):                 endpoint="/api/v4/vulnerabilities"
# REMOVED (503):             )
# REMOVED (503): 
# REMOVED (503):             return results
# REMOVED (503): 
# REMOVED (503):         except (FlashpointNotFoundError, FlashpointRateLimitError):
# REMOVED (503):             raise
# REMOVED (503):         except Exception as e:
# REMOVED (503):             record_api_failure("flashpoint", is_rate_limit=False)
# REMOVED (503):             if "HTTP" not in str(e):
# REMOVED (503):                 log_api_call(
# REMOVED (503):                     source="flashpoint",
# REMOVED (503):                     module="vulnerabilities",
# REMOVED (503):                     operation="search_vulnerabilities",
# REMOVED (503):                     query=product,
# REMOVED (503):                     status="error",
# REMOVED (503):                     error=str(e),
# REMOVED (503):                     endpoint="/api/v4/vulnerabilities"
# REMOVED (503):                 )
# REMOVED (503):             raise
# REMOVED (503): 
# REMOVED (503):     return await asyncio.to_thread(_sync_search)


async def search_all(org_profile: Dict[str, Any]) -> Dict[str, Any]:
    """
    Flashpoint intelligence collection using VALIDATED endpoints only

    Collects (enumerated 2026-02-11):
    - Compromised credentials (/indicators/simple - working)
    - Finished intelligence reports (/reports - working)

    REMOVED (returned 404 during enumeration):
    - Forums/communities
    - Vulnerabilities
    - Paste sites
    - Malware

    Args:
        org_profile: Organization profile dict

    Returns:
        Combined intelligence from validated Flashpoint endpoints
    """
    print("  [Flashpoint] Dark web intelligence collection (validated endpoints only)...")

    # Extract search targets
    domains = org_profile.get("domains", [])
    org_name = org_profile.get("organization", "")
    brands = org_profile.get("brands", [])
    industry = org_profile.get("industry", "")

    # Parallel queries - ONLY use validated working endpoints
    tasks = []

    # 1. Compromised credentials for domains (✓ /indicators/simple)
    for domain in domains[:3]:
        tasks.append(search_credentials(domain))

    # 2. Finished intelligence reports (✓ /reports)
    if industry:
        tasks.append(search_reports(industry))
    if org_name:
        tasks.append(search_reports(org_name))
    for brand in brands[:2]:
        tasks.append(search_reports(brand))

    print(f"  [Flashpoint] Executing {len(tasks)} parallel queries (validated endpoints)...")

    # Execute in parallel
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # Organize results (only credentials and reports work)
    credentials = []
    reports = []

    for result in results:
        if isinstance(result, Exception):
            continue

        if isinstance(result, list):
            for item in result:
                if "indicator_type" in item:
                    credentials.append(item)
                elif "title" in item and "platform_url" in item:
                    reports.append(item)

    # Add recency scoring
    credentials = add_recency_score(credentials, "first_seen")
    reports = add_recency_score(reports, "date")

    print(f"  [Flashpoint] ✓ Collected:")
    print(f"    - {len(credentials)} compromised credentials {format_trend_summary(credentials, 'first_seen')}")
    print(f"    - {len(reports)} analyst reports {format_trend_summary(reports, 'date')}")

    return {
        "credentials": credentials,
        "reports": reports,
        "source": "flashpoint"
    }
