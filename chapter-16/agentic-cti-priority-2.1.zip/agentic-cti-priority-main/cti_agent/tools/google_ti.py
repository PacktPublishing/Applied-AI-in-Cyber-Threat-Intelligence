"""
Google Threat Intelligence (VirusTotal) tools

Simple vt-py SDK wrappers for intelligence gathering
Read-only operations for shared GCP project safety
"""

import vt
import os
from typing import Dict, List, Optional, Any
import asyncio
from ._query_logger import get_logger
from ._rate_limiter import rate_limit_gti
from ._retry import retry_async
from ._time_utils import TIME_RANGES, add_recency_score, format_trend_summary
from ._api_tracker import log_api_call


def get_client() -> vt.Client:
    """
    Initialize VirusTotal client from environment

    Returns:
        vt.Client instance

    Raises:
        ValueError: If GTI_API_KEY not found
    """
    api_key = os.environ.get("GTI_API_KEY")
    if not api_key:
        raise ValueError(
            "GTI_API_KEY not found in environment.\n"
            "Run: gcloud auth login\n"
            "Secrets should be loaded from GSM automatically."
        )
    # Disable SSL verification for corporate proxy/firewall environments
    return vt.Client(api_key, verify_ssl=False)


@retry_async("gti")
async def search_domain(domain: str) -> Dict[str, Any]:
    """
    Search Google TI for domain intelligence

    Args:
        domain: Domain to search (e.g., "example.com")

    Returns:
        Domain intelligence dict with reputation, categories, etc.

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    logger = get_logger()

    # Rate limiting
    await rate_limit_gti()

    client = get_client()
    try:
        # Get domain object using async method
        domain_obj = await client.get_object_async(f"/domains/{domain}")

        result = {
            "domain": domain,
            "reputation": domain_obj.reputation if hasattr(domain_obj, 'reputation') else 0,
            "last_analysis_stats": domain_obj.last_analysis_stats if hasattr(domain_obj, 'last_analysis_stats') else {},
            "categories": domain_obj.categories if hasattr(domain_obj, 'categories') else {},
            "tags": domain_obj.tags if hasattr(domain_obj, 'tags') else [],
            "total_votes": {
                "harmless": domain_obj.total_votes.get("harmless", 0) if hasattr(domain_obj, 'total_votes') else 0,
                "malicious": domain_obj.total_votes.get("malicious", 0) if hasattr(domain_obj, 'total_votes') else 0
            },
            "source": "google_ti"
        }

        # Log query (legacy logger)
        logger.log_query(
            source="google_ti",
            query_type="domain",
            query=domain,
            response_summary={
                "count": 1,
                "reputation": result["reputation"],
                "tags": len(result["tags"])
            }
        )

        # Log to API tracker
        log_api_call(
            source="google_ti",
            module="domains",
            operation="search_domain",
            query=domain,
            status="success",

            endpoint="vt.domains",
            result_count=1
        )

        return result
    except Exception as e:
        # Log error to API tracker
        log_api_call(
            source="google_ti",
            module="domains",
            operation="search_domain",
            query=domain,
            status="error",

            endpoint="vt.domains",
            error=str(e)
        )
        raise
    finally:
        try:
            # Force close with 2-second timeout to prevent hanging
            await asyncio.wait_for(client.close_async(), timeout=2.0)
        except (asyncio.TimeoutError, Exception):
            # Suppress SSL close timeout errors (expected with verify_ssl=False)
            pass


@retry_async("gti")
async def search_ip(ip_address: str) -> Dict[str, Any]:
    """
    Search Google TI for IP address intelligence

    Args:
        ip_address: IP address to search

    Returns:
        IP intelligence dict

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    # Rate limiting
    await rate_limit_gti()

    client = get_client()
    try:
        # Use async method
        ip_obj = await client.get_object_async(f"/ip_addresses/{ip_address}")

        result = {
            "ip": ip_address,
            "reputation": ip_obj.reputation if hasattr(ip_obj, 'reputation') else 0,
            "last_analysis_stats": ip_obj.last_analysis_stats if hasattr(ip_obj, 'last_analysis_stats') else {},
            "country": ip_obj.country if hasattr(ip_obj, 'country') else "Unknown",
            "asn": ip_obj.asn if hasattr(ip_obj, 'asn') else "Unknown",
            "as_owner": ip_obj.as_owner if hasattr(ip_obj, 'as_owner') else "Unknown",
            "tags": ip_obj.tags if hasattr(ip_obj, 'tags') else [],
            "source": "google_ti"
        }

        return result
    finally:
        try:
            # Force close with 2-second timeout to prevent hanging
            await asyncio.wait_for(client.close_async(), timeout=2.0)
        except (asyncio.TimeoutError, Exception):
            # Suppress SSL close timeout errors (expected with verify_ssl=False)
            pass


@retry_async("gti")
async def search_threat_actors(query: str, limit: int = 10) -> List[Dict[str, Any]]:
    """
    Search for threat actors related to query using GTI Intelligence Search

    Args:
        query: Search query (org name, industry, etc.)
        limit: Max results to return

    Returns:
        List of threat actor dicts with detailed profiles

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    logger = get_logger()

    # Rate limiting
    await rate_limit_gti()

    client = get_client()
    try:
        # Search threat actors using async iterator
        search_query = f'entity:threat_actor "{query}"'
        results = client.iterator(
            f"/intelligence/search?query={search_query}",
            limit=limit
        )

        actors = []
        async for item in results:
            if hasattr(item, 'attributes'):
                actors.append({
                    "id": item.id if hasattr(item, 'id') else "unknown",
                    "name": item.attributes.get("name", "Unknown"),
                    "description": item.attributes.get("description", "")[:500],
                    "aliases": item.attributes.get("aliases", []),
                    "industries_targeted": item.attributes.get("target_industries", []),
                    "countries_targeted": item.attributes.get("target_countries", []),
                    "first_seen": item.attributes.get("first_seen", ""),
                    "last_seen": item.attributes.get("last_updated", ""),
                    "source": "google_ti",
                    "url": f"https://www.virustotal.com/gui/threat-actor/{item.id}"
                })

        logger.log_query(
            source="google_ti",
            query_type="threat_actors",
            query=query,
            response_summary={"count": len(actors)}
        )

        # Log to API tracker
        log_api_call(
            source="google_ti",
            module="threat_actors",
            operation="search_threat_actors",
            query=query,
            status="success",

            endpoint="vt.threat_actors",
            result_count=len(actors)
        )

        return actors
    except Exception as e:
        # Log error to API tracker
        log_api_call(
            source="google_ti",
            module="threat_actors",
            operation="search_threat_actors",
            query=query,
            status="error",

            endpoint="vt.threat_actors",
            error=str(e)
        )
        raise
    finally:
        try:
            # Force close with 2-second timeout to prevent hanging
            await asyncio.wait_for(client.close_async(), timeout=2.0)
        except (asyncio.TimeoutError, Exception):
            # Suppress SSL close timeout errors (expected with verify_ssl=False)
            pass


@retry_async("gti")
async def search_intelligence_reports(query: str, limit: int = 10) -> List[Dict[str, Any]]:
    """
    Search GTI Intelligence Reports (analyst-written reports)

    Args:
        query: Search query (industry, threat actor, org name)
        limit: Max results

    Returns:
        List of intelligence report summaries

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    logger = get_logger()

    # Rate limiting
    await rate_limit_gti()

    client = get_client()
    try:
        # Search general intelligence (reports not available in all GTI tiers)
        # Use broader search without entity type restriction
        search_query = f'"{query}"'
        results = client.iterator(
            f"/intelligence/search?query={search_query}",
            limit=limit
        )

        reports = []
        async for item in results:
            if hasattr(item, 'attributes'):
                # Filter for report-like items
                if hasattr(item, 'type') and 'report' in item.type.lower():
                    reports.append({
                        "id": item.id if hasattr(item, 'id') else "unknown",
                        "title": item.attributes.get("title", item.attributes.get("name", "Untitled")),
                        "summary": item.attributes.get("text", item.attributes.get("description", ""))[:500],
                        "date": item.attributes.get("date", item.attributes.get("created_date", "")),
                        "tags": item.attributes.get("tags", []),
                        "source": "google_ti",
                        "url": f"https://www.virustotal.com/gui/intelligence-overview"
                    })

        logger.log_query(
            source="google_ti",
            query_type="intelligence_reports",
            query=query,
            response_summary={"count": len(reports)}
        )

        # Log to API tracker
        log_api_call(
            source="google_ti",
            module="intelligence_reports",
            operation="search_intelligence_reports",
            query=query,
            status="success",

            endpoint="vt.intelligence_reports",
            result_count=len(reports)
        )

        return reports
    except Exception as e:
        # Log error to API tracker
        log_api_call(
            source="google_ti",
            module="intelligence_reports",
            operation="search_intelligence_reports",
            query=query,
            status="error",

            endpoint="vt.intelligence_reports",
            error=str(e)
        )
        raise
    finally:
        try:
            # Force close with 2-second timeout to prevent hanging
            await asyncio.wait_for(client.close_async(), timeout=2.0)
        except (asyncio.TimeoutError, Exception):
            # Suppress SSL close timeout errors (expected with verify_ssl=False)
            pass


@retry_async("gti")
async def search_collections(industry: str = None) -> List[Dict[str, Any]]:
    """
    Search GTI Collections (curated threat intelligence)

    Args:
        industry: Optional industry filter

    Returns:
        List of relevant collections

    Raises:
        Exception: On API errors (retry decorator handles retries)
    """
    logger = get_logger()

    # Rate limiting
    await rate_limit_gti()

    client = get_client()
    try:
        # Search collections using async iterator
        query = f"entity:collection"
        if industry:
            query += f" {industry}"

        results = client.iterator(
            f"/intelligence/search?query={query}",
            limit=20
        )

        collections = []
        async for item in results:
            if hasattr(item, 'attributes'):
                collections.append({
                    "id": item.id if hasattr(item, 'id') else "unknown",
                    "name": item.attributes.get("name", "Unknown"),
                    "description": item.attributes.get("description", "")[:300],
                    "type": item.attributes.get("type", ""),
                    "source": "google_ti"
                })

        logger.log_query(
            source="google_ti",
            query_type="collections",
            query=industry or "all",
            response_summary={"count": len(collections)}
        )

        # Log to API tracker
        log_api_call(
            source="google_ti",
            module="collections",
            operation="search_collections",
            query=industry or "all",
            status="success",

            endpoint="vt.collections",
            result_count=len(collections)
        )

        return collections
    except Exception as e:
        # Log error to API tracker
        log_api_call(
            source="google_ti",
            module="collections",
            operation="search_collections",
            query=industry or "all",
            status="error",

            endpoint="vt.collections",
            error=str(e)
        )
        raise
    finally:
        try:
            # Force close with 2-second timeout to prevent hanging
            await asyncio.wait_for(client.close_async(), timeout=2.0)
        except (asyncio.TimeoutError, Exception):
            # Suppress SSL close timeout errors (expected with verify_ssl=False)
            pass


async def search_all(org_profile: Dict[str, Any]) -> Dict[str, Any]:
    """
    Comprehensive GTI intelligence collection using ALL available APIs

    Collects:
    - Domain/IP reputation (basic)
    - Threat actors targeting industry
    - Intelligence reports
    - Collections relevant to industry
    - Detailed threat actor profiles

    Args:
        org_profile: Organization profile dict

    Returns:
        Combined intelligence from all GTI capabilities
    """
    print("  [GTI] Comprehensive intelligence collection...")

    # Extract search targets
    domains = org_profile.get("domains", [])
    org_name = org_profile.get("organization", "")
    industry = org_profile.get("industry", "")

    # Parallel queries - use ALL GTI capabilities
    tasks = []

    # 1. Basic indicators (domains/IPs)
    for domain in domains[:5]:
        tasks.append(search_domain(domain))

    # 2. Threat actor intelligence (industry-based)
    if industry:
        tasks.append(search_threat_actors(industry))
    if org_name:
        tasks.append(search_threat_actors(org_name))

    # 3. Intelligence reports (analyst-written research)
    if industry:
        tasks.append(search_intelligence_reports(industry))
    if org_name:
        tasks.append(search_intelligence_reports(org_name))

    # 4. Curated collections for industry
    if industry:
        tasks.append(search_collections(industry))

    print(f"  [GTI] Executing {len(tasks)} parallel queries across all GTI APIs...")

    # Execute all queries in parallel
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # Organize results by type
    domain_results = []
    threat_actors = []
    intelligence_reports = []
    collections = []

    for i, result in enumerate(results):
        if isinstance(result, Exception):
            print(f"  [GTI] Query {i} failed: {result}")
            continue

        if isinstance(result, dict) and "domain" in result:
            domain_results.append(result)
        elif isinstance(result, list):
            # Determine type by structure (validate first item is dict)
            if len(result) > 0 and isinstance(result[0], dict):
                first_item = result[0]
                if "title" in first_item and "summary" in first_item:
                    intelligence_reports.extend(result)
                elif "name" in first_item and "description" in first_item:
                    if "type" in first_item:
                        collections.extend(result)
                    else:
                        threat_actors.extend(result)
                else:
                    threat_actors.extend(result)

    # Add recency scoring
    threat_actors = add_recency_score(threat_actors, "last_seen")
    intelligence_reports = add_recency_score(intelligence_reports, "date")

    print(f"  [GTI] ✓ Collected:")
    print(f"    - {len(domain_results)} domains")
    print(f"    - {len(threat_actors)} threat actors {format_trend_summary(threat_actors, 'last_seen')}")
    print(f"    - {len(intelligence_reports)} intelligence reports {format_trend_summary(intelligence_reports, 'date')}")
    print(f"    - {len(collections)} curated collections")

    return {
        "domains": domain_results,
        "threat_actors": threat_actors,
        "intelligence_reports": intelligence_reports,
        "collections": collections,
        "source": "google_ti"
    }
