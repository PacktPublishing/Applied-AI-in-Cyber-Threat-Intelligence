"""
Time-based filtering utilities for CTI intelligence gathering

Provides consistent time scoping across all intelligence sources:
- 24 hours (highest priority - emerging threats)
- 7 days (trends and patterns)
- 30 days (context and historical analysis)
"""

from datetime import datetime, timedelta, timezone
from typing import Dict, Any, List, Optional
from dateutil import parser as date_parser


class TimeRange:
    """Time range for intelligence filtering"""

    def __init__(self, hours: Optional[int] = None, days: Optional[int] = None):
        """
        Initialize time range

        Args:
            hours: Number of hours back from now
            days: Number of days back from now
        """
        self.now = datetime.now(timezone.utc)

        if hours is not None:
            self.start = self.now - timedelta(hours=hours)
            self.label = f"{hours}h"
        elif days is not None:
            self.start = self.now - timedelta(days=days)
            self.label = f"{days}d"
        else:
            raise ValueError("Must specify either hours or days")

        self.end = self.now

    def contains(self, timestamp: str) -> bool:
        """
        Check if timestamp falls within this range

        Args:
            timestamp: ISO 8601 timestamp string or various common formats

        Returns:
            True if timestamp is within range
        """
        if not timestamp:
            return False

        try:
            dt = date_parser.parse(timestamp)
            # Make timezone-aware if naive
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return self.start <= dt <= self.end
        except (ValueError, TypeError):
            return False

    def format_api_filter(self, api_type: str) -> Dict[str, Any]:
        """
        Format time range for specific API type

        Args:
            api_type: API type (gti, flashpoint, crowdstrike, etc.)

        Returns:
            API-specific time filter parameters
        """
        if api_type == "gti":
            # VirusTotal uses timestamps in UNIX epoch
            return {
                "first_submission_date": f"{int(self.start.timestamp())}+",
                "last_analysis_date": f"{int(self.start.timestamp())}+"
            }
        elif api_type == "flashpoint":
            # Flashpoint uses ISO 8601 date strings
            return {
                "since": self.start.strftime("%Y-%m-%d"),
                "until": self.end.strftime("%Y-%m-%d")
            }
        elif api_type == "crowdstrike":
            # CrowdStrike uses filter syntax
            return {
                "filter": f"published_date:>='{self.start.strftime('%Y-%m-%d')}'"
            }
        else:
            # Generic ISO 8601
            return {
                "start_date": self.start.isoformat(),
                "end_date": self.end.isoformat()
            }

    def __repr__(self):
        return f"TimeRange({self.label}: {self.start.isoformat()} to {self.end.isoformat()})"


# Standard time ranges for CTI analysis
TIME_RANGES = {
    "critical": TimeRange(hours=24),   # Last 24 hours - emerging threats
    "recent": TimeRange(days=7),       # Last 7 days - trends
    "context": TimeRange(days=30)      # Last 30 days - patterns
}


def classify_by_recency(findings: List[Dict[str, Any]], timestamp_field: str = "date") -> Dict[str, List[Dict]]:
    """
    Classify findings by recency

    Args:
        findings: List of finding dictionaries
        timestamp_field: Field name containing timestamp

    Returns:
        Dictionary with keys: critical (24h), recent (7d), context (30d), older
    """
    classified = {
        "critical": [],  # Last 24 hours
        "recent": [],    # Last 7 days (excluding 24h)
        "context": [],   # Last 30 days (excluding 7d)
        "older": []      # Older than 30 days
    }

    for finding in findings:
        timestamp = finding.get(timestamp_field, "")

        if TIME_RANGES["critical"].contains(timestamp):
            classified["critical"].append(finding)
        elif TIME_RANGES["recent"].contains(timestamp):
            classified["recent"].append(finding)
        elif TIME_RANGES["context"].contains(timestamp):
            classified["context"].append(finding)
        else:
            classified["older"].append(finding)

    return classified


def add_recency_score(findings: List[Dict[str, Any]], timestamp_field: str = "date") -> List[Dict[str, Any]]:
    """
    Add recency score to findings (1.0 = last 24h, 0.0 = >30d)

    Args:
        findings: List of finding dictionaries
        timestamp_field: Field name containing timestamp

    Returns:
        Findings with added recency_score field
    """
    for finding in findings:
        timestamp = finding.get(timestamp_field, "")

        if TIME_RANGES["critical"].contains(timestamp):
            finding["recency_score"] = 1.0
            finding["recency_label"] = "critical (24h)"
        elif TIME_RANGES["recent"].contains(timestamp):
            finding["recency_score"] = 0.7
            finding["recency_label"] = "recent (7d)"
        elif TIME_RANGES["context"].contains(timestamp):
            finding["recency_score"] = 0.4
            finding["recency_label"] = "context (30d)"
        else:
            finding["recency_score"] = 0.1
            finding["recency_label"] = "older (>30d)"

    return findings


def format_trend_summary(findings: List[Dict[str, Any]], timestamp_field: str = "date") -> str:
    """
    Generate trend summary text

    Args:
        findings: List of finding dictionaries
        timestamp_field: Field name containing timestamp

    Returns:
        Human-readable trend summary
    """
    classified = classify_by_recency(findings, timestamp_field)

    summary_lines = []
    if classified["critical"]:
        summary_lines.append(f"🔴 {len(classified['critical'])} in last 24 hours (CRITICAL)")
    if classified["recent"]:
        summary_lines.append(f"🟡 {len(classified['recent'])} in last 7 days")
    if classified["context"]:
        summary_lines.append(f"🟢 {len(classified['context'])} in last 30 days")
    if classified["older"]:
        summary_lines.append(f"⚪ {len(classified['older'])} older than 30 days")

    if not summary_lines:
        return "No temporal data available"

    return " | ".join(summary_lines)
