"""
API Rate Limiting for CTI Intelligence Sources

Ensures we stay within quota limits for all external APIs:
- Google Threat Intelligence (VirusTotal)
- Flashpoint
- CrowdStrike Falcon
- OSINT sources (RSS feeds, public lookups)
- Vertex AI (LLM calls)
"""

import time
import asyncio
from typing import Dict, Optional
from collections import defaultdict
from datetime import datetime, timedelta


class CircuitBreaker:
    """
    Circuit breaker for API fault tolerance

    Prevents cascading failures by stopping requests to failing services:
    - CLOSED: Normal operation, requests allowed
    - OPEN: Too many failures, requests blocked
    - HALF_OPEN: Testing if service recovered
    """

    def __init__(
        self,
        failure_threshold: int = 3,
        recovery_timeout: float = 300.0,  # 5 minutes
        success_threshold: int = 2  # Successes needed to close from half-open
    ):
        """
        Initialize circuit breaker

        Args:
            failure_threshold: Consecutive failures before opening circuit
            recovery_timeout: Seconds before attempting recovery (half-open)
            success_threshold: Consecutive successes to close circuit from half-open
        """
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.success_threshold = success_threshold

        self.state = "closed"  # closed, open, half_open
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time: Optional[float] = None
        self.last_state_change: float = time.time()

    def can_attempt(self) -> bool:
        """Check if request should be attempted"""
        if self.state == "closed":
            return True

        if self.state == "open":
            # Check if recovery timeout elapsed
            if self.last_failure_time and (time.time() - self.last_failure_time) >= self.recovery_timeout:
                self._transition_to_half_open()
                return True
            return False

        if self.state == "half_open":
            # Allow one test request
            return True

        return False

    def record_success(self):
        """Record successful request"""
        if self.state == "closed":
            # Reset failure count on success
            self.failure_count = 0

        elif self.state == "half_open":
            self.success_count += 1
            if self.success_count >= self.success_threshold:
                self._transition_to_closed()

    def record_failure(self, is_rate_limit: bool = False):
        """
        Record failed request

        Args:
            is_rate_limit: True if failure was due to rate limit (503)
        """
        self.last_failure_time = time.time()

        if self.state == "closed":
            self.failure_count += 1
            if self.failure_count >= self.failure_threshold:
                self._transition_to_open()

        elif self.state == "half_open":
            # Single failure in half-open → back to open
            self._transition_to_open()

    def _transition_to_open(self):
        """Transition to OPEN state"""
        self.state = "open"
        self.last_state_change = time.time()
        print(f"  [CircuitBreaker] OPEN - Too many failures, blocking requests for {self.recovery_timeout}s")

    def _transition_to_half_open(self):
        """Transition to HALF_OPEN state"""
        self.state = "half_open"
        self.success_count = 0
        self.last_state_change = time.time()
        print(f"  [CircuitBreaker] HALF_OPEN - Testing service recovery...")

    def _transition_to_closed(self):
        """Transition to CLOSED state"""
        self.state = "closed"
        self.failure_count = 0
        self.success_count = 0
        self.last_state_change = time.time()
        print(f"  [CircuitBreaker] CLOSED - Service recovered, resuming normal operation")

    def get_status(self) -> Dict[str, any]:
        """Get circuit breaker status"""
        time_since_change = time.time() - self.last_state_change

        status = {
            "state": self.state,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "time_in_state": f"{time_since_change:.1f}s"
        }

        if self.state == "open" and self.last_failure_time:
            time_until_recovery = max(0, self.recovery_timeout - (time.time() - self.last_failure_time))
            status["recovery_in"] = f"{time_until_recovery:.1f}s"

        return status


class RateLimiter:
    """
    Token bucket rate limiter for API calls

    Tracks calls per source and enforces delays to stay within limits
    """

    # API rate limits (requests per minute)
    # Updated 2026-02-10 based on official documentation
    DEFAULT_LIMITS = {
        # Premium APIs (actual documented limits from user's accounts)
        "gti": 1000,             # VirusTotal Premium: 10K/min shared across group (using 10% to be safe)
        "flashpoint": 30,        # Flashpoint: Conservative (5000/day = ~3.5/min, recommend 2hr intervals)
        "crowdstrike": 6000,     # CrowdStrike: Account-specific (example showed 6000/min, read from headers)

        # Vertex AI (ACTUAL documented limits - 2026-02-10)
        # Source: https://cloud.google.com/vertex-ai/docs/quotas
        # Online inference: 30,000 RPM per region (shared across all models)
        "vertex_pro": 3000,      # Gemini 2.5 Pro: ~10% of 30k RPM (conservative, shared pool)
        "vertex_flash": 3000,    # Gemini 2.5 Flash: ~10% of 30k RPM (conservative, shared pool)

        # Free/Public APIs (more conservative)
        "osint_rss": 30,         # RSS feeds: 30/min (be polite)
        "osint_lookup": 10,      # Free lookup sites: 10/min (very conservative)

        # Default for unknown sources
        "default": 20
    }

    def __init__(self):
        """Initialize rate limiter"""
        self.call_history: Dict[str, list] = defaultdict(list)
        self.last_call: Dict[str, float] = {}

        # Circuit breakers for fault-prone APIs
        self.circuit_breakers: Dict[str, CircuitBreaker] = {
            "flashpoint": CircuitBreaker(
                failure_threshold=3,  # 3 consecutive failures
                recovery_timeout=300.0,  # 5 minute cooldown
                success_threshold=2  # 2 successes to close
            )
        }

    def _clean_history(self, source: str, window_seconds: int = 60):
        """Remove calls older than the time window"""
        cutoff = time.time() - window_seconds
        self.call_history[source] = [
            t for t in self.call_history[source] if t > cutoff
        ]

    def can_call(self, source: str) -> bool:
        """
        Check if we can make a call without exceeding rate limit

        Args:
            source: API source identifier (gti, flashpoint, etc.)

        Returns:
            True if call is allowed
        """
        self._clean_history(source)

        limit = self.DEFAULT_LIMITS.get(source, self.DEFAULT_LIMITS["default"])
        current_calls = len(self.call_history[source])

        return current_calls < limit

    def get_wait_time(self, source: str) -> float:
        """
        Get how long to wait before next call

        Args:
            source: API source identifier

        Returns:
            Seconds to wait (0.0 if can call immediately)
        """
        if self.can_call(source):
            return 0.0

        # Find oldest call in window
        self._clean_history(source)
        if not self.call_history[source]:
            return 0.0

        oldest_call = min(self.call_history[source])
        time_since_oldest = time.time() - oldest_call

        # Wait until oldest call falls out of 60s window
        return max(0.0, 60.0 - time_since_oldest)

    async def wait_if_needed(self, source: str, min_delay: Optional[float] = None):
        """
        Wait if needed to respect rate limits

        Args:
            source: API source identifier
            min_delay: Minimum delay between calls (seconds) regardless of rate limit
        """
        # Enforce minimum delay between calls
        if min_delay and source in self.last_call:
            time_since_last = time.time() - self.last_call[source]
            if time_since_last < min_delay:
                await asyncio.sleep(min_delay - time_since_last)

        # Enforce rate limit
        wait_time = self.get_wait_time(source)
        if wait_time > 0:
            print(f"  [RateLimit] Waiting {wait_time:.1f}s for {source} quota...")
            await asyncio.sleep(wait_time)

        # Record this call
        self.call_history[source].append(time.time())
        self.last_call[source] = time.time()

    def get_stats(self, source: str) -> Dict[str, any]:
        """
        Get rate limit statistics

        Args:
            source: API source identifier

        Returns:
            Dictionary with quota usage stats
        """
        self._clean_history(source)

        limit = self.DEFAULT_LIMITS.get(source, self.DEFAULT_LIMITS["default"])
        current_calls = len(self.call_history[source])

        stats = {
            "source": source,
            "limit_per_minute": limit,
            "calls_last_minute": current_calls,
            "quota_used_pct": (current_calls / limit) * 100 if limit > 0 else 0,
            "can_call": self.can_call(source),
            "wait_time_seconds": self.get_wait_time(source)
        }

        # Add circuit breaker status if exists
        if source in self.circuit_breakers:
            stats["circuit_breaker"] = self.circuit_breakers[source].get_status()

        return stats

    def check_circuit_breaker(self, source: str) -> bool:
        """
        Check if circuit breaker allows request

        Args:
            source: API source identifier

        Returns:
            True if request should be attempted
        """
        if source not in self.circuit_breakers:
            return True  # No circuit breaker for this source

        can_attempt = self.circuit_breakers[source].can_attempt()

        if not can_attempt:
            status = self.circuit_breakers[source].get_status()
            print(f"  [CircuitBreaker] {source.upper()} circuit is OPEN - blocking request")
            if "recovery_in" in status:
                print(f"  [CircuitBreaker] Will retry in {status['recovery_in']}")

        return can_attempt

    def record_success(self, source: str):
        """Record successful API call for circuit breaker"""
        if source in self.circuit_breakers:
            self.circuit_breakers[source].record_success()

    def record_failure(self, source: str, is_rate_limit: bool = False):
        """
        Record failed API call for circuit breaker

        Args:
            source: API source identifier
            is_rate_limit: True if failure was due to rate limit (503)
        """
        if source in self.circuit_breakers:
            self.circuit_breakers[source].record_failure(is_rate_limit=is_rate_limit)


# Global rate limiter instance
_rate_limiter = None


def get_rate_limiter() -> RateLimiter:
    """Get global rate limiter instance"""
    global _rate_limiter
    if _rate_limiter is None:
        _rate_limiter = RateLimiter()
    return _rate_limiter


async def rate_limit(source: str, min_delay: Optional[float] = None):
    """
    Decorator-friendly rate limiting

    Args:
        source: API source identifier
        min_delay: Minimum delay between calls (seconds)
    """
    limiter = get_rate_limiter()
    await limiter.wait_if_needed(source, min_delay)


# API-specific rate limiting helpers
async def rate_limit_gti():
    """Rate limit for Google Threat Intelligence (10K/min shared, using 1K/min)"""
    await rate_limit("gti", min_delay=0.06)  # Min 60ms between calls (1000/min = 1 per 60ms)


async def rate_limit_flashpoint():
    """Rate limit for Flashpoint"""
    await rate_limit("flashpoint", min_delay=1.0)  # Min 1s between calls (60/min = 1 call/sec)


async def rate_limit_crowdstrike():
    """Rate limit for CrowdStrike"""
    await rate_limit("crowdstrike", min_delay=0.6)  # Min 600ms between calls


async def rate_limit_vertex_pro():
    """Rate limit for Vertex AI Pro (most restrictive)"""
    await rate_limit("vertex_pro", min_delay=2.0)  # Min 2s between calls (30/min)


async def rate_limit_vertex_flash():
    """Rate limit for Vertex AI Flash"""
    await rate_limit("vertex_flash", min_delay=1.0)  # Min 1s between calls


async def rate_limit_osint_rss():
    """Rate limit for OSINT RSS feeds (be polite)"""
    await rate_limit("osint_rss", min_delay=2.0)  # Min 2s between feeds


async def rate_limit_osint_lookup():
    """Rate limit for free lookup sites (very conservative)"""
    await rate_limit("osint_lookup", min_delay=6.0)  # Min 6s between lookups (10/min)


# Circuit breaker helpers
def check_circuit_breaker(source: str) -> bool:
    """
    Check if circuit breaker allows request

    Args:
        source: API source identifier (e.g., "flashpoint")

    Returns:
        True if request should be attempted, False if circuit is open
    """
    limiter = get_rate_limiter()
    return limiter.check_circuit_breaker(source)


def record_api_success(source: str):
    """
    Record successful API call for circuit breaker

    Args:
        source: API source identifier
    """
    limiter = get_rate_limiter()
    limiter.record_success(source)


def record_api_failure(source: str, is_rate_limit: bool = False):
    """
    Record failed API call for circuit breaker

    Args:
        source: API source identifier
        is_rate_limit: True if failure was due to rate limit (503)
    """
    limiter = get_rate_limiter()
    limiter.record_failure(source, is_rate_limit=is_rate_limit)


def print_quota_summary():
    """Print quota usage summary for all sources"""
    limiter = get_rate_limiter()

    print("\n" + "="*60)
    print("API QUOTA USAGE SUMMARY")
    print("="*60)

    sources_with_activity = [
        source for source in limiter.call_history.keys()
        if len(limiter.call_history[source]) > 0
    ]

    if not sources_with_activity:
        print("No API calls tracked yet")
        return

    for source in sorted(sources_with_activity):
        stats = limiter.get_stats(source)
        print(f"\n{stats['source'].upper():20} | "
              f"Calls: {stats['calls_last_minute']:3}/{stats['limit_per_minute']:3} | "
              f"Usage: {stats['quota_used_pct']:5.1f}% | "
              f"Status: {'✓ OK' if stats['can_call'] else f'⏳ Wait {stats['wait_time_seconds']:.1f}s'}")

    print("="*60 + "\n")
