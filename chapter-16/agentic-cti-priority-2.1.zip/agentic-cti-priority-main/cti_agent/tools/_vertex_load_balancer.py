"""
Vertex AI Proactive Load Balancer

Instead of waiting for 429 errors, proactively distribute calls across regions
to maximize throughput and avoid quota exhaustion.

Strategy:
1. Round-robin across all regions
2. Track usage per region
3. Skip regions approaching quota limits
4. Fall back to retry only if necessary
"""

import time
from typing import Optional, List, Dict
from collections import defaultdict
import random


class VertexLoadBalancer:
    """
    Proactive load balancer for Vertex AI across multiple regions

    Distributes calls round-robin to avoid quota exhaustion in any single region
    """

    # Actual Vertex AI quotas (2026-02-10 from GCP documentation)
    # Source: https://cloud.google.com/vertex-ai/docs/quotas
    # Online inference requests: 30,000 RPM per region (shared across all models)

    # Conservative per-model limits (assume sharing the 30k pool)
    # We use 10% of total capacity per model to be safe
    LIMITS = {
        "gemini-2.5-pro": 3000,    # ~10% of 30k RPM per region
        "gemini-2.5-flash": 3000,  # ~10% of 30k RPM per region
        "gemini-2.0-flash": 3000,
        "gemini-1.5-pro": 3000,
        "gemini-1.5-flash": 3000,
    }

    # Burst allowance via token bucket algorithm
    # Vertex AI allows short bursts above sustained rate
    # We track this by allowing temporary exceedance
    BURST_MULTIPLIER = 1.5  # Allow 50% burst above sustained rate

    def __init__(self, regions: Optional[List[str]] = None):
        """
        Initialize load balancer

        Args:
            regions: List of regions to distribute across
        """
        if regions is None:
            # Default 8-region rotation
            regions = [
                "us-central1",
                "us-east5",
                "us-south1",
                "us-west4",
                "us-east1",
                "us-east4",
                "us-west1",
                "global"
            ]

        self.regions = regions
        self.current_index = 0

        # Track calls per region per model (sliding window)
        self.call_history: Dict[str, Dict[str, List[float]]] = defaultdict(
            lambda: defaultdict(list)
        )

        # Track failures per region
        self.failure_count: Dict[str, int] = defaultdict(int)

        # Randomize starting point to avoid all sessions hitting same region first
        self.current_index = random.randint(0, len(self.regions) - 1)

    def _clean_history(self, region: str, model: str, window_seconds: int = 60):
        """Remove calls older than the time window"""
        cutoff = time.time() - window_seconds
        self.call_history[region][model] = [
            t for t in self.call_history[region][model] if t > cutoff
        ]

    def _get_usage(self, region: str, model: str) -> int:
        """Get current usage for region/model in last 60 seconds"""
        self._clean_history(region, model)
        return len(self.call_history[region][model])

    def _get_quota_remaining(self, region: str, model: str) -> int:
        """Get remaining quota for region/model"""
        limit = self.LIMITS.get(model, 100)  # Default conservative limit
        usage = self._get_usage(region, model)
        return max(0, limit - usage)

    def _is_region_available(self, region: str, model: str, threshold: float = 0.8) -> bool:
        """
        Check if region has available quota

        Args:
            region: Region to check
            model: Model name
            threshold: Use region if <80% quota used (allows burst room)

        Returns:
            True if region has capacity
        """
        limit = self.LIMITS.get(model, 100)
        # Validate limit is positive (prevent division by zero)
        if limit <= 0:
            limit = 100  # Use safe default
        usage = self._get_usage(region, model)

        # Check if region has failed recently (circuit breaker)
        if self.failure_count[region] >= 3:
            return False

        # Allow burst up to BURST_MULTIPLIER × limit
        burst_limit = limit * self.BURST_MULTIPLIER

        # Check if under burst threshold
        # We use conservative threshold (80%) to leave room for burst
        return (usage / burst_limit) < threshold if burst_limit > 0 else True

    def get_next_region(self, model: str) -> str:
        """
        Get next available region using round-robin + availability check

        Args:
            model: Model name (e.g., "gemini-2.5-pro")

        Returns:
            Region name with available quota
        """
        # Try all regions in round-robin order
        for _ in range(len(self.regions)):
            region = self.regions[self.current_index]
            self.current_index = (self.current_index + 1) % len(self.regions)

            # Check if this region has capacity
            if self._is_region_available(region, model):
                return region

        # All regions near capacity - return least loaded
        return self._get_least_loaded_region(model)

    def _get_least_loaded_region(self, model: str) -> str:
        """Get region with most remaining quota"""
        regions_by_usage = [
            (region, self._get_usage(region, model))
            for region in self.regions
        ]
        if not regions_by_usage:
            raise ValueError("No regions available in load balancer")
        regions_by_usage.sort(key=lambda x: x[1])  # Sort by usage (ascending)
        return regions_by_usage[0][0]  # Return least loaded

    def record_call(self, region: str, model: str):
        """Record a successful call"""
        self.call_history[region][model].append(time.time())
        # Reset failure count on success
        if self.failure_count[region] > 0:
            self.failure_count[region] = max(0, self.failure_count[region] - 1)

    def record_failure(self, region: str):
        """Record a failed call (429, quota error, etc.)"""
        self.failure_count[region] += 1

    def reset_failures(self, region: str):
        """Reset failure count (e.g., after successful retry)"""
        self.failure_count[region] = 0

    def get_stats(self) -> Dict:
        """
        Get load balancer statistics

        Returns:
            Dictionary with per-region stats
        """
        stats = {}

        for region in self.regions:
            region_stats = {}
            for model in ["gemini-2.5-pro", "gemini-2.5-flash"]:
                usage = self._get_usage(region, model)
                limit = self.LIMITS.get(model, 100)
                region_stats[model] = {
                    "usage": usage,
                    "limit": limit,
                    "remaining": limit - usage,
                    "utilization_pct": (usage / limit * 100) if limit > 0 else 0
                }

            region_stats["failures"] = self.failure_count[region]
            region_stats["available"] = self._is_region_available(region, "gemini-2.5-pro")
            stats[region] = region_stats

        return stats

    def print_stats(self):
        """Print load balancer statistics"""
        stats = self.get_stats()

        print("\n" + "="*80)
        print("VERTEX AI LOAD BALANCER STATUS")
        print("="*80)

        for region, region_stats in stats.items():
            print(f"\n{region:20}")

            for model, model_stats in region_stats.items():
                if model in ["failures", "available"]:
                    continue

                status = "✓" if model_stats["remaining"] > 0 else "✗"
                print(f"  {model:25} | "
                      f"Usage: {model_stats['usage']:3}/{model_stats['limit']:4} | "
                      f"Util: {model_stats['utilization_pct']:5.1f}% | "
                      f"{status}")

            if region_stats["failures"] > 0:
                print(f"  ⚠️  Failures: {region_stats['failures']}")

        print("="*80 + "\n")


# Global load balancer instance
_load_balancer = None


def get_load_balancer() -> VertexLoadBalancer:
    """Get global load balancer instance"""
    global _load_balancer
    if _load_balancer is None:
        _load_balancer = VertexLoadBalancer()
    return _load_balancer


def get_next_vertex_region(model: str = "gemini-2.5-pro") -> str:
    """
    Get next available Vertex AI region

    Args:
        model: Model name

    Returns:
        Region with available quota
    """
    lb = get_load_balancer()
    return lb.get_next_region(model)


def record_vertex_call(region: str, model: str = "gemini-2.5-pro"):
    """Record a successful Vertex AI call"""
    lb = get_load_balancer()
    lb.record_call(region, model)


def record_vertex_failure(region: str):
    """Record a Vertex AI call failure (429, quota exhausted, etc.)"""
    lb = get_load_balancer()
    lb.record_failure(region)


def print_vertex_stats():
    """Print Vertex AI load balancer statistics"""
    lb = get_load_balancer()
    lb.print_stats()
