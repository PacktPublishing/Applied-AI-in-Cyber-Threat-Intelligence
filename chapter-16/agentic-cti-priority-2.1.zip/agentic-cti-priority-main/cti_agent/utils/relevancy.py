"""
Relevancy scoring for contextual intelligence

Scores how relevant news/OSINT findings are to actual threats found
"""

from typing import Dict, List, Any
from datetime import datetime, timedelta
import re


def calculate_relevancy_score(
    contextual_item: Dict[str, Any],
    threats: List[Dict[str, Any]],
    org_profile: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Calculate relevancy score for a contextual intelligence item

    Scoring factors:
    1. Keyword overlap with threats (0-40 points)
    2. Temporal proximity to threats (0-20 points)
    3. Industry/organization match (0-20 points)
    4. Threat actor mentions (0-20 points)

    Args:
        contextual_item: News/advisory item with title, summary, category, etc.
        threats: List of actual threats identified in analysis
        org_profile: Organization profile

    Returns:
        Enhanced contextual_item with "relevancy_score" and "relevancy_details"
    """
    score = 0
    details = []

    # Extract text for keyword matching
    item_text = (
        contextual_item.get("title", "") + " " +
        contextual_item.get("summary", "") + " " +
        contextual_item.get("why_it_matters", "")
    ).lower()

    org_name = org_profile.get("organization", "").lower()
    industry = org_profile.get("industry", "").lower()

    # 1. Keyword overlap with threats (0-40 points)
    threat_keywords = set()
    threat_actors = set()

    for threat in threats:
        # Extract keywords from threat
        threat_text = (
            threat.get("title", "") + " " +
            threat.get("summary", "") + " " +
            threat.get("threat_vector", "")
        ).lower()

        # Common threat terms
        threat_terms = re.findall(r'\b\w{4,}\b', threat_text)
        threat_keywords.update(threat_terms)

        # Threat actors
        if threat.get("suspected_attribution"):
            actor = threat["suspected_attribution"].get("actor", "")
            if actor:
                threat_actors.add(actor.lower())

    # Count keyword matches (excluding common words)
    common_words = {"the", "and", "with", "from", "that", "this", "have", "been", "were", "will"}
    item_terms = set(re.findall(r'\b\w{4,}\b', item_text)) - common_words
    keyword_overlap = len(item_terms & threat_keywords)

    if keyword_overlap > 5:
        score += 40
        details.append(f"High keyword overlap ({keyword_overlap} terms)")
    elif keyword_overlap > 2:
        score += 25
        details.append(f"Moderate keyword overlap ({keyword_overlap} terms)")
    elif keyword_overlap > 0:
        score += 10
        details.append(f"Low keyword overlap ({keyword_overlap} terms)")

    # 2. Temporal proximity (0-20 points)
    # Check if contextual item mentions recent time periods
    temporal_indicators = [
        "2026", "2025", "recent", "latest", "new", "emerging",
        "last week", "last month", "this year"
    ]

    temporal_matches = sum(1 for indicator in temporal_indicators if indicator in item_text)
    if temporal_matches > 2:
        score += 20
        details.append("Recent/current timeframe")
    elif temporal_matches > 0:
        score += 10
        details.append("Some temporal relevance")

    # 3. Industry/organization match (0-20 points)
    if org_name and org_name in item_text:
        score += 20
        details.append(f"Direct mention of {org_profile.get('organization')}")
    elif industry and industry in item_text:
        score += 15
        details.append(f"Industry match ({industry})")

    # Check for competitor mentions
    competitors = org_profile.get("competitors", [])
    for competitor in competitors[:5]:
        if competitor.lower() in item_text:
            score += 10
            details.append(f"Competitor mentioned ({competitor})")
            break

    # 4. Threat actor mentions (0-20 points)
    actor_matches = sum(1 for actor in threat_actors if actor in item_text)
    if actor_matches > 0:
        score += 20
        details.append(f"Threat actor correlation ({actor_matches} matches)")

    # Category bonuses
    category = contextual_item.get("category", "").lower()
    if category == "supply_chain" and any("supply" in t.get("threat_vector", "").lower() for t in threats):
        score += 10
        details.append("Supply chain threat correlation")

    if category == "regulatory" and industry:
        score += 5
        details.append("Regulatory context for industry")

    # Cap score at 100
    score = min(score, 100)

    # Add to item
    contextual_item["relevancy_score"] = score
    contextual_item["relevancy_details"] = details

    return contextual_item


def score_all_contextual_items(
    contextual_items: List[Dict[str, Any]],
    threats: List[Dict[str, Any]],
    org_profile: Dict[str, Any]
) -> List[Dict[str, Any]]:
    """
    Score all contextual intelligence items and sort by relevancy

    Args:
        contextual_items: List of news/advisories
        threats: List of actual threats found
        org_profile: Organization profile

    Returns:
        Sorted list with relevancy scores (highest first)
    """
    scored_items = []

    for item in contextual_items:
        scored_item = calculate_relevancy_score(item, threats, org_profile)
        scored_items.append(scored_item)

    # Sort by score (highest first)
    scored_items.sort(key=lambda x: x.get("relevancy_score", 0), reverse=True)

    return scored_items
