"""
Status logging for non-interactive mode

Logs key status updates to JSON-lines file for ADK/automation consumption
while preserving console output for interactive use.
"""

import os
import json
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any


class StatusLogger:
    """Thread-safe status logger for non-interactive mode"""

    def __init__(self, log_file: Optional[str] = None):
        """
        Initialize status logger

        Args:
            log_file: Path to status log file (default: from CTI_STATUS_LOG env var or disabled)
        """
        self.log_file = log_file or os.environ.get("CTI_STATUS_LOG")
        self.enabled = self.log_file is not None

        if self.enabled:
            # Ensure log file directory exists
            log_path = Path(self.log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)

            # Write initial status
            self.log_status("initialized", {"log_file": str(log_path)})

    def log_status(
        self,
        event: str,
        data: Optional[Dict[str, Any]] = None,
        print_message: Optional[str] = None
    ):
        """
        Log status event

        Args:
            event: Event name (e.g., "phase_started", "collection_complete")
            data: Event data dictionary
            print_message: Optional message to print to console
        """
        # Print to console if message provided
        if print_message:
            print(print_message)

        # Write to status log if enabled
        if not self.enabled:
            return

        status_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": event,
            "data": data or {}
        }

        try:
            with open(self.log_file, 'a') as f:
                f.write(json.dumps(status_entry) + '\n')
        except Exception as e:
            # Don't fail if logging fails
            print(f"[StatusLogger] Warning: Failed to write to status log: {e}")


# Global singleton
_logger: Optional[StatusLogger] = None


def get_status_logger() -> StatusLogger:
    """Get global status logger instance"""
    global _logger
    if _logger is None:
        _logger = StatusLogger()
    return _logger


def log_status(
    event: str,
    data: Optional[Dict[str, Any]] = None,
    print_message: Optional[str] = None
):
    """
    Convenience function to log status

    Args:
        event: Event name
        data: Event data
        print_message: Optional console message
    """
    get_status_logger().log_status(event, data, print_message)
