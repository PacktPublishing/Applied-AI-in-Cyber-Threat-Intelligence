"""
Output cleanup utility

Automatically removes old reports and logs to prevent disk bloat
"""

import os
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Tuple


def cleanup_old_files(
    output_dir: str = "output",
    max_age_days: int = 7,
    max_count: int = 50,
    min_size_bytes: int = 1024,
    dry_run: bool = False
) -> Tuple[int, int]:
    """
    Clean up old reports and logs from output directory

    Strategy:
    1. Delete files older than max_age_days
    2. If more than max_count files remain, delete oldest
    3. Always preserve last successful report (> min_size_bytes)

    Args:
        output_dir: Directory to clean (default: "output")
        max_age_days: Delete files older than this many days (default: 7)
        max_count: Max files to keep (default: 50)
        min_size_bytes: Minimum size for "successful" report (default: 1KB)
        dry_run: If True, only report what would be deleted

    Returns:
        Tuple of (files_deleted, bytes_freed)
    """
    output_path = Path(output_dir)
    if not output_path.exists():
        return (0, 0)

    # Patterns to clean
    patterns = [
        "report_*.html",
        "*.log",
        "test_*.log",
        "query_log_*.jsonl"
    ]

    # Find all matching files with metadata
    files_to_consider = []
    for pattern in patterns:
        for file_path in output_path.glob(pattern):
            # Skip latest_report.html symlink
            if file_path.name == "latest_report.html":
                continue

            try:
                stat = file_path.stat()
                files_to_consider.append({
                    "path": file_path,
                    "size": stat.st_size,
                    "mtime": datetime.fromtimestamp(stat.st_mtime),
                    "age_days": (datetime.now() - datetime.fromtimestamp(stat.st_mtime)).days
                })
            except OSError:
                # File may have been deleted or inaccessible
                continue

    if not files_to_consider:
        return (0, 0)

    # Find last successful report (largest recent report > min_size_bytes)
    reports = [f for f in files_to_consider if f["path"].name.startswith("report_") and f["size"] > min_size_bytes]
    reports.sort(key=lambda x: x["mtime"], reverse=True)
    last_successful_report = reports[0]["path"] if reports else None

    # Determine files to delete
    files_to_delete = []

    # Rule 1: Delete files older than max_age_days
    cutoff_date = datetime.now() - timedelta(days=max_age_days)
    for file_info in files_to_consider:
        if file_info["mtime"] < cutoff_date:
            # Preserve last successful report
            if last_successful_report and file_info["path"] == last_successful_report:
                continue
            files_to_delete.append(file_info)

    # Rule 2: If still too many files, delete oldest (excluding preserved report)
    remaining_files = [f for f in files_to_consider if f not in files_to_delete]
    if last_successful_report:
        remaining_files = [f for f in remaining_files if f["path"] != last_successful_report]

    if len(remaining_files) > max_count:
        # Sort by age (oldest first) and delete excess
        remaining_files.sort(key=lambda x: x["mtime"])
        excess_count = len(remaining_files) - max_count
        files_to_delete.extend(remaining_files[:excess_count])

    # Execute deletion
    files_deleted = 0
    bytes_freed = 0

    for file_info in files_to_delete:
        try:
            if dry_run:
                print(f"  [Cleanup] Would delete: {file_info['path'].name} ({file_info['size']:,} bytes, {file_info['age_days']} days old)")
            else:
                file_info["path"].unlink()
                files_deleted += 1
                bytes_freed += file_info["size"]
        except OSError as e:
            print(f"  [Cleanup] Failed to delete {file_info['path'].name}: {e}")

    return (files_deleted, bytes_freed)


def cleanup_after_report(output_dir: str = "output", verbose: bool = True) -> None:
    """
    Run cleanup after successful report generation

    Args:
        output_dir: Output directory to clean
        verbose: Print cleanup summary
    """
    files_deleted, bytes_freed = cleanup_old_files(output_dir=output_dir)

    if verbose and files_deleted > 0:
        print(f"\n[Cleanup] Removed {files_deleted} old files ({bytes_freed / 1024 / 1024:.2f} MB freed)")
