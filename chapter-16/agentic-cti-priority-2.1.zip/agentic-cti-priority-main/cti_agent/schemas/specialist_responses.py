"""
Pydantic schemas for specialist agent responses
These ensure deterministic structured output
"""

from typing import List, Optional
from pydantic import BaseModel, Field


class SpecialistStrategy(BaseModel):
    """Strategy planned by specialist agent"""
    search_strategy: str = Field(description="Brief description of search approach")
    queries_planned: List[str] = Field(description="List of queries to execute")
    competitors_identified: Optional[List[str]] = Field(default=None, description="Competitors identified (OSINT)")
    refinements_attempted: List[str] = Field(default_factory=list, description="Query refinements tried")


class Finding(BaseModel):
    """Individual intelligence finding"""
    type: str = Field(description="Type of finding: domain, ip, threat_actor, credential, news, etc.")
    value: str = Field(description="The actual value (domain name, IP, actor name, etc.)")
    confidence: str = Field(description="Confidence level: high, medium, low")
    relevance: str = Field(description="Why this matters to the organization")
    source: str = Field(description="Source: google_ti, flashpoint, crowdstrike, osint")
    url: Optional[str] = Field(default=None, description="Direct URL to evidence")


class PassSummary(BaseModel):
    """Summary of a single refinement pass"""
    pass_number: int = Field(description="Which pass (1-3)")
    strategy: str = Field(description="Strategy used in this pass")
    queries_executed: List[str] = Field(description="Actual queries executed")
    results_count: int = Field(description="Number of results found")
    refinements: List[str] = Field(default_factory=list, description="Refinements made")


class GTISpecialistResponse(BaseModel):
    """Response from GTI Specialist Agent"""
    search_strategy: str = Field(description="Overall search strategy")
    queries_planned: List[str] = Field(description="Queries planned across all passes")
    findings: List[Finding] = Field(description="All findings from GTI")
    refinements_attempted: List[str] = Field(description="All refinements tried")
    coverage_assessment: str = Field(description="How comprehensive was the search")


class FlashpointSpecialistResponse(BaseModel):
    """Response from Flashpoint Specialist Agent"""
    search_strategy: str = Field(description="Overall search strategy")
    queries_planned: List[str] = Field(description="Queries planned across all passes")
    findings: List[Finding] = Field(description="All findings from Flashpoint")
    refinements_attempted: List[str] = Field(description="All refinements tried")
    coverage_assessment: str = Field(description="How comprehensive was the search")


class CrowdStrikeSpecialistResponse(BaseModel):
    """Response from CrowdStrike Specialist Agent"""
    search_strategy: str = Field(description="Overall search strategy across all APIs")
    queries_planned: List[str] = Field(description="Queries planned across ASM, SSPM, Falcon, etc.")
    findings: List[Finding] = Field(description="All findings from CrowdStrike")
    refinements_attempted: List[str] = Field(description="All refinements tried")
    coverage_assessment: str = Field(description="How comprehensive was the search")


class OSINTSpecialistResponse(BaseModel):
    """Response from OSINT Specialist Agent"""
    search_strategy: str = Field(description="Overall OSINT search strategy")
    competitors_identified: List[str] = Field(description="Competitors identified via research")
    queries_planned: List[str] = Field(description="Queries planned including Google News, lookups")
    findings: List[Finding] = Field(description="All findings from OSINT")
    refinements_attempted: List[str] = Field(description="All refinements tried")
    coverage_assessment: str = Field(description="How comprehensive was the search")
