"""
Organization profile schema for input validation
"""

from pydantic import BaseModel, Field, validator
from typing import List, Optional


class OrgProfile(BaseModel):
    """
    Organization profile for intelligence gathering

    Validates user input and prevents injection attacks
    """

    organization: str = Field(
        ...,
        min_length=1,
        max_length=200,
        description="Organization name"
    )

    industry: str = Field(
        ...,
        min_length=1,
        max_length=100,
        description="Industry sector"
    )

    domains: List[str] = Field(
        default_factory=list,
        description="Organization domains (e.g., example.com)"
    )

    brands: List[str] = Field(
        default_factory=list,
        description="Brand names"
    )

    competitors: Optional[List[str]] = Field(
        default_factory=list,
        description="Competitor organizations"
    )

    technology_stack: Optional[List[str]] = Field(
        default_factory=list,
        description="Technology stack (e.g., AWS, Kubernetes)"
    )

    @validator('domains')
    def validate_domains(cls, v):
        """Validate domain format"""
        if len(v) > 50:
            raise ValueError("Too many domains (max 50)")

        # Basic domain validation
        for domain in v:
            if not domain or '/' in domain or ' ' in domain:
                raise ValueError(f"Invalid domain format: {domain}")

        return v

    @validator('brands')
    def validate_brands(cls, v):
        """Validate brands"""
        if len(v) > 20:
            raise ValueError("Too many brands (max 20)")
        return v

    @validator('organization', 'industry')
    def sanitize_text(cls, v):
        """Basic sanitization for text fields"""
        # Remove null bytes
        v = v.replace('\x00', '')

        # Check for injection patterns
        dangerous = ['<script', 'javascript:', 'onerror=', '--', ';--']
        for pattern in dangerous:
            if pattern in v.lower():
                raise ValueError(f"Potentially dangerous input detected")

        return v.strip()

    class Config:
        """Pydantic config"""
        json_schema_extra = {
            "example": {
                "organization": "Example Corp",
                "industry": "Technology",
                "domains": ["example.com", "example.io"],
                "brands": ["Example", "ExamplePro"],
                "competitors": ["Competitor A"],
                "technology_stack": ["AWS", "Kubernetes", "Python"]
            }
        }
