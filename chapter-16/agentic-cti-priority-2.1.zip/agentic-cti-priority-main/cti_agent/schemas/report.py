"""
Report schemas for CTI Priority Intelligence
"""

from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any
from datetime import datetime


class ThreatSummary(BaseModel):
    """Individual threat finding"""
    title: str
    description: str
    severity: str  # critical, high, medium, low
    confidence: str  # high, medium, low (Admiralty scale)
    threat_actors: List[str] = Field(default_factory=list)
    ttps: List[str] = Field(default_factory=list)  # MITRE ATT&CK IDs
    indicators: List[Dict[str, str]] = Field(default_factory=list)
    affected_assets: List[str] = Field(default_factory=list)
    sources: List[str] = Field(default_factory=list)


class FollowUpQueries(BaseModel):
    """Follow-up research queries for each tool"""
    google_ti: List[str] = Field(default_factory=list)
    flashpoint: List[str] = Field(default_factory=list)
    crowdstrike: List[str] = Field(default_factory=list)
    osint: List[str] = Field(default_factory=list)


class IntelligenceReport(BaseModel):
    """Complete intelligence report"""

    # Metadata
    report_id: str
    generated_at: datetime = Field(default_factory=datetime.utcnow)
    organization: str
    industry: str

    # Executive summary
    executive_summary: List[str] = Field(
        description="5-10 key findings"
    )

    # Threat findings
    critical_threats: List[ThreatSummary] = Field(default_factory=list)
    high_threats: List[ThreatSummary] = Field(default_factory=list)
    medium_threats: List[ThreatSummary] = Field(default_factory=list)
    informational: List[ThreatSummary] = Field(default_factory=list)

    # Analysis
    attack_surface_summary: str = ""
    threat_actor_attribution: List[str] = Field(default_factory=list)

    # Visual correlation (Mermaid diagram)
    mermaid_diagram: Optional[str] = None

    # Follow-up queries
    follow_up_queries: FollowUpQueries = Field(default_factory=FollowUpQueries)

    # Collection metadata
    sources_queried: List[str] = Field(default_factory=list)
    execution_time_seconds: Optional[float] = None
    region_used: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "report_id": "report_20260210_123456",
                "organization": "Example Corp",
                "industry": "Technology",
                "executive_summary": [
                    "APT29 targeting technology sector with spearphishing",
                    "CVE-2024-1234 affects organization's AWS infrastructure"
                ],
                "critical_threats": [],
                "sources_queried": ["google_ti", "flashpoint", "crowdstrike"]
            }
        }
