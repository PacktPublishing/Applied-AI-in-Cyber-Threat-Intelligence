"""
CTI Priority Intelligence - Main Orchestrator

Simple orchestrator that coordinates intelligence collection and analysis
"""

import os
import asyncio
import time
from typing import Dict, Any
from google import genai
from pathlib import Path

# Import modules
from .config import secrets, regions, settings
from .schemas.org_profile import OrgProfile
from .agents import analyzer, reporter
from .agents import gti_specialist, flashpoint_specialist, crowdstrike_specialist, osint_specialist
from .tools._api_tracker import get_tracker
from .utils.status_logger import log_status


async def run_intelligence_gathering(org_profile_dict: Dict[str, Any]) -> str:
    """
    Main orchestrator - coordinates collection, analysis, and reporting

    Args:
        org_profile_dict: Organization profile dictionary

    Returns:
        Path to generated HTML report

    Raises:
        Exception: If critical errors occur
    """
    start_time = time.time()

    print("="*80)
    print("CTI PRIORITY INTELLIGENCE SYSTEM")
    print("="*80)
    print()

    # Step 0: Validate input
    log_status("validation_started", print_message="[Setup] Validating organization profile...")
    try:
        org_profile = OrgProfile(**org_profile_dict)
        org_dict = org_profile.model_dump()
        log_status("validation_complete", {
            "organization": org_dict['organization'],
            "industry": org_dict['industry'],
            "domain_count": len(org_dict.get('domains', []))
        })
        print(f"[Setup] ✓ Organization: {org_dict['organization']}")
        print(f"[Setup]   Industry: {org_dict['industry']}")
        print(f"[Setup]   Domains: {len(org_dict.get('domains', []))}")
    except Exception as e:
        log_status("validation_failed", {"error": str(e)}, f"[Setup] ✗ Invalid organization profile: {e}")
        raise

    # Step 1: Load secrets from GSM
    print("\n[Setup] Loading secrets from Google Secret Manager...")
    try:
        sm = secrets.load_secrets_from_gsm()
        print("[Setup] ✓ Secrets loaded")
    except Exception as e:
        print(f"[Setup] ✗ Failed to load secrets: {e}")
        print("[Setup]   Ensure: gcloud auth login")
        raise

    # Step 2: Initialize Vertex AI load balancer for proactive quota distribution
    from .tools._vertex_load_balancer import get_load_balancer, get_next_vertex_region

    project_id = os.environ.get("GOOGLE_CLOUD_PROJECT")
    if not project_id:
        raise ValueError(
            "GOOGLE_CLOUD_PROJECT environment variable not set.\n"
            "  Fix this by running:\n"
            "    gcloud config set project YOUR_PROJECT_ID\n"
            "  Or export the variable:\n"
            "    export GOOGLE_CLOUD_PROJECT=your-project-id"
        )

    os.environ['GOOGLE_GENAI_USE_VERTEXAI'] = 'true'

    print("[Setup] Initializing Vertex AI load balancer (8 regions)...")
    load_balancer = get_load_balancer()
    print("[Setup] ✓ Load balancer ready")

    # Helper to create client for each specialist with different region
    def create_specialist_client(model: str = "gemini-2.5-pro") -> genai.Client:
        """Create Gemini client with next available region from load balancer"""
        region = get_next_vertex_region(model)
        client = genai.Client(
            vertexai=True,
            project=project_id,
            location=region
        )
        print(f"  [Client] Created for region: {region}")
        return client, region

    # Step 4: Collect intelligence via specialist agents
    print("\n" + "="*80)
    print("COLLECTION PHASE - Specialist Agents with Multi-Pass Refinement")
    print("="*80)

    # Load settings for quota management and model configuration
    from .config import settings as settings_module
    config = settings_module.get_settings()

    # Check if we should run sequentially for quota management
    inter_agent_delay = config.inter_agent_delay
    parallel_execution = os.environ.get("CTI_PARALLEL_EXECUTION", "true").lower() == "true"

    # Get model configurations from config.yaml
    collector_model = config.model_collectors.get("name", "gemini-2.5-flash")
    correlator_model = config.model_correlator.get("name", "gemini-2.5-pro")
    report_model = config.model_report_generator.get("name", "gemini-2.5-flash")

    log_status("collection_phase_started", {
        "mode": "parallel" if parallel_execution else "sequential"
    })

    if parallel_execution:
        print("[Collection] Mode: PARALLEL (proactive load balancing across regions)")

        # Create separate clients for each specialist (different regions)
        # GTI, Flashpoint, CrowdStrike use correlator model (default: pro)
        gti_client, gti_region = create_specialist_client(correlator_model)
        fp_client, fp_region = create_specialist_client(correlator_model)
        cs_client, cs_region = create_specialist_client(correlator_model)
        # OSINT uses collector model (default: flash)
        osint_client, osint_region = create_specialist_client(collector_model)

        print(f"[Collection] GTI: {gti_region}, FP: {fp_region}, CS: {cs_region}, OSINT: {osint_region}")

        gti_data, fp_data, cs_data, osint_data = await asyncio.gather(
            gti_specialist.collect_intelligence(gti_client, org_dict),
            flashpoint_specialist.collect_intelligence(fp_client, org_dict),
            crowdstrike_specialist.collect_intelligence(cs_client, org_dict),
            osint_specialist.collect_intelligence(osint_client, org_dict),
            return_exceptions=True
        )
    else:
        print(f"[Collection] Mode: SEQUENTIAL (quota-safe, {inter_agent_delay}s delays, load balanced)")

        # Run specialists sequentially with delays, each with different region
        gti_client, gti_region = create_specialist_client(correlator_model)
        print(f"[GTI] Using region: {gti_region}, model: {correlator_model}")
        gti_data = await gti_specialist.collect_intelligence(gti_client, org_dict)
        await asyncio.sleep(inter_agent_delay)

        fp_client, fp_region = create_specialist_client(correlator_model)
        print(f"[Flashpoint] Using region: {fp_region}, model: {correlator_model}")
        fp_data = await flashpoint_specialist.collect_intelligence(fp_client, org_dict)
        await asyncio.sleep(inter_agent_delay)

        cs_client, cs_region = create_specialist_client(correlator_model)
        print(f"[CrowdStrike] Using region: {cs_region}, model: {correlator_model}")
        cs_data = await crowdstrike_specialist.collect_intelligence(cs_client, org_dict)
        await asyncio.sleep(inter_agent_delay)

        osint_client, osint_region = create_specialist_client(collector_model)
        print(f"[OSINT] Using region: {osint_region}, model: {collector_model}")
        osint_data = await osint_specialist.collect_intelligence(osint_client, org_dict)

    # Validate collection results - check for actual intelligence, not just non-Exception
    def has_findings(source: str, data: Any) -> bool:
        """Check if source returned actual intelligence findings"""
        if isinstance(data, Exception):
            return False
        if not isinstance(data, dict):
            return False

        # Check source-specific fields for actual data
        if source == "google_ti":
            findings = data.get("findings", {})
            if isinstance(findings, dict):
                return any([
                    len(findings.get("domains", [])) > 0,
                    len(findings.get("threat_actors", [])) > 0,
                    len(findings.get("intelligence_reports", [])) > 0,
                    len(findings.get("collections", [])) > 0
                ])
        elif source == "flashpoint":
            findings = data.get("findings", {})
            if isinstance(findings, dict):
                return any([
                    len(findings.get("credentials", [])) > 0,
                    len(findings.get("forum_mentions", [])) > 0,
                    len(findings.get("finished_intelligence", [])) > 0,
                    len(findings.get("vulnerabilities", [])) > 0
                ])
        elif source == "crowdstrike":
            findings = data.get("findings", {})
            if isinstance(findings, dict):
                return any([
                    len(findings.get("indicators", [])) > 0,
                    len(findings.get("threat_actors", [])) > 0,
                    len(findings.get("asm_assets", [])) > 0,
                    len(findings.get("vulnerabilities", [])) > 0,
                    len(findings.get("sspm_misconfigs", [])) > 0,
                    len(findings.get("identity_risks", [])) > 0,
                    len(findings.get("falcon_detections", [])) > 0,
                    len(findings.get("incidents", [])) > 0,
                    len(findings.get("custom_iocs", [])) > 0,
                    len(findings.get("threat_graph", [])) > 0,
                    len(findings.get("malquery_samples", [])) > 0
                ])
        elif source == "osint":
            findings = data.get("findings", {})
            if isinstance(findings, dict):
                return any([
                    len(findings.get("news", [])) > 0,
                    len(findings.get("advisories", [])) > 0
                ])
        return False

    # Handle collection exceptions and validate actual findings
    sources_succeeded = []
    sources_with_data = []

    if not isinstance(gti_data, Exception):
        sources_succeeded.append("google_ti")
        if has_findings("google_ti", gti_data):
            sources_with_data.append("google_ti")
        else:
            print(f"  [GTI] ⚠️  Collection succeeded but returned no findings")
    else:
        print(f"  [GTI] ✗ Collection failed: {gti_data}")
        gti_data = {"error": str(gti_data)}

    if not isinstance(fp_data, Exception):
        sources_succeeded.append("flashpoint")
        if has_findings("flashpoint", fp_data):
            sources_with_data.append("flashpoint")
        else:
            print(f"  [Flashpoint] ⚠️  Collection succeeded but returned no findings")
    else:
        print(f"  [Flashpoint] ✗ Collection failed: {fp_data}")
        fp_data = {"error": str(fp_data)}

    if not isinstance(cs_data, Exception):
        sources_succeeded.append("crowdstrike")
        if has_findings("crowdstrike", cs_data):
            sources_with_data.append("crowdstrike")
        else:
            print(f"  [CrowdStrike] ⚠️  Collection succeeded but returned no findings")
    else:
        print(f"  [CrowdStrike] ✗ Collection failed: {cs_data}")
        cs_data = {"error": str(cs_data)}

    if not isinstance(osint_data, Exception):
        sources_succeeded.append("osint")
        if has_findings("osint", osint_data):
            sources_with_data.append("osint")
        else:
            print(f"  [OSINT] ⚠️  Collection succeeded but returned no findings")
    else:
        print(f"  [OSINT] ✗ Collection failed: {osint_data}")
        osint_data = {"error": str(osint_data)}

    log_status("collection_phase_complete", {
        "sources_succeeded": sources_succeeded,
        "sources_with_data": sources_with_data,
        "success_count": len(sources_succeeded),
        "data_count": len(sources_with_data)
    })
    print(f"\n✓ Collection complete: {len(sources_succeeded)}/4 sources succeeded")
    print(f"  Intelligence gathered from: {len(sources_with_data)}/4 sources ({', '.join(sources_with_data) if sources_with_data else 'none'})")

    # Check if we have enough data (OSINT is always available)
    if len(sources_succeeded) < 1:
        print("✗ Insufficient data collected (need at least 1 source)")
        print("  Check network connectivity")
        raise Exception("Insufficient intelligence sources")

    # Warn if sources succeeded but returned no findings
    if len(sources_with_data) == 0:
        print("⚠️  WARNING: All sources returned empty results")
        print("  This may indicate:")
        print("  - No threats found for this organization (good news)")
        print("  - API access limitations (check licenses)")
        print("  - Network/firewall blocking queries")
        print("  Report will include fallback geopolitical intelligence\n")

    if len(sources_succeeded) == 1 and "osint" in sources_succeeded:
        print("⚠️  Using OSINT only - consider adding API keys for better coverage")

    # Step 5: Analyze (correlation + enrichment)
    log_status("analysis_phase_started")
    print("\n" + "="*80)
    print("ANALYSIS PHASE")
    print("="*80)

    # Create client for analyzer with load balancing
    analyzer_client, analyzer_region = create_specialist_client(correlator_model)
    print(f"[Analyzer] Using region: {analyzer_region}, model: {correlator_model}")

    analyzed_data = await analyzer.analyze(
        analyzer_client,
        raw_data={
            "google_ti": gti_data,
            "flashpoint": fp_data,
            "crowdstrike": cs_data,
            "osint": osint_data
        },
        org_profile=org_dict
    )

    log_status("analysis_phase_complete", {
        "threats_identified": len(analyzed_data.get("threats", [])),
        "threat_actors": analyzed_data.get("threat_actors_identified", [])
    })

    # Step 6: Generate report
    log_status("reporting_phase_started")
    print("\n" + "="*80)
    print("REPORTING PHASE")
    print("="*80)

    # Create client for reporter with load balancing
    reporter_client, reporter_region = create_specialist_client(report_model)
    print(f"[Reporter] Using region: {reporter_region}, model: {report_model}")

    execution_time = time.time() - start_time

    # Get detailed API tracker summary
    api_tracker = get_tracker()
    api_summary = api_tracker.get_summary()

    # Extract contextual intelligence from OSINT for complementary reporting
    contextual_intelligence = []
    if not isinstance(osint_data, Exception) and isinstance(osint_data, dict):
        findings = osint_data.get("findings", {})
        if isinstance(findings, dict):
            # Collect news and advisories for contextual intelligence section
            contextual_intelligence.extend(findings.get("news", []))
            contextual_intelligence.extend(findings.get("advisories", []))

    metadata = {
        "sources_queried": sources_succeeded,
        "execution_time": f"{execution_time:.1f}s",
        "regions_used": "Load balanced across 8 regions",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
        "api_tracker": api_summary,  # Detailed API query tracking
        "contextual_intelligence": contextual_intelligence,  # News/advisories for context section
        "threats_found": analyzed_data.get("threats", [])  # For relevancy scoring
    }

    report_path = await reporter.generate_html_report(
        reporter_client,
        analyzed_data=analyzed_data,
        org_profile=org_dict,
        output_dir="output",
        metadata=metadata
    )

    # Step 7: Summary
    log_status("intelligence_gathering_complete", {
        "report_path": report_path,
        "execution_time": f"{execution_time:.1f}s",
        "sources_succeeded": sources_succeeded,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
    })
    print("\n" + "="*80)
    print("COMPLETE")
    print("="*80)
    print(f"\n✓ Intelligence report generated")
    print(f"  Report: {report_path}")
    print(f"  Execution time: {execution_time:.1f}s")
    print(f"  Sources: {', '.join(sources_succeeded)}")

    # Show load balancer stats
    from .tools._vertex_load_balancer import print_vertex_stats
    from .tools._rate_limiter import print_quota_summary

    print_vertex_stats()
    print_quota_summary()

    # Cleanup old reports and logs (only if report is successful)
    from .utils.cleanup import cleanup_after_report
    try:
        report_size = Path(report_path).stat().st_size
        if report_size > 1024:  # Only cleanup if report is > 1KB (successful)
            cleanup_after_report(output_dir="output", verbose=True)
    except Exception as e:
        # Don't fail if cleanup fails
        print(f"[Cleanup] Skipped: {e}")

    return report_path
