#!/usr/bin/env python3
"""
CTI Priority Intelligence System - CLI Entry Point

Usage:
    python run_agent.py --org "Example Corp" --industry "Technology" --domains "example.com,example.io"
    python run_agent.py --interactive
"""

import asyncio
import argparse
import sys
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

from cti_agent.orchestrator import run_intelligence_gathering


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description='CTI Priority Intelligence System - Simplified MVP',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage
  python run_agent.py --org "Example Corp" --industry "Technology" --domains "example.com"

  # Full profile
  python run_agent.py \\
    --org "Example Corp" \\
    --industry "Technology" \\
    --domains "example.com,example.io" \\
    --brands "Example,ExamplePro" \\
    --competitors "Competitor A" \\
    --tech "AWS,Kubernetes"

  # Interactive mode
  python run_agent.py --interactive

Prerequisites:
  1. Run: gcloud auth login
  2. Secrets setup: ./scripts/setup_secrets_gsm.sh
        """
    )

    parser.add_argument(
        '--org',
        '--organization',
        type=str,
        required='--interactive' not in sys.argv and '-i' not in sys.argv and '--from-config' not in sys.argv and '-c' not in sys.argv,
        help='Organization name (REQUIRED for CLI mode)'
    )

    parser.add_argument(
        '--industry',
        type=str,
        default='Unknown',
        help='Industry sector (e.g., "Technology", "Healthcare"). Defaults to "Unknown" if not specified.'
    )

    parser.add_argument(
        '--domains',
        type=str,
        required='--interactive' not in sys.argv and '-i' not in sys.argv and '--from-config' not in sys.argv and '-c' not in sys.argv,
        help='Comma-separated list of domains (REQUIRED for CLI mode - e.g., "example.com,example.io")'
    )

    parser.add_argument(
        '--brands',
        type=str,
        help='Comma-separated list of brand names'
    )

    parser.add_argument(
        '--competitors',
        type=str,
        help='Comma-separated list of competitors'
    )

    parser.add_argument(
        '--tech',
        '--technology-stack',
        type=str,
        help='Comma-separated list of technologies (e.g., "AWS,Kubernetes,Python")'
    )

    parser.add_argument(
        '--interactive',
        '-i',
        action='store_true',
        help='Run in interactive mode with prompts'
    )

    parser.add_argument(
        '--from-config',
        '-c',
        action='store_true',
        help='Load organization profile from config.yaml (non-interactive)'
    )

    parser.add_argument(
        '--status-log',
        type=str,
        help='Path to status log file for non-interactive mode (JSON-lines format)'
    )

    return parser.parse_args()


async def interactive_mode():
    """Interactive mode - prompt for all inputs"""
    print("="*80)
    print("CTI Priority Intelligence System - Interactive Mode")
    print("="*80)
    print()

    org = input("Organization name: ").strip()
    industry = input("Industry: ").strip()
    domains = input("Domains (comma-separated): ").strip()
    brands = input("Brand names (comma-separated, optional): ").strip()
    competitors = input("Competitors (comma-separated, optional): ").strip()
    tech = input("Technology stack (comma-separated, optional): ").strip()

    # Build profile
    profile = {
        "organization": org,
        "industry": industry,
        "domains": [d.strip() for d in domains.split(',') if d.strip()],
        "brands": [b.strip() for b in brands.split(',') if b.strip()],
        "competitors": [c.strip() for c in competitors.split(',') if c.strip()],
        "technology_stack": [t.strip() for t in tech.split(',') if t.strip()]
    }

    print()
    print("Profile:")
    print(f"  Organization: {profile['organization']}")
    print(f"  Industry: {profile['industry']}")
    print(f"  Domains: {len(profile['domains'])}")
    print()

    confirm = input("Proceed with intelligence gathering? (y/n): ").strip().lower()
    if confirm != 'y':
        print("Cancelled.")
        return

    # Run
    await run_intelligence_gathering(profile)


async def main():
    """Main entry point"""
    args = parse_args()

    # Set status log if provided
    if args.status_log:
        import os
        os.environ['CTI_STATUS_LOG'] = args.status_log

    # Interactive mode
    if args.interactive:
        await interactive_mode()
        return

    # Config file mode - load from config.yaml
    if args.from_config:
        from cti_agent.config.settings import get_settings
        settings = get_settings()
        org_config = settings.default_organization

        if not org_config:
            print("✗ No organization profile found in config.yaml")
            print("  Add organization profile to config.yaml or use --interactive mode")
            sys.exit(1)

        # Build profile from config
        profile = {
            "organization": org_config.get("name", "Unknown"),
            "industry": org_config.get("industry", "Unknown"),
            "domains": org_config.get("domains", []),
        }

        # Optional fields
        if org_config.get("brands"):
            profile["brands"] = org_config.get("brands", [])
        if org_config.get("competitors"):
            profile["competitors"] = org_config.get("competitors", [])
        if org_config.get("technology_stack"):
            profile["technology_stack"] = org_config.get("technology_stack", [])

        print("="*80)
        print("Loading organization profile from config.yaml")
        print("="*80)
        print(f"  Organization: {profile['organization']}")
        print(f"  Industry: {profile['industry']}")
        print(f"  Domains: {len(profile.get('domains', []))}")
        print()

        # Run
        try:
            await run_intelligence_gathering(profile)
            sys.exit(0)
        except Exception as e:
            print(f"\n✗ Error: {e}")
            sys.exit(1)

    # Build profile (org and domains required, industry defaults to "Unknown")
    profile = {
        "organization": args.org,
        "industry": args.industry if args.industry else "Unknown",
        "domains": [d.strip() for d in args.domains.split(',') if d.strip()],
    }

    # Optional fields
    if args.brands:
        profile["brands"] = [b.strip() for b in args.brands.split(',') if b.strip()]

    if args.competitors:
        profile["competitors"] = [c.strip() for c in args.competitors.split(',') if c.strip()]

    if args.tech:
        profile["technology_stack"] = [t.strip() for t in args.tech.split(',') if t.strip()]

    # Run
    try:
        await run_intelligence_gathering(profile)
        sys.exit(0)
    except Exception as e:
        print(f"\n✗ Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    asyncio.run(main())
