#!/usr/bin/env python3
"""
Component Test Script - Verify all components work before full run

Usage:
    python test_components.py
"""

import asyncio
import sys
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))


async def test_secrets():
    """Test GSM secret loading"""
    print("\n" + "="*80)
    print("TEST 1: Secrets Loading")
    print("="*80)

    try:
        from cti_agent.config import secrets
        sm = secrets.load_secrets_from_gsm()

        required_keys = ['GTI_API_KEY', 'FP_API_KEY', 'CS_CLIENT_ID', 'CS_CLIENT_SECRET']
        for key in required_keys:
            value = sm.get(key)
            if value:
                print(f"  ✓ {key}: {value[:10]}...")
            else:
                print(f"  ✗ {key}: NOT FOUND")
                return False

        print("\n✓ Secrets test PASSED")
        return True

    except Exception as e:
        print(f"\n✗ Secrets test FAILED: {e}")
        return False


async def test_config():
    """Test config.yaml loading"""
    print("\n" + "="*80)
    print("TEST 2: Configuration Loading")
    print("="*80)

    try:
        from cti_agent.config import settings
        s = settings.get_settings()

        print(f"  ✓ OSINT news feeds: {len(s.osint_news_feeds)}")
        print(f"  ✓ Intelligence sources: {len(s.intelligence_sources)}")

        # Check priorities
        gti_priority = s.intelligence_sources.get('google_ti', {}).get('priority')
        fp_priority = s.intelligence_sources.get('flashpoint', {}).get('priority')
        cs_priority = s.intelligence_sources.get('crowdstrike', {}).get('priority')

        print(f"\n  Priority ranking:")
        print(f"    GTI: {gti_priority} (should be 1)")
        print(f"    Flashpoint: {fp_priority} (should be 2)")
        print(f"    CrowdStrike: {cs_priority} (should be 3)")

        print("\n✓ Config test PASSED")
        return True

    except Exception as e:
        print(f"\n✗ Config test FAILED: {e}")
        return False


async def test_regions():
    """Test region selection"""
    print("\n" + "="*80)
    print("TEST 3: Region Selection")
    print("="*80)

    try:
        from cti_agent.config import regions

        region = regions.select_region()
        print(f"  ✓ Selected region: {region}")

        expected_regions = [
            "global", "us-central1", "us-east5", "us-south1",
            "us-west4", "us-east1", "us-east4", "us-west1"
        ]

        if region in expected_regions:
            print(f"  ✓ Region is valid (one of {len(expected_regions)})")
        else:
            print(f"  ✗ Region not in expected list: {expected_regions}")
            return False

        print("\n✓ Region test PASSED")
        return True

    except Exception as e:
        print(f"\n✗ Region test FAILED: {e}")
        return False


async def test_org_profile():
    """Test organization profile schema"""
    print("\n" + "="*80)
    print("TEST 4: Organization Profile Schema")
    print("="*80)

    try:
        from cti_agent.schemas.org_profile import OrgProfile

        # Test valid profile
        profile = OrgProfile(
            organization="Test Corp",
            industry="Technology",
            domains=["example.com"],
            brands=["TestBrand"],
            competitors=["CompetitorX"],
            technology_stack=["AWS", "Python"]
        )

        print(f"  ✓ Valid profile created")
        print(f"    Organization: {profile.organization}")
        print(f"    Industry: {profile.industry}")
        print(f"    Domains: {len(profile.domains)}")

        # Test validation
        try:
            invalid = OrgProfile(organization="", industry="Tech", domains=[])
            print(f"  ✗ Validation failed - empty org name should be rejected")
            return False
        except:
            print(f"  ✓ Validation works (rejected empty org name)")

        print("\n✓ Schema test PASSED")
        return True

    except Exception as e:
        print(f"\n✗ Schema test FAILED: {e}")
        return False


async def test_osint_collection():
    """Test OSINT collection (quick check)"""
    print("\n" + "="*80)
    print("TEST 5: OSINT Collection")
    print("="*80)

    try:
        from cti_agent.tools import osint

        print("  Collecting news feeds (this may take 10-15 seconds)...")
        news = await osint.collect_news_feeds()

        print(f"  ✓ Collected {len(news)} news items")

        if news:
            print(f"    Sample: {news[0].get('title', 'N/A')[:60]}...")

        print("\n✓ OSINT test PASSED")
        return True

    except Exception as e:
        print(f"\n✗ OSINT test FAILED: {e}")
        return False


async def test_google_ti():
    """Test Google TI client initialization"""
    print("\n" + "="*80)
    print("TEST 6: Google Threat Intelligence Client")
    print("="*80)

    try:
        from cti_agent.tools import google_ti

        print("  Testing GTI search for 'google.com'...")
        result = await google_ti.search_domain("google.com")

        if result.get('error'):
            print(f"  ⚠ GTI returned error (may be API key issue): {result['error']}")
            print(f"  This is non-critical if API key is not yet configured")
        else:
            print(f"  ✓ GTI search successful")
            print(f"    Reputation: {result.get('reputation', 'N/A')}")

        print("\n✓ GTI client test PASSED")
        return True

    except Exception as e:
        print(f"\n✗ GTI client test FAILED: {e}")
        print(f"  Note: This may fail if API key is not configured yet")
        return False


async def main():
    """Run all component tests"""
    print("="*80)
    print("CTI PRIORITY INTELLIGENCE - COMPONENT TEST SUITE")
    print("="*80)
    print("\nThis will verify all components are working before full run")
    print("Tests will run in sequence...")

    results = []

    # Run tests
    results.append(("Secrets", await test_secrets()))
    results.append(("Config", await test_config()))
    results.append(("Regions", await test_regions()))
    results.append(("Schema", await test_org_profile()))
    results.append(("OSINT", await test_osint_collection()))
    results.append(("Google TI", await test_google_ti()))

    # Summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for name, result in results:
        status = "✓ PASSED" if result else "✗ FAILED"
        print(f"  {name:20s} {status}")

    print(f"\nTotal: {passed}/{total} tests passed")

    if passed == total:
        print("\n✅ All tests passed! Ready to run full intelligence gathering.")
        print("\nNext step:")
        print("  python run_agent.py --interactive")
        sys.exit(0)
    else:
        print("\n⚠ Some tests failed. Review errors above before proceeding.")
        print("\nCommon fixes:")
        print("  1. Run: ./scripts/setup_secrets_gsm.sh")
        print("  2. Verify: gcloud auth login")
        print("  3. Check: config.yaml exists and is valid")
        sys.exit(1)


if __name__ == '__main__':
    asyncio.run(main())
