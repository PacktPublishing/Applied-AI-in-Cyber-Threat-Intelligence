#!/usr/bin/env python3
"""Test if ADK can find root_agent"""
import sys
from pathlib import Path

# Add project root to path (like ADK does)
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

print("Testing ADK agent discovery...")
print(f"Project root: {project_root}")
print(f"Python path: {sys.path[0]}")
print()

# Test 1: Direct module import (cti_agent.agent.root_agent)
try:
    from cti_agent.agent import root_agent as ra1
    print("✓ Test 1 PASSED: from cti_agent.agent import root_agent")
    print(f"  Type: {type(ra1)}")
    print(f"  Name: {ra1.__name__}")
except Exception as e:
    print(f"✗ Test 1 FAILED: {e}")

print()

# Test 2: Package-level import (cti_agent.root_agent)
try:
    from cti_agent import root_agent as ra2
    print("✓ Test 2 PASSED: from cti_agent import root_agent")
    print(f"  Type: {type(ra2)}")
    print(f"  Name: {ra2.__name__}")
except Exception as e:
    print(f"✗ Test 2 FAILED: {e}")

print()

# Test 3: Check if it's a coroutine function
try:
    import inspect
    from cti_agent import root_agent
    if inspect.iscoroutinefunction(root_agent):
        print("✓ Test 3 PASSED: root_agent is an async function")
    else:
        print("✗ Test 3 FAILED: root_agent is not an async function")
        print(f"  Type: {type(root_agent)}")
except Exception as e:
    print(f"✗ Test 3 FAILED: {e}")

print()

# Test 4: Check module attributes
try:
    import cti_agent
    print("Module attributes:")
    print(f"  __all__: {getattr(cti_agent, '__all__', 'Not defined')}")
    print(f"  __file__: {cti_agent.__file__}")
    print(f"  Has root_agent: {hasattr(cti_agent, 'root_agent')}")
except Exception as e:
    print(f"✗ Test 4 FAILED: {e}")

print()
print("="*60)
print("If all tests passed, ADK should be able to find root_agent")
print("="*60)
