#!/bin/bash
# CTI Priority Intelligence - Run Tests
# Runs end-to-end tests against "Google" organization

set -e

cd "$(dirname "$0")"

# Check if setup was completed
if [ ! -d "venv" ]; then
    echo "✗ Virtual environment not found"
    echo ""
    echo "Run setup first: ./setup.sh"
    exit 1
fi

# Run tests
./tests/RUN_TEST.sh
