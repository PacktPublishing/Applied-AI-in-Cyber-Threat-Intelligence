"""
Test quota management, rate limiting, and retry logic

Run with: pytest tests/test_quota_management.py -v -s
"""

import pytest
import asyncio
import time
from cti_agent.tools._rate_limiter import RateLimiter, get_rate_limiter, rate_limit_gti, rate_limit_flashpoint
from cti_agent.tools._retry import retry_with_backoff, RetryConfig, retry_async
from cti_agent.tools._time_utils import TimeRange, TIME_RANGES, classify_by_recency, add_recency_score


class TestRateLimiter:
    """Test rate limiting functionality"""

    def test_rate_limiter_basic(self):
        """Test basic rate limiting"""
        limiter = RateLimiter()

        # Should allow first call
        assert limiter.can_call("test_source") is True

        # Record calls up to limit
        for _ in range(20):  # Default limit is 20
            limiter.call_history["test_source"].append(time.time())

        # Should now be at limit
        assert limiter.can_call("test_source") is False

    def test_wait_time_calculation(self):
        """Test wait time calculation"""
        limiter = RateLimiter()

        # No wait needed initially
        assert limiter.get_wait_time("test_source") == 0.0

        # Fill up quota
        for _ in range(20):
            limiter.call_history["test_source"].append(time.time())

        # Should need to wait
        wait_time = limiter.get_wait_time("test_source")
        assert wait_time > 0.0
        assert wait_time <= 60.0

    def test_history_cleanup(self):
        """Test that old calls are removed from history"""
        limiter = RateLimiter()

        # Add old calls (65 seconds ago)
        old_time = time.time() - 65
        for _ in range(10):
            limiter.call_history["test_source"].append(old_time)

        # Clean history
        limiter._clean_history("test_source")

        # Old calls should be removed
        assert len(limiter.call_history["test_source"]) == 0

    @pytest.mark.asyncio
    async def test_rate_limit_gti(self):
        """Test GTI rate limiting"""
        start = time.time()

        # First call should be instant
        await rate_limit_gti()

        # Second call should have minimum delay
        await rate_limit_gti()

        elapsed = time.time() - start

        # Should have at least the minimum delay (200ms)
        assert elapsed >= 0.2

    def test_quota_stats(self):
        """Test quota usage statistics"""
        limiter = RateLimiter()

        # Add some calls
        for _ in range(5):
            limiter.call_history["gti"].append(time.time())

        stats = limiter.get_stats("gti")

        assert stats["source"] == "gti"
        assert stats["limit_per_minute"] == 300
        assert stats["calls_last_minute"] == 5
        assert stats["quota_used_pct"] == pytest.approx((5 / 300) * 100, rel=0.01)
        assert stats["can_call"] is True


class TestRetryLogic:
    """Test retry with exponential backoff"""

    def test_retry_config_delay_calculation(self):
        """Test exponential backoff delay calculation"""
        config = RetryConfig(base_delay=2.0, exponential_base=2.0, jitter=False)

        # Test delays without jitter
        assert config.calculate_delay(0) == 2.0  # 2 * 2^0 = 2
        assert config.calculate_delay(1) == 4.0  # 2 * 2^1 = 4
        assert config.calculate_delay(2) == 8.0  # 2 * 2^2 = 8

    def test_retry_config_max_delay(self):
        """Test that delay caps at max_delay"""
        config = RetryConfig(base_delay=2.0, max_delay=10.0, exponential_base=2.0, jitter=False)

        # Should cap at 10s
        assert config.calculate_delay(10) == 10.0

    def test_retry_config_jitter(self):
        """Test that jitter adds randomness"""
        config = RetryConfig(base_delay=10.0, jitter=True, jitter_range=0.5)

        delays = [config.calculate_delay(0) for _ in range(10)]

        # Delays should vary (not all exactly 10.0)
        assert len(set(delays)) > 1

        # All delays should be within jitter range (5.0 - 15.0)
        assert all(5.0 <= d <= 15.0 for d in delays)

    def test_retryable_error_detection(self):
        """Test detection of retryable errors"""
        config = RetryConfig()

        # Rate limit errors should always be retryable
        rate_limit_error = Exception("429 Too Many Requests")
        assert config.is_retryable(rate_limit_error) is True

        quota_error = Exception("Quota exceeded")
        assert config.is_retryable(quota_error) is True

    @pytest.mark.asyncio
    async def test_retry_with_backoff_success(self):
        """Test successful execution with retry"""
        call_count = 0

        async def successful_function():
            nonlocal call_count
            call_count += 1
            return "success"

        result = await retry_with_backoff(successful_function)

        assert result == "success"
        assert call_count == 1  # Should succeed on first try

    @pytest.mark.asyncio
    async def test_retry_with_backoff_eventual_success(self):
        """Test retry until success"""
        call_count = 0

        async def eventually_successful():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ConnectionError("Temporary failure")
            return "success"

        config = RetryConfig(max_retries=5, base_delay=0.1, jitter=False)
        result = await retry_with_backoff(eventually_successful, config=config)

        assert result == "success"
        assert call_count == 3  # Failed twice, succeeded on third

    @pytest.mark.asyncio
    async def test_retry_exhausted(self):
        """Test that retry gives up after max attempts"""
        call_count = 0

        async def always_fails():
            nonlocal call_count
            call_count += 1
            raise ConnectionError("Always fails")

        config = RetryConfig(max_retries=2, base_delay=0.1, jitter=False)

        with pytest.raises(ConnectionError):
            await retry_with_backoff(always_fails, config=config)

        assert call_count == 3  # Initial + 2 retries

    @pytest.mark.asyncio
    async def test_retry_decorator(self):
        """Test retry decorator"""
        call_count = 0

        @retry_async("gti")
        async def decorated_function():
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ConnectionError("Temporary failure")
            return "success"

        # Reset call count
        call_count = 0

        result = await decorated_function()

        assert result == "success"
        assert call_count == 2  # Failed once, succeeded on retry


class TestTimeUtils:
    """Test time-based filtering utilities"""

    def test_time_range_creation(self):
        """Test TimeRange creation"""
        range_24h = TimeRange(hours=24)
        assert range_24h.label == "24h"

        range_7d = TimeRange(days=7)
        assert range_7d.label == "7d"

    def test_time_range_contains(self):
        """Test timestamp checking"""
        import datetime

        range_24h = TimeRange(hours=24)

        # Timestamp from 1 hour ago (should be in range)
        one_hour_ago = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(hours=1)).isoformat()
        assert range_24h.contains(one_hour_ago) is True

        # Timestamp from 48 hours ago (should not be in range)
        two_days_ago = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(hours=48)).isoformat()
        assert range_24h.contains(two_days_ago) is False

    def test_classify_by_recency(self):
        """Test recency classification"""
        import datetime
        from datetime import timezone

        now = datetime.datetime.now(timezone.utc)

        findings = [
            {"name": "f1", "date": (now - datetime.timedelta(hours=12)).isoformat()},  # 12h ago - critical
            {"name": "f2", "date": (now - datetime.timedelta(days=3)).isoformat()},    # 3d ago - recent
            {"name": "f3", "date": (now - datetime.timedelta(days=15)).isoformat()},   # 15d ago - context
            {"name": "f4", "date": (now - datetime.timedelta(days=60)).isoformat()},   # 60d ago - older
        ]

        classified = classify_by_recency(findings, "date")

        assert len(classified["critical"]) == 1
        assert len(classified["recent"]) == 1
        assert len(classified["context"]) == 1
        assert len(classified["older"]) == 1

    def test_add_recency_score(self):
        """Test recency score addition"""
        import datetime
        from datetime import timezone

        now = datetime.datetime.now(timezone.utc)

        findings = [
            {"name": "f1", "date": (now - datetime.timedelta(hours=12)).isoformat()},  # Critical
            {"name": "f2", "date": (now - datetime.timedelta(days=3)).isoformat()},    # Recent
        ]

        findings_with_scores = add_recency_score(findings, "date")

        assert findings_with_scores[0]["recency_score"] == 1.0  # Critical
        assert findings_with_scores[0]["recency_label"] == "critical (24h)"

        assert findings_with_scores[1]["recency_score"] == 0.7  # Recent
        assert findings_with_scores[1]["recency_label"] == "recent (7d)"

    def test_format_trend_summary(self):
        """Test trend summary generation"""
        import datetime
        from datetime import timezone

        now = datetime.datetime.now(timezone.utc)

        findings = [
            {"date": (now - datetime.timedelta(hours=12)).isoformat()},  # Critical
            {"date": (now - datetime.timedelta(hours=18)).isoformat()},  # Critical
            {"date": (now - datetime.timedelta(days=3)).isoformat()},    # Recent
        ]

        summary = format_trend_summary(findings, "date")

        assert "2 in last 24 hours" in summary
        assert "1 in last 7 days" in summary

    def test_api_specific_time_filters(self):
        """Test API-specific time filter formatting"""
        range_7d = TimeRange(days=7)

        # Test GTI format (UNIX epoch)
        gti_filter = range_7d.format_api_filter("gti")
        assert "first_submission_date" in gti_filter
        assert isinstance(gti_filter["first_submission_date"], str)
        assert "+" in gti_filter["first_submission_date"]

        # Test Flashpoint format (ISO 8601)
        fp_filter = range_7d.format_api_filter("flashpoint")
        assert "since" in fp_filter
        assert "until" in fp_filter
        assert isinstance(fp_filter["since"], str)

        # Test CrowdStrike format (filter syntax)
        cs_filter = range_7d.format_api_filter("crowdstrike")
        assert "filter" in cs_filter
        assert "published_date:>=" in cs_filter["filter"]


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
