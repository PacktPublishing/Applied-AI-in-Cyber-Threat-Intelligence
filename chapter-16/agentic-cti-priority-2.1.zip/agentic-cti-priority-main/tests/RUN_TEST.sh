#!/bin/bash
# End-to-End Test Script
# Run this in a separate terminal

set -e  # Exit on error

echo "================================================================================"
echo "CTI PRIORITY INTELLIGENCE - END-TO-END TEST"
echo "================================================================================"
echo ""

# Navigate to project directory
cd "$(dirname "$0")"
echo "✓ Project directory: $(pwd)"
echo ""

# Check if venv exists
if [ ! -d "venv" ]; then
    echo "✗ Virtual environment not found!"
    echo "  Creating venv..."
    python3 -m venv venv
    echo "  Installing requirements..."
    source venv/bin/activate
    pip install -q -r requirements.txt
    echo "✓ Dependencies installed"
else
    echo "✓ Virtual environment found"
fi

# Activate venv
echo "[1/5] Activating virtual environment..."
source venv/bin/activate
echo "✓ Virtual environment activated"
echo ""

# Check if dependencies are installed
echo "[2/5] Checking dependencies..."
if ! python -c "import google.adk" &>/dev/null; then
    echo "⚠️  Dependencies not found or incomplete"
    echo "  Installing requirements.txt..."
    pip install -q -r requirements.txt
    echo "✓ Dependencies installed"
else
    echo "✓ Dependencies already installed"
fi
echo ""

# Check gcloud auth
echo "[3/5] Checking authentication..."
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | grep -q "@"; then
    echo "⚠️  Not authenticated with gcloud"
    echo "  Running: gcloud auth login"
    gcloud auth login
fi
ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | head -1)
echo "✓ Authenticated as: $ACCOUNT"

# Get GCP project (from env var or gcloud config)
if [ -z "$GOOGLE_CLOUD_PROJECT" ]; then
    PROJECT_ID=$(gcloud config get-value project 2>/dev/null)
    if [ -z "$PROJECT_ID" ] || [ "$PROJECT_ID" = "(unset)" ]; then
        echo ""
        echo "✗ No GCP project configured"
        echo ""
        echo "Please set your project ID:"
        echo "  gcloud config set project YOUR_PROJECT_ID"
        echo ""
        echo "Or set the environment variable:"
        echo "  export GOOGLE_CLOUD_PROJECT=YOUR_PROJECT_ID"
        echo ""
        exit 1
    fi
    export GOOGLE_CLOUD_PROJECT="$PROJECT_ID"
fi
echo "✓ GCP Project: $GOOGLE_CLOUD_PROJECT"
echo ""

# Run test
echo "[4/5] Running end-to-end test..."
echo "  Target: Google (Technology sector)"
echo "  Domain: google.com"
echo "  Mode: Non-interactive CLI"
echo "  Project: $GOOGLE_CLOUD_PROJECT"
echo ""
echo "================================================================================"
echo ""

python run_agent.py \
    --org "Google" \
    --industry "Technology" \
    --domains "google.com" \
    2>&1 | tee "output/test_e2e_$(date +%Y%m%d_%H%M%S).log"

TEST_EXIT_CODE=$?

echo ""
echo "================================================================================"
if [ $TEST_EXIT_CODE -eq 0 ]; then
    echo "✓ TEST COMPLETED SUCCESSFULLY"
    echo ""
    echo "Results:"
    echo "  - Report: output/latest_report.html"
    echo "  - Log: output/test_e2e_*.log"
    echo ""

    # Auto-open report in browser
    if [ -f "output/latest_report.html" ]; then
        echo "Opening report in browser..."
        if [[ "$OSTYPE" == "darwin"* ]]; then
            # macOS
            open output/latest_report.html
        elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
            # Linux
            xdg-open output/latest_report.html 2>/dev/null || echo "⚠️  Could not auto-open"
        elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
            # Windows
            start output/latest_report.html
        fi
        echo "✓ Report opened in browser"
        echo ""
    fi

    echo "Verification checklist:"
    echo "  1. ✅ Verify IOC tool links work (click on IOCs)"
    echo "  2. ✅ Check Industry vs. Targeted sections"
    echo "  3. ✅ Verify threat diagram renders"
    echo "  4. ✅ Check source citations are clickable"
else
    echo "✗ TEST FAILED (exit code: $TEST_EXIT_CODE)"
    echo ""
    echo "Troubleshooting:"
    echo "  1. Check output/test_e2e_*.log for errors"
    echo "  2. Verify API credentials are set"
    echo "  3. Check network connectivity"
fi
echo "================================================================================"

exit $TEST_EXIT_CODE
