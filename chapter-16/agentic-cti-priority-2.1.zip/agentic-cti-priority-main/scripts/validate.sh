#!/bin/bash
# CTI Priority Intelligence - Validation Script
# Check if environment is correctly configured

set +e  # Don't exit on errors

# Change to project root (parent of scripts/)
cd "$(dirname "$0")/.."

echo "================================================================================"
echo "  CTI PRIORITY INTELLIGENCE - ENVIRONMENT VALIDATION"
echo "================================================================================"
echo ""

ERRORS=0
WARNINGS=0

# Check 1: Python
echo "[1/8] Checking Python..."
if command -v python3 &>/dev/null; then
    PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
    if python3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)"; then
        echo "✓ Python $PYTHON_VERSION"
    else
        echo "✗ Python $PYTHON_VERSION (need 3.11+)"
        ERRORS=$((ERRORS + 1))
    fi
else
    echo "✗ Python 3 not found"
    ERRORS=$((ERRORS + 1))
fi

# Check 2: Virtual environment
echo ""
echo "[2/8] Checking virtual environment..."
if [ -d "venv" ]; then
    echo "✓ venv/ exists"
else
    echo "✗ venv/ not found - run ./setup.sh first"
    ERRORS=$((ERRORS + 1))
fi

# Check 3: Dependencies
echo ""
echo "[3/8] Checking dependencies..."
if [ -d "venv" ]; then
    source venv/bin/activate 2>/dev/null
    if python -c "import google.adk" 2>/dev/null; then
        echo "✓ Dependencies installed"
    else
        echo "⚠️  Dependencies missing or incomplete - run ./setup.sh"
        WARNINGS=$((WARNINGS + 1))
    fi
else
    echo "⊘ Skipped (no venv)"
fi

# Check 4: gcloud CLI
echo ""
echo "[4/8] Checking gcloud CLI..."
if command -v gcloud &>/dev/null; then
    GCLOUD_VERSION=$(gcloud version 2>&1 | grep "Google Cloud SDK" | awk '{print $4}')
    echo "✓ gcloud $GCLOUD_VERSION"
else
    echo "✗ gcloud not found - install from https://cloud.google.com/sdk"
    ERRORS=$((ERRORS + 1))
fi

# Check 5: GCP authentication
echo ""
echo "[5/8] Checking GCP authentication..."
if command -v gcloud &>/dev/null; then
    if gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | grep -q "@"; then
        ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | head -1)
        echo "✓ Authenticated as: $ACCOUNT"
    else
        echo "✗ Not authenticated - run: gcloud auth login"
        ERRORS=$((ERRORS + 1))
    fi
else
    echo "⊘ Skipped (no gcloud)"
fi

# Check 6: GCP project
echo ""
echo "[6/8] Checking GCP project..."
if command -v gcloud &>/dev/null; then
    PROJECT_ID=$(gcloud config get-value project 2>/dev/null)
    if [ -n "$PROJECT_ID" ] && [ "$PROJECT_ID" != "(unset)" ]; then
        echo "✓ Project: $PROJECT_ID"
    else
        echo "✗ No project configured - run: gcloud config set project YOUR_PROJECT_ID"
        ERRORS=$((ERRORS + 1))
    fi
else
    echo "⊘ Skipped (no gcloud)"
fi

# Check 7: config.yaml
echo ""
echo "[7/8] Checking config.yaml..."
if [ -f "config.yaml" ]; then
    if python3 -c "import yaml; yaml.safe_load(open('config.yaml'))" 2>/dev/null; then
        echo "✓ config.yaml valid"
    else
        echo "✗ config.yaml has syntax errors"
        ERRORS=$((ERRORS + 1))
    fi
else
    echo "✗ config.yaml not found"
    ERRORS=$((ERRORS + 1))
fi

# Check 8: API secrets (optional)
echo ""
echo "[8/8] Checking API secrets..."
if command -v gcloud &>/dev/null; then
    PROJECT_ID=$(gcloud config get-value project 2>/dev/null)
    if [ -n "$PROJECT_ID" ] && [ "$PROJECT_ID" != "(unset)" ]; then
        SECRET_COUNT=0
        for SECRET in "adk-cti-priority-gti-api-key" "adk-cti-priority-flashpoint-api-key" "adk-cti-priority-crowdstrike-client-id" "adk-cti-priority-crowdstrike-client-secret"; do
            if gcloud secrets describe "$SECRET" --project="$PROJECT_ID" &>/dev/null; then
                SECRET_COUNT=$((SECRET_COUNT + 1))
            fi
        done

        if [ $SECRET_COUNT -eq 0 ]; then
            echo "⚠️  No API secrets found - will use OSINT only"
            echo "   Run ./setup.sh to configure secrets"
            WARNINGS=$((WARNINGS + 1))
        elif [ $SECRET_COUNT -eq 4 ]; then
            echo "✓ All API secrets configured"
        else
            echo "⚠️  $SECRET_COUNT/4 API secrets configured"
            echo "   Run: ./scripts/setup_secrets_gsm.sh to add more"
            WARNINGS=$((WARNINGS + 1))
        fi
    else
        echo "⊘ Skipped (no project)"
    fi
else
    echo "⊘ Skipped (no gcloud)"
fi

# Summary
echo ""
echo "================================================================================"
if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo "✓ VALIDATION PASSED - Ready to run!"
    echo "================================================================================"
    echo ""
    echo "Next: ./run.sh"
    exit 0
elif [ $ERRORS -eq 0 ]; then
    echo "⚠️  VALIDATION PASSED WITH WARNINGS"
    echo "================================================================================"
    echo ""
    echo "Warnings: $WARNINGS"
    echo "You can proceed, but some features may be limited."
    echo ""
    echo "Next: ./run.sh"
    exit 0
else
    echo "✗ VALIDATION FAILED"
    echo "================================================================================"
    echo ""
    echo "Errors: $ERRORS"
    echo "Warnings: $WARNINGS"
    echo ""
    echo "Fix the errors above, then run ./validate.sh again."
    echo "Or run ./setup.sh to fix automatically."
    exit 1
fi
