#!/bin/bash
# Enumerate all API schemas using existing credentials

set -e

cd "$(dirname "$0")/.."

echo "================================================================================"
echo "API SCHEMA ENUMERATION - ALL SOURCES"
echo "================================================================================"
echo ""

# Check if venv exists
if [ ! -d "venv" ]; then
    echo "✗ Virtual environment not found!"
    echo "  Run ./RUN_INTERACTIVE.sh first to set up the environment"
    exit 1
fi

# Activate venv
echo "[1/4] Activating virtual environment..."
source venv/bin/activate
echo "✓ venv activated"
echo ""

# Check GCP auth
echo "[2/4] Checking authentication..."
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | grep -q "@"; then
    echo "⚠️  Not authenticated with gcloud"
    echo "  Running: gcloud auth login"
    gcloud auth login
fi
ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | head -1)
echo "✓ Authenticated as: $ACCOUNT"

# Get GCP project
if [ -z "$GOOGLE_CLOUD_PROJECT" ]; then
    PROJECT_ID=$(gcloud config get-value project 2>/dev/null)
    if [ -z "$PROJECT_ID" ] || [ "$PROJECT_ID" = "(unset)" ]; then
        echo ""
        echo "✗ No GCP project configured"
        echo "  Please run: gcloud config set project YOUR_PROJECT_ID"
        exit 1
    fi
    export GOOGLE_CLOUD_PROJECT="$PROJECT_ID"
fi
echo "✓ GCP Project: $GOOGLE_CLOUD_PROJECT"
echo ""

# Enumerate Flashpoint API
echo "[3/3] Enumerating Flashpoint API endpoints..."
echo "================================================================================"
python scripts/enumerate_flashpoint_api.py
FLASHPOINT_EXIT=$?
echo ""

# Summary
echo "================================================================================"
echo "ENUMERATION SUMMARY"
echo "================================================================================"
echo ""

echo "ℹ️  CrowdStrike: Uses FalconPy SDK (introspection via help() at runtime)"
echo ""

if [ $FLASHPOINT_EXIT -eq 0 ]; then
    echo "✓ Flashpoint OpenAPI Spec: references/flashpoint-api/flashpoint_api_openapi_spec.json"
    echo "✓ Flashpoint Schema: references/flashpoint-api/flashpoint_api_schema.json"
    echo "✓ Flashpoint Docs: references/flashpoint-api/flashpoint_api_endpoints.md"
else
    echo "✗ Flashpoint: Enumeration failed (exit code: $FLASHPOINT_EXIT)"
fi

echo ""
echo "These schemas can now be used by the Query Reasoner agent to:"
echo "  - Understand available API methods and parameters"
echo "  - Construct valid queries based on actual API capabilities"
echo "  - Avoid 400 errors from malformed requests"
echo "  - Reason about which endpoints to use for each data type"
echo ""
echo "================================================================================"

exit 0
