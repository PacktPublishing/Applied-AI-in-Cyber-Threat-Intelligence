#!/usr/bin/env python3
"""
Enumerate Flashpoint API Schema

Uses existing Flashpoint credentials to discover and document API endpoints.
Saves the schema to references/flashpoint-api/ for query reasoner use.
"""

import os
import sys
import json
import requests
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from cti_agent.config.secrets import load_secrets_from_gsm

# Disable SSL warnings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


API_BASE_URL = "https://fp.tools/api/v4"


def discover_openapi_spec(api_key: str) -> dict:
    """
    Try to discover OpenAPI/Swagger spec from common endpoints

    Args:
        api_key: Flashpoint API key

    Returns:
        OpenAPI spec dict if found, None otherwise
    """
    headers = {"Authorization": f"Bearer {api_key}"}

    # Common OpenAPI spec endpoints
    spec_endpoints = [
        "/swagger.json",
        "/openapi.json",
        "/api/swagger.json",
        "/api/openapi.json",
        "/v4/swagger.json",
        "/v4/openapi.json",
        "/docs/swagger.json",
        "/docs/openapi.json"
    ]

    print("[Schema Discovery] Checking for OpenAPI/Swagger spec...")
    for endpoint in spec_endpoints:
        url = f"{API_BASE_URL}{endpoint}"
        try:
            resp = requests.get(url, headers=headers, timeout=10, verify=False)
            if resp.status_code == 200:
                try:
                    spec = resp.json()
                    print(f"[Schema Discovery] ✓ Found OpenAPI spec at: {endpoint}")
                    return spec
                except json.JSONDecodeError:
                    continue
        except Exception:
            continue

    print("[Schema Discovery] ⚠️  No OpenAPI spec found at common endpoints")
    return None


def enumerate_known_endpoints(api_key: str) -> dict:
    """
    Enumerate known Flashpoint API endpoints and document their parameters

    Args:
        api_key: Flashpoint API key

    Returns:
        Dict with endpoint documentation
    """
    headers = {"Authorization": f"Bearer {api_key}"}

    # VALIDATED endpoints from actual API enumeration + HAR trace (2026-02-11)
    # These 3 endpoints confirmed working (200 OK)
    endpoints = {
        "indicators_simple": {
            "path": "/indicators/simple",
            "method": "GET",
            "description": "Search for compromised credentials and technical indicators",
            "parameters": {
                "query": "Search query (e.g., +domain:\"example.com\")",
                "limit": "Max results (default: 100)",
                "types": "Comma-separated indicator types (e.g., email,credential-pair,domain,ip-dst)",
                "since": "ISO timestamp for time filtering",
                "until": "ISO timestamp for time filtering"
            }
        },
        "indicators_attribute": {
            "path": "/indicators/attribute",
            "method": "GET",
            "description": "Search indicators by attribute (alternate endpoint)",
            "parameters": {
                "query": "Search query",
                "limit": "Max results"
            }
        },
        "reports": {
            "path": "/reports",
            "method": "GET",
            "description": "Search finished intelligence reports",
            "parameters": {
                "query": "Search query (threat actor, campaign, industry, etc.)",
                "limit": "Max results",
                "skip": "Offset for pagination",
                "sort": "Sort field",
                "sort_date": "Date range filter (e.g., Last 30 Days)",
                "tags": "Filter by tags",
                "is_featured": "Filter for featured reports only",
                "since": "ISO timestamp for time filtering",
                "until": "ISO timestamp for time filtering"
            }
        }
    }

    # These endpoints were tested but returned 404/503 - not included in OpenAPI spec:
    # /forums/posts, /finished-intelligence/reports, /vulnerabilities, /communities/search,
    # /reports/search, /paste-sites/search, /malware/search, /cards/search,
    # /chat-services/search, /compromised-credentials/search, /threat-actors/search,
    # /leaked-credentials

    # Test each endpoint to get actual response schema
    print("\n[Endpoint Testing] Testing known endpoints...")
    for name, endpoint_info in endpoints.items():
        url = f"{API_BASE_URL}{endpoint_info['path']}"

        try:
            # Make a minimal test query
            params = {"limit": 1}
            resp = requests.get(url, headers=headers, params=params, timeout=15, verify=False)

            endpoint_info["status_code"] = resp.status_code
            endpoint_info["tested"] = True

            if resp.status_code == 200:
                try:
                    data = resp.json()

                    # Extract response schema
                    endpoint_info["response_schema"] = {
                        "type": "object",
                        "keys": list(data.keys()) if isinstance(data, dict) else [],
                        "data_type": type(data).__name__
                    }

                    # Get sample item if available
                    if isinstance(data, dict) and "data" in data and isinstance(data["data"], list) and len(data["data"]) > 0:
                        sample_item = data["data"][0]
                        endpoint_info["response_schema"]["sample_item_keys"] = list(sample_item.keys()) if isinstance(sample_item, dict) else []

                    print(f"[Endpoint Testing]   ✓ {name}: {resp.status_code} - Response keys: {endpoint_info['response_schema']['keys']}")
                except json.JSONDecodeError:
                    print(f"[Endpoint Testing]   ⚠️  {name}: {resp.status_code} - Invalid JSON response")
            else:
                print(f"[Endpoint Testing]   ✗ {name}: {resp.status_code}")

                # Try to get error details
                try:
                    error_data = resp.json()
                    endpoint_info["error"] = error_data
                except:
                    endpoint_info["error"] = resp.text[:200]

        except Exception as e:
            endpoint_info["tested"] = False
            endpoint_info["error"] = str(e)
            print(f"[Endpoint Testing]   ✗ {name}: Error - {e}")

    return endpoints


def enumerate_with_options(api_key: str) -> dict:
    """
    Try OPTIONS request to discover available endpoints

    Args:
        api_key: Flashpoint API key

    Returns:
        Dict with discovered endpoints
    """
    headers = {"Authorization": f"Bearer {api_key}"}

    print("\n[OPTIONS Discovery] Trying OPTIONS requests...")

    base_paths = [
        "/",
        "/indicators",
        "/communities",
        "/reports",
        "/vulnerabilities"
    ]

    discovered = {}
    for path in base_paths:
        url = f"{API_BASE_URL}{path}"
        try:
            resp = requests.options(url, headers=headers, timeout=10, verify=False)
            if "Allow" in resp.headers:
                discovered[path] = {
                    "allowed_methods": resp.headers["Allow"],
                    "status_code": resp.status_code
                }
                print(f"[OPTIONS Discovery]   ✓ {path}: {resp.headers['Allow']}")
        except Exception as e:
            print(f"[OPTIONS Discovery]   ✗ {path}: {e}")

    return discovered


def convert_to_openapi_spec(schema_data: dict) -> dict:
    """
    Convert enumerated schema to OpenAPI 3.0 specification

    Args:
        schema_data: Enumerated schema data

    Returns:
        OpenAPI 3.0 spec dict
    """
    openapi_spec = {
        "openapi": "3.0.0",
        "info": {
            "title": "Flashpoint Ignite API",
            "description": "Auto-generated OpenAPI specification from API enumeration",
            "version": "v4",
            "contact": {
                "name": "Flashpoint",
                "url": "https://docs.flashpoint.io/"
            }
        },
        "servers": [
            {
                "url": schema_data["base_url"],
                "description": "Flashpoint API v4"
            }
        ],
        "security": [
            {
                "BearerAuth": []
            }
        ],
        "components": {
            "securitySchemes": {
                "BearerAuth": {
                    "type": "http",
                    "scheme": "bearer",
                    "description": "Flashpoint API key (Bearer token)"
                }
            },
            "schemas": {}
        },
        "paths": {}
    }

    # Convert each endpoint to OpenAPI path
    for name, endpoint in schema_data.get("endpoints", {}).items():
        path = endpoint["path"]

        # Initialize path if not exists
        if path not in openapi_spec["paths"]:
            openapi_spec["paths"][path] = {}

        # Build parameters
        parameters = []
        for param_name, param_desc in endpoint.get("parameters", {}).items():
            param_schema = {
                "name": param_name,
                "in": "query",
                "description": param_desc,
                "required": param_name in ["query"],  # query param typically required
                "schema": {
                    "type": "string" if param_name != "limit" else "integer"
                }
            }
            parameters.append(param_schema)

        # Build response schema
        response_schema = {
            "200": {
                "description": "Successful response",
                "content": {
                    "application/json": {
                        "schema": {
                            "type": "object"
                        }
                    }
                }
            }
        }

        # If we have actual response schema from testing, add it
        if "response_schema" in endpoint and endpoint.get("tested"):
            schema_info = endpoint["response_schema"]
            response_obj = {
                "type": schema_info.get("data_type", "object"),
                "properties": {}
            }

            # Add root keys as properties
            if schema_info.get("keys"):
                for key in schema_info["keys"]:
                    if key == "data":
                        response_obj["properties"][key] = {
                            "type": "array",
                            "items": {
                                "type": "object"
                            }
                        }
                        # Add sample item keys if available
                        if schema_info.get("sample_item_keys"):
                            item_props = {}
                            for item_key in schema_info["sample_item_keys"]:
                                item_props[item_key] = {"type": "string"}
                            response_obj["properties"][key]["items"]["properties"] = item_props
                    else:
                        response_obj["properties"][key] = {"type": "object"}

            response_schema["200"]["content"]["application/json"]["schema"] = response_obj

        # Add error responses if we have them
        if endpoint.get("error"):
            error_code = str(endpoint.get("status_code", "4xx"))
            response_schema[error_code] = {
                "description": f"Error response: {endpoint.get('error', 'Unknown error')}",
                "content": {
                    "application/json": {
                        "schema": {
                            "type": "object",
                            "properties": {
                                "error": {"type": "string"}
                            }
                        }
                    }
                }
            }

        # Build operation
        operation = {
            "summary": endpoint.get("description", ""),
            "operationId": name,
            "tags": [name.split("_")[0]],  # Tag by module (indicators, communities, etc.)
            "parameters": parameters,
            "responses": response_schema
        }

        # Add to spec
        method = endpoint["method"].lower()
        openapi_spec["paths"][path][method] = operation

    return openapi_spec


def save_schema(schema_data: dict, output_dir: Path):
    """
    Save enumerated schema to files

    Args:
        schema_data: Schema data to save
        output_dir: Output directory
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    # Save comprehensive schema (internal format)
    schema_file = output_dir / "flashpoint_api_schema.json"
    with open(schema_file, 'w') as f:
        json.dump(schema_data, f, indent=2)
    print(f"\n[Save] ✓ Saved comprehensive schema to: {schema_file}")

    # Convert to OpenAPI 3.0 format and save
    openapi_spec = convert_to_openapi_spec(schema_data)
    openapi_file = output_dir / "flashpoint_api_openapi_spec.json"
    with open(openapi_file, 'w') as f:
        json.dump(openapi_spec, f, indent=2)
    print(f"[Save] ✓ Saved OpenAPI 3.0 spec to: {openapi_file}")

    # Save human-readable documentation
    docs_file = output_dir / "flashpoint_api_endpoints.md"
    with open(docs_file, 'w') as f:
        f.write("# Flashpoint API Endpoints\n\n")
        f.write("**Auto-generated from API enumeration**\n\n")
        f.write(f"**Base URL**: {API_BASE_URL}\n\n")
        f.write("---\n\n")

        if "openapi_spec" in schema_data and schema_data["openapi_spec"]:
            f.write("## OpenAPI Specification\n\n")
            f.write("✓ OpenAPI/Swagger spec found and saved to flashpoint_api_schema.json\n\n")
            f.write("---\n\n")

        f.write("## Known Endpoints\n\n")
        for name, endpoint in schema_data.get("endpoints", {}).items():
            f.write(f"### {name.title()}\n\n")
            f.write(f"**Path**: `{endpoint['path']}`\n\n")
            f.write(f"**Method**: {endpoint['method']}\n\n")
            f.write(f"**Description**: {endpoint['description']}\n\n")

            if endpoint.get("tested"):
                status = "✓" if endpoint.get("status_code") == 200 else "✗"
                f.write(f"**Status**: {status} ({endpoint.get('status_code')})\n\n")

            f.write("**Parameters**:\n")
            for param, desc in endpoint.get("parameters", {}).items():
                f.write(f"- `{param}`: {desc}\n")
            f.write("\n")

            if "response_schema" in endpoint:
                f.write("**Response Schema**:\n")
                schema = endpoint["response_schema"]
                f.write(f"- Type: {schema.get('data_type', 'unknown')}\n")
                if schema.get("keys"):
                    f.write(f"- Root keys: {', '.join(schema['keys'])}\n")
                if schema.get("sample_item_keys"):
                    f.write(f"- Sample item keys: {', '.join(schema['sample_item_keys'])}\n")
                f.write("\n")

            f.write("---\n\n")

    print(f"[Save] ✓ Saved documentation to: {docs_file}")


def main():
    """Main enumeration process"""
    print("="*80)
    print("FLASHPOINT API SCHEMA ENUMERATION")
    print("="*80)
    print()

    # Load secrets
    print("[Setup] Loading API credentials from Google Secret Manager...")
    try:
        sm = load_secrets_from_gsm()
        api_key = os.environ.get("FP_API_KEY")

        if not api_key:
            print("[Setup] ✗ FP_API_KEY not found in environment")
            print("[Setup]   Ensure secrets are loaded: gcloud auth login")
            return 1

        print(f"[Setup] ✓ API key loaded: {api_key[:10]}...")
    except Exception as e:
        print(f"[Setup] ✗ Failed to load secrets: {e}")
        return 1

    # Enumerate API
    schema_data = {
        "base_url": API_BASE_URL,
        "enumerated_at": __import__('datetime').datetime.utcnow().isoformat(),
        "openapi_spec": None,
        "endpoints": {},
        "options_discovery": {}
    }

    # Try to discover OpenAPI spec
    openapi_spec = discover_openapi_spec(api_key)
    if openapi_spec:
        schema_data["openapi_spec"] = openapi_spec

    # Enumerate known endpoints
    endpoints = enumerate_known_endpoints(api_key)
    schema_data["endpoints"] = endpoints

    # Try OPTIONS discovery
    options_data = enumerate_with_options(api_key)
    schema_data["options_discovery"] = options_data

    # Save results
    output_dir = Path(__file__).parent.parent / "references" / "flashpoint-api"
    save_schema(schema_data, output_dir)

    print()
    print("="*80)
    print("ENUMERATION COMPLETE")
    print("="*80)
    print()
    print("Files created:")
    print("  - flashpoint_api_schema.json (internal format)")
    print("  - flashpoint_api_openapi_spec.json (OpenAPI 3.0 format)")
    print("  - flashpoint_api_endpoints.md (human-readable)")
    print()
    print("Next steps:")
    print("1. Review: references/flashpoint-api/flashpoint_api_endpoints.md")
    print("2. Use OpenAPI spec with Query Reasoner agent")
    print("3. Update Flashpoint tool with correct syntax")
    print()

    return 0


if __name__ == "__main__":
    sys.exit(main())
