#!/bin/bash
# CTI Priority Intelligence - CLI Mode Runner
# Wrapper for non-interactive execution (ADK CLI, automation, scripts)
# Handles venv activation and gcloud auth before running

set -e

cd "$(dirname "$0")"

# Check if venv exists
if [ ! -d "venv" ]; then
    echo "✗ Virtual environment not found"
    echo "  Run setup first: ./setup.sh"
    exit 1
fi

# Activate venv
source venv/bin/activate

# Check dependencies (quick)
if ! python -c "import google.adk" &>/dev/null; then
    echo "✗ Dependencies not installed"
    echo "  Run: ./setup.sh"
    exit 1
fi

# Check GCP auth
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | grep -q "@"; then
    echo "✗ Not authenticated with gcloud"
    echo "  Run: gcloud auth login"
    exit 1
fi

# Get GCP project (from env var or gcloud config)
if [ -z "$GOOGLE_CLOUD_PROJECT" ]; then
    PROJECT_ID=$(gcloud config get-value project 2>/dev/null)
    if [ -z "$PROJECT_ID" ] || [ "$PROJECT_ID" = "(unset)" ]; then
        echo "✗ No GCP project configured"
        echo "  Run: gcloud config set project YOUR_PROJECT_ID"
        echo "  Or: export GOOGLE_CLOUD_PROJECT=your-project-id"
        exit 1
    fi
    export GOOGLE_CLOUD_PROJECT="$PROJECT_ID"
fi

# Run with all passed arguments (CLI mode, non-interactive)
python run_agent.py "$@"
