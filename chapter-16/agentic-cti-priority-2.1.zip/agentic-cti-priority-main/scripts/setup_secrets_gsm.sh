#!/bin/bash
# CTI Priority - Setup Secrets in Google Secret Manager
# Interactive setup with retry logic and graceful error handling

set -e

# Configuration
MAX_RETRIES=2
RETRY_DELAY=2

# Get script directory and navigate to project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

LOG_DIR="$PROJECT_ROOT/logs"
LOG_FILE="$LOG_DIR/secrets.log"

# Create log directory
mkdir -p "$LOG_DIR"

# Logging function
log() {
    local level=$1
    shift
    local message="$@"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message" >> "$LOG_FILE"
}

PROJECT_ID=$(gcloud config get-value project 2>/dev/null)

if [[ -z "$PROJECT_ID" ]] || [[ "$PROJECT_ID" == "(unset)" ]]; then
    echo "❌ Error: No GCP project configured"
    echo ""
    echo "Run: gcloud config set project YOUR_PROJECT_ID"
    echo "Or: gcloud init"
    log "ERROR" "No GCP project configured"
    exit 1
fi

echo "============================================================"
echo "  CTI Priority Intelligence - Secret Setup"
echo "============================================================"
echo ""
echo "Project: $PROJECT_ID"
echo "Log: $LOG_FILE"
echo ""
log "INFO" "Starting secret setup for project: $PROJECT_ID"

# Function to add secret (with retry logic)
add_secret() {
    local name="$1"
    local prompt="$2"
    local attempt=1

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "$prompt"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # Check if exists
    local exists=false
    if gcloud secrets describe "$name" --project="$PROJECT_ID" &>/dev/null; then
        exists=true
        echo "⚠️  Secret '$name' already exists."
        log "INFO" "Secret $name already exists"
        read -r -p "Update it? (y/n): " update
        if [[ "$update" != "y" ]]; then
            echo "→ Skipped (keeping existing value)."
            log "INFO" "Skipped updating $name (user choice)"
            echo ""
            return
        fi
        echo "→ Updating with new value..."
        log "INFO" "Updating existing secret: $name"
    fi

    read -r -p "Paste API key (or press Enter to skip): " value

    if [[ -z "$value" ]]; then
        echo "→ Empty input, skipped. (You can re-run this script to add it later)"
        log "INFO" "Skipped $name (empty input)"
        echo ""
        return
    fi

    # Create or update with retry logic
    while [ $attempt -le $MAX_RETRIES ]; do
        if [[ "$exists" == "true" ]]; then
            # Update existing secret
            if echo -n "$value" | gcloud secrets versions add "$name" --data-file=- --project="$PROJECT_ID" >> "$LOG_FILE" 2>&1; then
                echo "✓ Updated: $name"
                log "SUCCESS" "Updated secret: $name"
                echo ""
                return 0
            else
                local exit_code=$?
                log "ERROR" "Failed to update $name (attempt $attempt, exit code: $exit_code)"

                if [ $attempt -ge $MAX_RETRIES ]; then
                    echo "❌ Failed to update: $name (after $MAX_RETRIES attempts)"
                    log "FATAL" "Failed to update $name after $MAX_RETRIES attempts"
                    return 1
                fi

                echo "⚠️  Retry attempt $attempt/$MAX_RETRIES..."
                sleep $RETRY_DELAY
            fi
        else
            # Create new secret
            if echo -n "$value" | gcloud secrets create "$name" \
                --replication-policy="automatic" \
                --data-file=- \
                --project="$PROJECT_ID" \
                --labels="app=adk-cti-priority" >> "$LOG_FILE" 2>&1; then
                echo "✓ Created: $name"
                log "SUCCESS" "Created secret: $name"
                echo ""
                return 0
            else
                local exit_code=$?
                log "ERROR" "Failed to create $name (attempt $attempt, exit code: $exit_code)"

                if [ $attempt -ge $MAX_RETRIES ]; then
                    echo "❌ Failed to create: $name (after $MAX_RETRIES attempts)"
                    log "FATAL" "Failed to create $name after $MAX_RETRIES attempts"
                    return 1
                fi

                echo "⚠️  Retry attempt $attempt/$MAX_RETRIES..."
                sleep $RETRY_DELAY
            fi
        fi

        attempt=$((attempt + 1))
    done

    echo ""
    return 1
}

# 1. Google Threat Intelligence
log "INFO" "Starting GTI secret setup"
add_secret "adk-cti-priority-gti-api-key" "[1/3] Google Threat Intelligence (VirusTotal) API Key"

# 2. CrowdStrike (both required - OAuth2 authentication)
echo ""
echo "Note: CrowdStrike requires BOTH Client ID and Secret"
echo "      Find them in Falcon Console: Support → API Clients & Keys"
echo ""
log "INFO" "Starting CrowdStrike secrets setup"
add_secret "adk-cti-priority-crowdstrike-client-id" "[2/3] CrowdStrike Client ID (like a username)"
add_secret "adk-cti-priority-crowdstrike-client-secret" "[3/3] CrowdStrike Client Secret (like a password)"

# 3. Flashpoint - Manual Instructions (JWT tokens too long for shell)
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  FLASHPOINT API KEY - MANUAL SETUP REQUIRED"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "⚠️  Flashpoint JWT tokens are too long for shell input."
echo ""
echo "OPTION 1 - Use GCP Console (Easiest):"
echo "  1. Open: https://console.cloud.google.com/security/secret-manager?project=$PROJECT_ID"
echo "  2. Click 'CREATE SECRET'"
echo "  3. Name: adk-cti-priority-flashpoint-api-key"
echo "  4. Secret value: Paste your Flashpoint JWT token"
echo "  5. Click 'CREATE SECRET'"
echo ""
echo "OPTION 2 - Use gcloud command:"
echo "  Save your JWT to a file first, then run:"
echo "  echo -n 'YOUR_JWT_TOKEN' > /tmp/fp.txt"
echo "  gcloud secrets create adk-cti-priority-flashpoint-api-key \\"
echo "    --replication-policy=automatic \\"
echo "    --data-file=/tmp/fp.txt \\"
echo "    --project=$PROJECT_ID"
echo "  rm /tmp/fp.txt"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
log "INFO" "Flashpoint manual setup instructions displayed"

echo "============================================================"
echo "✓ Setup complete!"
echo "============================================================"
echo ""
log "SUCCESS" "Secret setup complete"

# Count configured secrets
SECRET_COUNT=0
for SECRET in "adk-cti-priority-gti-api-key" "adk-cti-priority-flashpoint-api-key" "adk-cti-priority-crowdstrike-client-id" "adk-cti-priority-crowdstrike-client-secret"; do
    if gcloud secrets describe "$SECRET" --project="$PROJECT_ID" &>/dev/null; then
        SECRET_COUNT=$((SECRET_COUNT + 1))
    fi
done

echo "Configured secrets: $SECRET_COUNT/4"
log "INFO" "Total configured secrets: $SECRET_COUNT/4"

if [ $SECRET_COUNT -eq 0 ]; then
    echo "⚠️  No API secrets configured - system will use OSINT-only mode"
    log "WARN" "No API secrets configured (OSINT-only mode)"
elif [ $SECRET_COUNT -eq 4 ]; then
    echo "✓ All API secrets configured!"
    log "SUCCESS" "All API secrets configured"
else
    echo "⚠️  Partial configuration - system will use available sources"
    log "WARN" "Partial secret configuration ($SECRET_COUNT/4)"
fi

echo ""
echo "Verify secrets:"
echo "  gcloud secrets list --filter='name:adk-cti-priority'"
echo ""
echo "View logs:"
echo "  cat $LOG_FILE"
echo ""
