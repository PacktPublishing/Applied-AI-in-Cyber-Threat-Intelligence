#!/bin/bash
# CTI Priority Intelligence - One-Time Setup
# Robust setup with retry logic and graceful error handling

set -e

# Configuration
MAX_RETRIES=3
RETRY_DELAY=2

cd "$(dirname "$0")"

LOG_DIR="logs"
LOG_FILE="$LOG_DIR/setup.log"

# Create log directory
mkdir -p "$LOG_DIR"

# Initialize log
cat > "$LOG_FILE" << EOF
CTI Priority Intelligence - Setup Log
Started: $(date '+%Y-%m-%d %H:%M:%S')
========================================

EOF

# Logging function
log() {
    local level=$1
    shift
    local message="$@"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message" >> "$LOG_FILE"
    if [ "$level" != "DEBUG" ]; then
        echo "[$level] $message"
    fi
}

# Retry wrapper
retry_command() {
    local description=$1
    shift
    local cmd="$@"
    local attempt=1

    while [ $attempt -le $MAX_RETRIES ]; do
        if [ $attempt -gt 1 ]; then
            log "RETRY" "Attempt $attempt/$MAX_RETRIES: $description"
            sleep $RETRY_DELAY
        fi

        if eval "$cmd" >> "$LOG_FILE" 2>&1; then
            log "SUCCESS" "$description"
            return 0
        else
            local exit_code=$?
            log "ERROR" "$description failed (attempt $attempt, exit code: $exit_code)"

            if [ $attempt -ge $MAX_RETRIES ]; then
                log "FATAL" "Max retries exceeded for: $description"
                return $exit_code
            fi
        fi

        attempt=$((attempt + 1))
    done

    return 1
}

echo "================================================================================"
echo "  CTI PRIORITY INTELLIGENCE - SETUP"
echo "================================================================================"
echo ""
echo "This script will:"
echo "  1. Check Python 3.11+ installation"
echo "  2. Create Python virtual environment"
echo "  3. Install dependencies"
echo "  4. Authenticate with Google Cloud"
echo "  5. Configure API secrets in Google Secret Manager"
echo ""
echo "Log file: $LOG_FILE"
echo ""
read -r -p "Continue with setup? (y/n): " confirm

if [[ "$confirm" != "y" ]]; then
    log "INFO" "Setup cancelled by user"
    echo "Setup cancelled."
    exit 0
fi

log "INFO" "Setup started"

# Step 1: Check Python version
echo ""
echo "[1/5] Checking Python version..."
log "INFO" "Checking Python version"

if ! command -v python3 &>/dev/null; then
    log "ERROR" "Python 3 not found"
    echo "✗ Python 3 not found"
    echo "  Install Python 3.11 or higher from: https://www.python.org/downloads/"
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')

if python3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)"; then
    echo "✓ Python $PYTHON_VERSION detected"
    log "SUCCESS" "Python $PYTHON_VERSION detected"
else
    log "ERROR" "Python $PYTHON_VERSION is too old (need 3.11+)"
    echo "✗ Python $PYTHON_VERSION is too old (need 3.11+)"
    echo "  Install Python 3.11 or higher"
    exit 1
fi

# Step 2: Create virtual environment
echo ""
echo "[2/5] Creating virtual environment..."
log "INFO" "Creating virtual environment"

if [ -d "venv" ]; then
    echo "✓ Virtual environment already exists"
    log "INFO" "Virtual environment already exists"
else
    if retry_command "Creating virtual environment" "python3 -m venv venv"; then
        echo "✓ Virtual environment created"
    else
        log "FATAL" "Failed to create virtual environment"
        echo "✗ Failed to create virtual environment"
        echo "  Check the log: $LOG_FILE"
        exit 1
    fi
fi

# Step 3: Install dependencies
echo ""
echo "[3/5] Installing dependencies..."
log "INFO" "Installing dependencies"

source venv/bin/activate

if retry_command "Upgrading pip" "pip install --upgrade pip -q"; then
    log "SUCCESS" "pip upgraded"
else
    log "WARN" "pip upgrade failed, continuing anyway"
fi

if retry_command "Installing requirements" "pip install -r requirements.txt -q"; then
    echo "✓ Dependencies installed (168 packages)"
else
    log "FATAL" "Failed to install dependencies"
    echo "✗ Failed to install dependencies"
    echo "  Check the log: $LOG_FILE"
    echo "  Try manually: source venv/bin/activate && pip install -r requirements.txt"
    exit 1
fi

# Step 4: GCP Authentication
echo ""
echo "[4/5] Setting up Google Cloud authentication..."
log "INFO" "Checking GCP authentication"

if ! command -v gcloud &>/dev/null; then
    log "ERROR" "gcloud CLI not found"
    echo "✗ gcloud CLI not found"
    echo ""
    echo "Install Google Cloud SDK:"
    echo "  https://cloud.google.com/sdk/docs/install"
    echo ""
    echo "After installing, run this setup script again."
    exit 1
fi

# Check if already authenticated
if gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | grep -q "@"; then
    ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | head -1)
    echo "✓ Already authenticated as: $ACCOUNT"
    log "SUCCESS" "Already authenticated as: $ACCOUNT"
else
    echo "  Launching browser for authentication..."
    log "INFO" "Launching gcloud auth login"

    if retry_command "GCP authentication" "gcloud auth login"; then
        ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | head -1)
        echo "✓ Authentication complete: $ACCOUNT"
        log "SUCCESS" "Authentication complete: $ACCOUNT"
    else
        log "FATAL" "GCP authentication failed"
        echo "✗ Authentication failed"
        echo "  Try manually: gcloud auth login"
        exit 1
    fi
fi

# Check/set project
PROJECT_ID=$(gcloud config get-value project 2>/dev/null)
if [ -z "$PROJECT_ID" ] || [ "$PROJECT_ID" = "(unset)" ]; then
    echo ""
    echo "No GCP project configured."
    read -r -p "Enter your GCP project ID: " PROJECT_ID

    if retry_command "Setting GCP project" "gcloud config set project $PROJECT_ID"; then
        echo "✓ Project set to: $PROJECT_ID"
        log "SUCCESS" "Project set to: $PROJECT_ID"
    else
        log "ERROR" "Failed to set project"
        echo "✗ Failed to set project"
        echo "  Try manually: gcloud config set project YOUR_PROJECT_ID"
    fi
else
    echo "✓ Project: $PROJECT_ID"
    log "INFO" "Using existing project: $PROJECT_ID"
fi

# Step 5: Configure secrets
echo ""
echo "[5/5] Configuring API secrets..."
log "INFO" "Starting secret configuration"
echo ""
echo "You need API keys from these services:"
echo "  - Google Threat Intelligence (VirusTotal) - recommended"
echo "  - Flashpoint - optional"
echo "  - CrowdStrike Falcon - optional"
echo ""
echo "All keys are optional. The system will work with OSINT-only mode."
echo ""
echo "Running secret configuration..."
echo ""

if ./scripts/setup_secrets_gsm.sh; then
    log "SUCCESS" "Secret configuration complete"
else
    log "WARN" "Secret configuration had warnings (this is OK)"
fi

# Done
echo ""
echo "================================================================================"
echo "✓ SETUP COMPLETE!"
echo "================================================================================"
echo ""
log "SUCCESS" "Setup complete"

echo "Next steps:"
echo "  1. Run the agent: ./run.sh"
echo "  2. Validate setup: ./scripts/validate.sh"
echo "  3. View logs: cat $LOG_FILE"
echo ""
echo "For help: cat README.md"
echo ""
