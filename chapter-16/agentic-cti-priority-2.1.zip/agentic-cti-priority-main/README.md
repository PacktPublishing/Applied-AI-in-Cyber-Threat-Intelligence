# CTI Priority Intelligence System

Multi-source threat intelligence gathering using GCP Vertex's Gemini 2.5, and CTI APIs.

Aggregates intelligence from **Google Threat Intelligence**, **Flashpoint**, **CrowdStrike**, and **OSINT sources** to deliver tactical threat reports for CTI analysts.

---

## Prerequisites

**Required:**
- Python 3.11+
- Google Cloud SDK (gcloud)
- GCP account with Vertex AI enabled

**Platform Support:**
- macOS/Linux (bash/zsh)
- Windows (PowerShell or Git Bash)

**API Keys (all optional):**
- Google Threat Intelligence (VirusTotal) - recommended
- Flashpoint - optional
- CrowdStrike Falcon - optional

---

## Quick Start

### 1. One-Time Setup

**macOS/Linux:**
```bash
./setup.sh
```

**Windows (PowerShell):**
```powershell
# Create virtual environment
python -m venv venv

# Activate venv
.\venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt

# Authenticate with Google Cloud
gcloud auth login
gcloud config set project YOUR_PROJECT_ID

# Setup secrets (run in Git Bash or WSL)
bash scripts/setup_secrets_gsm.sh
```

**Windows (Git Bash):**
```bash
./setup.sh
```

This will:
- Check Python 3.11+ and create virtual environment
- Install dependencies
- Authenticate with Google Cloud
- Configure API secrets in Google Secret Manager
- Validate everything is ready

### 2. Configure Your Organization

Edit `config.yaml` in the project root:

```yaml
organization:
  name: "Your Company Name"
  industry: "Technology"
  domains:
    - "yourcompany.com"
    - "yourapp.io"
  brands:
    - "YourBrand"
  competitors:
    - "Competitor A"
  technology_stack:
    - "AWS"
    - "Kubernetes"
```

### 3. Run

Choose any execution method below.

---

## Execution Methods

### Method 1: Automated Script (Recommended)

Best for: Quick runs, automation, CI/CD

**macOS/Linux:**
```bash
# From project root
./run.sh
```

**Windows (PowerShell):**
```powershell
# From project root
.\venv\Scripts\Activate.ps1
python run_agent.py --from-config
```

**Windows (Git Bash):**
```bash
# From project root
./run.sh
```

- Loads configuration from `config.yaml`
- Includes retry logic and error handling
- Auto-opens HTML report in browser
- Logs everything to `logs/run.log`

Output: `output/latest_report.html`

---

### Method 2: CLI with Config File

Best for: Automation scripts, scheduled jobs

**macOS/Linux:**
```bash
# From project root
source venv/bin/activate
python run_agent.py --from-config
```

**Windows (PowerShell):**
```powershell
# From project root
.\venv\Scripts\Activate.ps1
python run_agent.py --from-config
```

- Loads configuration from `config.yaml`
- No prompts or user input needed
- Perfect for cron jobs or CI/CD

Output: `output/latest_report.html`

---

### Method 3: CLI with Arguments

Best for: Scripting, dynamic inputs, testing different targets

**macOS/Linux:**
```bash
# From project root
source venv/bin/activate

python run_agent.py \
  --org "Company Name" \
  --industry "Technology" \
  --domains "example.com,example.io" \
  --brands "Brand1,Brand2" \
  --competitors "Competitor A,Competitor B" \
  --tech "AWS,Kubernetes,Python"
```

**Windows (PowerShell):**
```powershell
# From project root
.\venv\Scripts\Activate.ps1

python run_agent.py --org "Company Name" --industry "Technology" --domains "example.com,example.io" --brands "Brand1,Brand2" --competitors "Competitor A,Competitor B" --tech "AWS,Kubernetes,Python"
```

**All CLI options:**

```bash
python run_agent.py --help

Required (unless using --interactive or --from-config):
  --org ORGANIZATION        Organization name
  --domains DOMAINS         Comma-separated domains

Optional:
  --industry INDUSTRY       Industry sector (default: "Unknown")
  --brands BRANDS           Comma-separated brand names
  --competitors COMPETITORS Comma-separated competitors
  --tech TECH               Comma-separated technology stack

Modes:
  --from-config, -c         Load from config.yaml (no prompts)
  --interactive, -i         Interactive mode (prompts for input)
```

Output: `output/latest_report.html`

---

### Method 4: Interactive Mode

Best for: One-off runs, manual exploration

**macOS/Linux:**
```bash
# From project root
source venv/bin/activate
python run_agent.py --interactive
```

**Windows (PowerShell):**
```powershell
# From project root
.\venv\Scripts\Activate.ps1
python run_agent.py --interactive
```

You'll be prompted for organization details.

Output: `output/latest_report.html`

---

## Report Output

### Tactical HTML Report Sections

1. **Executive Summary**
   - Top 5 critical findings
   - Prioritized by recency (24h/7d preferred)
   - Confidence and risk scores
   - Threat actor attribution
   - Source citations

2. **Intelligence Source Status**
   - Per-module health check
   - Success/partial/failed indicators
   - Error messages for troubleshooting

3. **Temporal Intelligence**
   - Last 24 Hours: Immediate threats
   - Last 7 Days: Week-old intelligence
   - Last 30 Days: Context and trends

4. **Threat Correlation & Attack Chains**
   - Mermaid diagram showing relationships

5. **CrowdStrike FQL Hunt Queries**
   - Ready-to-paste into Falcon console

6. **Correlated Assets**
   - Links to findings in CrowdStrike, Flashpoint, Google TI

---

## Architecture

### 7-Agent System (Adaptive Multi-Pass)

```
Orchestrator
  - Load balances across 8 Vertex AI regions
  - Coordinates 4 specialists in parallel

COLLECTION PHASE (Parallel)
  - GTI Specialist (3 adaptive passes)
  - Flashpoint Specialist (circuit break)
  - CrowdStrike Specialist (10 modules)
  - OSINT Specialist (Google dorking)

Analyzer Agent
  - Deduplicates indicators
  - Correlates threats
  - Maps to MITRE ATT&CK

Reporter Agent
  - Top 5 critical findings
  - Temporal sections (24h/7d/30d)
  - CrowdStrike FQL queries
  - HTML tactical report
```

Performance: ~2-4 minutes end-to-end

---

## Configuration Guide

### Organization Profile (config.yaml)

```yaml
organization:
  name: "Example Corp"
  industry: "Technology"
  domains:
    - "example.com"
    - "example.io"
  brands:
    - "Example"
  competitors:
    - "Competitor A"
  technology_stack:
    - "AWS"
    - "Kubernetes"
```

### OSINT Sources

Enable/disable news feeds and advisories:

```yaml
osint_sources:
  news_feeds:
    - name: "The Hacker News"
      url: "https://thehackernews.com/feeds/posts/default"
      enabled: true
      priority: high

  advisories:
    - name: "CISA Alerts"
      url: "https://www.cisa.gov/cybersecurity-advisories/all.xml"
      enabled: true
      priority: high
```

### Model Configuration

Customize Gemini models:

```yaml
models:
  correlator:
    name: "gemini-2.5-pro"
    temperature: 0.2

  collectors:
    name: "gemini-2.5-flash"
    temperature: 0.3

  report_generator:
    name: "gemini-2.5-flash"
    temperature: 0.4
```

### Performance Tuning

```yaml
performance:
  max_concurrent_collectors: 5
  inter_agent_delay_seconds: 3.0
  collection_timeout_seconds: 180
```

---

## Security

- Secrets stored in Google Secret Manager (encrypted at rest)
- Access via gcloud auth (no credentials on disk)
- Read-only API operations
- Input validation with Pydantic schemas

---

## Troubleshooting

### Secrets Not Found

```bash
# From project root
./scripts/setup_secrets_gsm.sh

# Verify secrets exist
gcloud secrets list --filter='name:adk-cti-priority'
```

### Update a Secret

Via GCP Console:
1. Go to: https://console.cloud.google.com/security/secret-manager
2. Click secret name > NEW VERSION
3. Paste new value > ADD NEW VERSION

Via CLI:
```bash
echo -n "your-new-api-key" | gcloud secrets versions add adk-cti-priority-google-ti-api-key --data-file=-
```

### Check Logs

```bash
# From project root
cat logs/run.log
cat logs/cti-agent.log
ls logs/query_log_*.jsonl
```

### Authentication Issues

```bash
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
gcloud auth list
```

### No API Keys Available

System works in OSINT-only mode without API keys. Add keys later:

```bash
./scripts/setup_secrets_gsm.sh
```

---

## Project Structure

```
adk-cti-priority/               # Project root
├── README.md                   # This file
├── setup.sh                    # One-time setup script
├── run.sh                      # Automated run script
├── run_agent.py                # Main entry point
├── config.yaml                 # User configuration
├── adk.yaml                    # ADK configuration
├── requirements.txt            # Python dependencies
│
├── scripts/
│   ├── setup_secrets_gsm.sh    # Secret setup helper
│   └── validate.sh             # Validation script
│
├── cti_agent/
│   ├── orchestrator.py         # Main coordinator
│   ├── agents/                 # Specialist agents
│   ├── tools/                  # API wrappers
│   ├── config/                 # Settings loader
│   ├── prompts/                # Agent instructions
│   └── schemas/                # Data validation
│
├── output/                     # Generated reports
│   ├── latest_report.html      # Most recent report
│   └── history/                # Historical reports
│
└── logs/                       # Execution logs
    ├── run.log                 # Script logs
    ├── cti-agent.log           # Agent logs
    └── query_log_*.jsonl       # API query logs
```

---

## Testing

### Validation

```bash
# From project root
./scripts/validate.sh
```

### Test with Sample Data

```bash
# From project root
source venv/bin/activate
python run_agent.py --org "Test Corp" --industry "Technology" --domains "google.com"
```

### Test Each Execution Method

```bash
# Method 1: Automated script
./run.sh

# Method 2: ADK web
adk web

# Method 3: Config file
source venv/bin/activate
python run_agent.py --from-config

# Method 4: CLI arguments
source venv/bin/activate
python run_agent.py --org "Test" --domains "test.com"

# Method 5: Interactive
source venv/bin/activate
python run_agent.py --interactive
```

---

## Examples

### Example 1: Basic Run with Script

```bash
# Edit config.yaml first
# Then from project root:
./run.sh
```

### Example 2: Automation Script

```bash
#!/bin/bash
# automated_scan.sh

cd /path/to/agentic-cti-priority
source venv/bin/activate
python run_agent.py --from-config

# Email report
mail -s "Daily CTI Report" analyst@company.com < output/latest_report.html
```

### Example 3: Multiple Targets

```bash
source venv/bin/activate

python run_agent.py --org "Company A" --domains "companya.com"
python run_agent.py --org "Company B" --domains "companyb.com"
python run_agent.py --org "Company C" --domains "companyc.com"
```

---

## Updating

### Update Python Dependencies

```bash
# From project root
source venv/bin/activate
pip install --upgrade -r requirements.txt
```

### Pull Latest Code

```bash
# From project root
git pull origin main
source venv/bin/activate
pip install -r requirements.txt
```

---

## Support

Issues or Questions:
- Email: dchow[AT]xtecsystems.com
- Include: Error messages, logs (logs/run.log), execution method used

---

## Built With

- Google Gemini 2.5 (Flash & Pro) via Vertex AI
- CrowdStrike FalconPy 1.4.5 SDK
- vt-py 0.18.4 (Google Threat Intelligence/VirusTotal)
- Flashpoint REST API
- Google Secret Manager for secure credentials

---

Version: 2.1
Author: Dennis Chow
Last Updated: 2026-03-07
