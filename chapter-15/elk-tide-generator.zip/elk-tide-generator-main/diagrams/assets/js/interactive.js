// Interactive features for elk-tide-generator diagrams

// Initialize Mermaid
mermaid.initialize({
  startOnLoad: true,
  theme: 'default',
  themeVariables: {
    primaryColor: '#e1f5ff',
    primaryTextColor: '#212529',
    primaryBorderColor: '#007bff',
    lineColor: '#6c757d',
    secondaryColor: '#fff3cd',
    tertiaryColor: '#d4edda',
  },
  flowchart: {
    htmlLabels: true,
    curve: 'basis',
    padding: 15,
  },
  sequence: {
    diagramMarginX: 50,
    diagramMarginY: 10,
    actorMargin: 50,
    width: 150,
    height: 65,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
  }
});

// Search functionality
function initializeSearch() {
  const searchInput = document.getElementById('search-input');
  if (!searchInput) return;

  searchInput.addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const diagramContainer = document.querySelector('.mermaid');

    if (!diagramContainer) return;

    // Remove previous highlights
    const highlighted = diagramContainer.querySelectorAll('.highlight');
    highlighted.forEach(el => {
      el.outerHTML = el.innerHTML;
    });

    if (searchTerm.length < 2) return;

    // Search in SVG text elements
    const textElements = diagramContainer.querySelectorAll('text, tspan');
    textElements.forEach(el => {
      if (el.textContent.toLowerCase().includes(searchTerm)) {
        // Highlight the parent node
        let node = el.closest('.node, .cluster');
        if (node) {
          node.style.filter = 'drop-shadow(0 0 8px #ffeb3b)';

          // Scroll into view
          if (textElements[0] === el) {
            node.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }
      }
    });
  });
}

// Toggle retry logic visibility
function initializeToggles() {
  const toggleBtn = document.getElementById('toggle-retry');
  if (!toggleBtn) return;

  toggleBtn.addEventListener('click', function() {
    const retryNodes = document.querySelectorAll('[data-retry]');
    const isHidden = toggleBtn.classList.toggle('active');

    retryNodes.forEach(node => {
      node.style.display = isHidden ? 'none' : 'block';
    });
  });
}

// Tab switching
function initializeTabs() {
  const tabs = document.querySelectorAll('.tab');
  if (tabs.length === 0) return;

  tabs.forEach(tab => {
    tab.addEventListener('click', function() {
      const targetId = this.getAttribute('data-tab');

      // Remove active class from all tabs and contents
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

      // Add active class to clicked tab and corresponding content
      this.classList.add('active');
      const targetContent = document.getElementById(targetId);
      if (targetContent) {
        targetContent.classList.add('active');
      }
    });
  });
}

// Tooltip functionality
function initializeTooltips() {
  const tooltipData = {
    // Workflow files
    'end-to-end-test.yml': 'Master orchestrator workflow (6 jobs, artifact passing)',
    'generate-detections.yml': 'Rule generation with region retry',
    'integration-test-simple.yml': 'Standalone ES testing',

    // Python scripts
    'agent.py': 'detection_agent/agent.py - 5-stage pipeline',
    'load_cti_files.py': 'detection_agent/tools/load_cti_files.py - CTI loading with chunking',
    'iterative_validator.py': 'detection_agent/tools/iterative_validator.py - 3-attempt validation',
    'validate_lucene.py': 'detection_agent/tools/validate_lucene.py - Lucene syntax validation',
    'validate_ecs_fields.py': 'detection_agent/tools/validate_ecs_fields.py - ECS field validation',
    'execute_detection_tests.py': 'scripts/execute_detection_tests.py - ES integration testing',
    'refine_failed_rules.py': 'scripts/refine_failed_rules.py - Test-driven refinement',
    'test_ttp_validator.py': 'scripts/test_ttp_validator.py - TTP intent validation',
    'select_region.py': 'scripts/select_region.py - Regional quota rotation',
    'create_manual_review_pr.py': 'scripts/create_manual_review_pr.py - Auto-PR creation',

    // Models
    'Gemini 2.5 Flash': 'Fast model for generation/security (3min timeout)',
    'Gemini 2.5 Pro': 'Advanced model for validation (4min timeout)',

    // Metrics
    'precision': 'TP / (TP + FP) - Threshold: ≥0.60',
    'recall': 'TP / (TP + FN) - Threshold: ≥0.70 (primary metric)',
    'f1_score': '2 * (precision * recall) / (precision + recall)',

    // Thresholds
    '0.70': 'Recall threshold for deployment eligibility',
    '0.60': 'Precision threshold for deployment eligibility',
    '0.75': 'Validation score threshold for rule approval',

    // Timeouts
    '120s': '2 minutes - Security scan timeout',
    '180s': '3 minutes - Generation timeout (Flash + Google Search)',
    '240s': '4 minutes - Validation timeout (Pro + Google Search)',
    '3.0s': 'Inter-agent delay to avoid rate limiting',
  };

  // Create tooltip element
  const tooltip = document.createElement('div');
  tooltip.className = 'tooltip';
  document.body.appendChild(tooltip);

  // Add hover listeners to SVG elements
  document.addEventListener('mouseover', function(e) {
    const target = e.target;
    const textContent = target.textContent?.trim();

    if (!textContent) return;

    // Check if text matches any tooltip data
    for (const [key, description] of Object.entries(tooltipData)) {
      if (textContent.includes(key)) {
        tooltip.textContent = description;
        tooltip.classList.add('show');

        // Position tooltip near cursor
        const x = e.pageX + 10;
        const y = e.pageY + 10;
        tooltip.style.left = x + 'px';
        tooltip.style.top = y + 'px';
        break;
      }
    }
  });

  document.addEventListener('mouseout', function(e) {
    tooltip.classList.remove('show');
  });

  // Update tooltip position on mouse move
  document.addEventListener('mousemove', function(e) {
    if (tooltip.classList.contains('show')) {
      const x = e.pageX + 10;
      const y = e.pageY + 10;
      tooltip.style.left = x + 'px';
      tooltip.style.top = y + 'px';
    }
  });
}

// Copy code functionality
function initializeCopyButtons() {
  const codeBlocks = document.querySelectorAll('pre code');

  codeBlocks.forEach(block => {
    const button = document.createElement('button');
    button.className = 'copy-btn';
    button.textContent = 'Copy';
    button.style.cssText = 'position: absolute; top: 5px; right: 5px; padding: 5px 10px; border-radius: 3px; border: 1px solid #ccc; background: white; cursor: pointer;';

    const wrapper = block.parentElement;
    wrapper.style.position = 'relative';
    wrapper.appendChild(button);

    button.addEventListener('click', function() {
      navigator.clipboard.writeText(block.textContent);
      button.textContent = 'Copied!';
      setTimeout(() => {
        button.textContent = 'Copy';
      }, 2000);
    });
  });
}

// Initialize all features when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  console.log('Initializing interactive features...');
  initializeSearch();
  initializeToggles();
  initializeTabs();
  initializeTooltips();
  initializeCopyButtons();
  console.log('Interactive features initialized.');
});

// Re-initialize Mermaid diagrams after dynamic content loads
function reinitializeMermaid() {
  mermaid.init(undefined, document.querySelectorAll('.mermaid'));
}
