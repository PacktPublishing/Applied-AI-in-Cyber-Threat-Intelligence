# Elk-Tide-Generator Interactive Diagrams

Interactive HTML5 documentation with Mermaid.js diagrams showing the architecture, workflows, and data flows of the elk-tide-generator detection engineering pipeline.

## 📂 Directory Structure

```
diagrams/
├── index.html                    # Master navigation page
├── README.md                     # This file
├── assets/
│   ├── css/
│   │   └── diagrams.css         # Shared styling
│   └── js/
│       └── interactive.js       # Interactive features
├── workflows/                    # GitHub Actions workflow diagrams
│   ├── workflow-overview.html
│   ├── end-to-end-test.html
│   ├── generate-detections.html
│   ├── integration-test-simple.html
│   └── mock-deploy.html
├── python-components/            # Python agent & tool diagrams
│   ├── agent-pipeline.html
│   ├── refinement-loops.html
│   ├── validation-tools.html
│   └── testing-framework.html
└── data-flows/                   # Data transformation diagrams
    ├── cti-to-rules.html
    └── testing-feedback.html
```

## 🚀 Quick Start

### View Locally

```bash
cd diagrams/
python3 -m http.server 8000
```

Then open http://localhost:8000 in your browser.

### Browse Directly

Open `index.html` directly in your browser (some features may require a local server).

## 📊 Diagram Categories

### 1. Workflows (5 diagrams)
- **workflow-overview.html** - All 6 workflows and their relationships
- **end-to-end-test.html** - Master orchestrator with 6 jobs
- **generate-detections.html** - Rule generation with regional retry
- **integration-test-simple.html** - Standalone ES testing
- **mock-deploy.html** - Deployment simulation

### 2. Python Components (4 diagrams)
- **agent-pipeline.html** - 5-stage detection agent sequence
- **refinement-loops.html** - 3 refinement strategies comparison
- **validation-tools.html** - 7 validation tools flowchart
- **testing-framework.html** - ES integration testing sequence

### 3. Data Flows (2 diagrams)
- **cti-to-rules.html** - CTI → Generation → Validation → Rules
- **testing-feedback.html** - Rules → Testing → Metrics → Refinement

## ✨ Interactive Features

### Tooltips
Hover over diagram nodes to see:
- File paths (e.g., `detection_agent/agent.py`)
- Function signatures
- Parameter descriptions
- Metric thresholds

### Search
Use the search box to find specific components:
- Workflow names (e.g., "end-to-end-test")
- Python scripts (e.g., "refine_failed_rules.py")
- Model names (e.g., "Gemini 2.5 Flash")
- Metrics (e.g., "recall", "precision")

### Toggle Controls
- **Toggle Retry Logic** - Show/hide retry loops and error paths
- **Collapsible Sections** - Click to expand/collapse detailed information

### Color Coding
- **Workflows**: Blue (`#e1f5ff`)
- **Generation**: Yellow (`#fff3cd`)
- **Validation**: Red (`#f8d7da`)
- **Refinement**: Green (`#d4edda`)
- **Testing**: Cyan (`#d1ecf1`)
- **Deployment**: Purple (`#e7e7ff`)

## 📖 Diagram Legend

### Workflow Diagrams
- **Rectangle** - Job or step
- **Diamond** - Decision point (conditional logic)
- **Subgraph** - Grouped jobs or stages
- **Arrows** - Data/control flow
- **Dashed lines** - Artifact dependencies

### Sequence Diagrams
- **Participant** - Component or service
- **Arrow** - Function call or message
- **Note** - Additional context or description
- **Rectangle** - Processing stage
- **Alt/Loop** - Conditional logic or iteration

## 🎯 Key Metrics & Thresholds

### Quality Thresholds
- **Precision ≥ 0.60** - TP / (TP + FP) - Secondary metric
- **Recall ≥ 0.70** - TP / (TP + FN) - PRIMARY metric for deployment
- **Validation Score ≥ 0.75** - Rule approval threshold

### Timeouts
- **Security scan**: 120s (2 minutes)
- **Generation**: 180s (3 minutes - Flash + Google Search)
- **Iterative validation**: 240s (4 minutes per iteration)
- **Final validation**: 240s (4 minutes per rule - Pro model)
- **Inter-agent delay**: 3.0s (rate limiting prevention)

### Retry Configuration
- **Max iterations**: 3 (self-healing, quality-driven)
- **Regional retry**: 3 regions (us-central1 → us-east4 → us-west1)
- **Exponential backoff**: 30s × 2^(attempt-1)

## 📚 Documentation Sources

All diagrams are verified against source code:

### Workflows
- `.github/workflows/end-to-end-test.yml` (652 lines)
- `.github/workflows/generate-detections.yml` (225 lines)
- `.github/workflows/integration-test-simple.yml`
- `.github/workflows/mock-deploy.yml`

### Python Components
- `detection_agent/agent.py` (367 lines - main pipeline)
- `detection_agent/refinement.py` (144 lines - self-healing)
- `detection_agent/quality_retry.py` (quality-driven refinement)
- `detection_agent/per_rule_refinement.py` (per-rule refinement)
- `detection_agent/tools/load_cti_files.py` (322 lines)
- `detection_agent/tools/iterative_validator.py`
- `detection_agent/tools/validate_lucene.py`
- `detection_agent/tools/validate_ecs_fields.py`
- `scripts/execute_detection_tests.py` (integration testing)
- `scripts/test_ttp_validator.py` (TTP intent validation)
- `scripts/refine_failed_rules.py` (test-driven refinement)

### Schemas
- `detection_agent/schemas/detection_rule.py` (Pydantic models)

## 🛠️ Technology Stack

- **Mermaid.js** - Declarative diagram rendering (v10)
- **HTML5/CSS3** - Modern web standards
- **Vanilla JavaScript** - No framework dependencies
- **Google Fonts** - Typography
- **Responsive Design** - Mobile-friendly layout

## 🔍 Browser Compatibility

Tested and working in:
- ✅ Chrome 120+
- ✅ Firefox 120+
- ✅ Safari 17+
- ✅ Edge 120+

## 📝 Maintenance

### Updating Diagrams

When source code changes:
1. Update the corresponding `.html` file in the appropriate directory
2. Verify Mermaid syntax with the [Mermaid Live Editor](https://mermaid.live/)
3. Update file paths and line numbers in info panels
4. Test all interactive features (tooltips, search, toggle)

### Adding New Diagrams

1. Create new `.html` file in appropriate directory
2. Copy template from existing diagram (e.g., `agent-pipeline.html`)
3. Update Mermaid diagram code
4. Add detailed info panel with file references
5. Update navigation links in related files
6. Add entry to `index.html` card grid

## 🤝 Contributing

When adding or updating diagrams:
1. Follow existing color scheme and styling
2. Include tooltips for all important nodes
3. Add comprehensive info panels with code examples
4. Verify all file paths are absolute and correct
5. Test in multiple browsers
6. Update this README if adding new categories

## 📅 Last Updated

March 5, 2026

## 📄 License

Part of the elk-tide-generator project.
